<div align="center">

# CLAWD JUMP

### AZURE ASCENT

**A precision platformer drawn entirely with procedural vector art**

[![Play](https://img.shields.io/badge/▶_PLAY-ds8puk8r249sc.cloudfront.net-E8825C?style=for-the-badge&labelColor=07060B)](https://ds8puk8r249sc.cloudfront.net/)

[![game assets](https://img.shields.io/badge/game_assets-0_bytes-5BD8E0?labelColor=15121F)](#audio-is-synthesised-at-runtime)
[![build](https://img.shields.io/badge/build_step-none-5BD8E0?labelColor=15121F)](#running-it)
[![payload](https://img.shields.io/badge/payload-304_KB-5BD8E0?labelColor=15121F)](#by-the-numbers)
[![tests](https://img.shields.io/badge/stack_tests-8_passing-8BE86A?labelColor=15121F)](#tests)
[![license](https://img.shields.io/badge/license-MIT-8B7BF0?labelColor=15121F)](LICENSE)

</div>

![Title screen](docs/img/title.png)

---

## What it is

A 2D precision platformer for the browser. You run, double jump, dash in eight
directions, and climb narrow shafts by kicking off alternating walls. Nine
hand-authored zones across three biomes, plus a procedurally generated endless
tower with a rising tide beneath you.

The interesting part technically: **nothing about the game is downloaded**. There
are no sprite sheets, no tilesets and no audio files. The character, terrain, sky,
sound effects and music are all generated at runtime. The whole payload is
**304 KB across 27 static files**, and the game is playable the moment the HTML
parses. (The only external fetch is the UI webfont.)

The in-game interface is in Korean — that is the game's own language. This
document, the code and its comments are in English.

<table>
<tr>
<td width="50%"><img src="docs/img/coral.png" alt="Coral Canyon"><br><sub><b>Coral Canyon</b> — sunset, canyon backwall, strata continuous across tiles</sub></td>
<td width="50%"><img src="docs/img/glass.png" alt="Glass Forest"><br><sub><b>Glass Forest</b> — four-tile vertical shafts climbed by wall jumping</sub></td>
</tr>
<tr>
<td width="50%"><img src="docs/img/ember.png" alt="Ember Core"><br><sub><b>Ember Core</b> — glowing vents, ash motes, heat wisps</sub></td>
<td width="50%"><img src="docs/img/endless.png" alt="Endless Ascent"><br><sub><b>Endless Ascent</b> — a generated tower and the tide that chases you up it</sub></td>
</tr>
</table>

## Controls

| Action | Keyboard | Gamepad |
|---|---|---|
| Move | `←` `→` / `A` `D` | Left stick · D-pad |
| Jump | `Space` `Z` `J` | A |
| Double jump | press jump again in the air | |
| Dash (8-way) | `Shift` `X` `K` | X · Y · RB · RT |
| Stomp | `↓` while airborne | Down |
| Wall jump | jump while sliding on a wall | |
| Pause | `Esc` `P` | Start |
| Restart zone | `R` | Back / Select |

Every key is rebindable, and the panel refuses a key another action already owns.
On touch devices a virtual stick and buttons appear; keyboard, gamepad and touch
all feed the same action layer.

<div align="center">
<img src="docs/img/select.png" width="49%" alt="Zone select">
<img src="docs/img/settings.png" width="49%" alt="Settings">
</div>

---

# Design notes

The rest of this document is *why*, not *what*. Reading it before touching the
code will save you time.

## The world is canvas; every glyph you read is DOM

The HUD, menus and settings are not drawn into the canvas with a bitmap font.
Only the world is `<canvas>`; all readable text is real DOM.

What that buys: text stays crisp at any device pixel ratio, CSS transitions and
`backdrop-filter` come free, focus rings are real, and screen readers can reach
the interface. None of that is available to glyphs painted on a canvas.

## The character is a rig, not a sprite sheet

`render/clawd.js` draws Clawd procedurally every frame — a superellipse shell,
two-segment legs, and pincers assembled in their own rotated space.

A baked sprite can only ever show the poses you drew. A rig deforms continuously:
squash on landing, stretch at take-off, lean into acceleration, legs reaching for
the ground, pupils that lead the direction of travel. Those values come straight
out of the physics rather than from animation data — and the result is resolution
independent, so it stays sharp at 4K.

## Bloom blurs the small buffer, then upscales

Emissive geometry is drawn to a separate quarter-resolution canvas. The order
matters.

Canvas2D's `ctx.filter` applies in *destination* space. Blur during the upscaling
`drawImage` and the kernel runs over every full-resolution pixel, throwing away
the entire benefit of the small buffer. Blur the small buffer first and let the
bilinear upscale widen the halo. On a software rasteriser this is the difference
between a playable frame time and an unplayable one.

## Terrain merges visible tiles into one Path2D

`CanvasGradient` and `CanvasPattern` coordinates resolve in user space **at paint
time**. So one gradient object can serve every tile as long as the context is
translated — dropping gradient construction from 576 per frame to zero.

Collecting every visible solid tile into a single `Path2D` and filling **once**
makes rock strata run continuously across tile boundaries. Filling per tile
restarts the pattern every 16 units; filling once makes a cliff read as one mass.

Depth shading on top of that is what turns a flat mass into a cliff face. It is
also grouped into one path per depth level, because per-tile translucent
`fillRect` calls antialias their own edges and double-blend against their
neighbours — printing a dark seam on every tile boundary.

## Game feel is a list of constants

All of it lives in `PHYS` in `game/config.js`, in roughly the order a player
notices it:

- **coyote time and jump buffering** — the jump fires when you meant it
- **asymmetric gravity with a softer apex window** — snappy fall, generous peak
- **turn boost** — direction changes bite immediately; without it the game feels like ice
- **corner correction** — a 1–3 unit lip lets a head or a foot slide past
- **8-way dash with a freeze frame** — reads as an impact, not a teleport
- **wall slide / wall jump with a brief input lock** — the kick always lands visually
- **hitstop, trauma-based screen shake, zoom pulse**

The simulation runs at a **fixed 120Hz** so a 60Hz laptop and a 165Hz monitor
integrate identically. Getting that guarantee to actually hold required care at
the input boundary — see the note below.

### The input boundary is load-bearing

The fixed timestep means `world.update` runs several times per rendered frame
while input is sampled once. Press *edges* must therefore be consumed exactly
once per press, not once per substep — otherwise a single tap fires both the
ground jump and the air jump, and the variable-height cut applies several times.

Measured before the fix: one press was seen by **8** substeps, the jump cut by
**3**, and the resulting apex was **1.13 tiles against a design value of 2.69** —
varying with the player's frame rate, which is precisely what the fixed timestep
exists to prevent. `Input#clearEdges()` is called after the first substep of each
frame. If you touch the loop, keep that invariant.

## Audio is synthesised at runtime

`core/audio.js` builds 22 sound effects and 5 sequenced tracks with WebAudio.
There are zero bytes of audio to download.

```
voices ─┬─> sfxBus ──┐
        └─> musBus ──┤
                     ├─> masterGain ─> compressor ─> destination
           fxSend ───┘
```

`fxSend` is a two-tap feedback delay with a lowpass in the loop — a cheap stand-in
for convolution reverb that glues percussive hits together. Each biome gets its
own key, mode and tempo (dorian / aeolian / phrygian), and arrangement density
follows nearby threat in real time.

## Accessibility

Assist mode (softer gravity, a third air jump, shorter dash cooldown),
invincibility, flash suppression, full key rebinding, adaptive quality that steps
itself down when frame rate drops, and a portrait-orientation prompt on phones.

`prefers-reduced-motion` reaches further than CSS here: the stylesheet zeroes UI
animation, and on a first run the OS preference also seeds screen shake to zero
and turns off flashes and film grain — because the game's own motion lives in the
canvas where CSS cannot reach it. Explicit choices afterwards are never
overridden.

The HUD reports state through a polite live region (throttled, since shard
pickups can land several times a second), so hearts and shard counts are
followable without seeing the canvas.

---

# Working on it

## Running it

No bundler, no transpile, no install. A static file server is enough.

```bash
npm run dev          # http://127.0.0.1:8099
```

`frontend/` is native ES modules. Edit a file, reload.

## Deploying

```bash
npm run deploy       # cdk deploy — prints SiteUrl when finished
```

A private S3 bucket read through CloudFront with **Origin Access Control**: the
bucket has no public access and no website endpoint, so the CDN is the only way
in (direct S3 requests return 403). CSP, HSTS, `nosniff` and frame denial are set
at the edge. Filenames are not content-hashed, so objects carry a short TTL and
every deploy issues a `/*` invalidation — players never get a stale mix of old
HTML and new modules.

Current deployment: `ClawdJumpStack` in `ap-northeast-2`, CloudFront `E22FCGFO0DGT52`.

## Authoring levels

Levels are not hand-typed ASCII — that makes it far too easy to misalign a row or
strand a region.

```bash
npm run levels       # build_levels.py → emit_levels.mjs → frontend/src/game/levels.js
```

`tools/build_levels.py` assembles each level from primitives (`ground`, `plat`,
`owp`, `spikes`, `water`, `ent`, `arc`) and validates that every row is
rectangular and that no bottomless pit is wider than a double jump.

> `frontend/src/game/levels.js` is **generated**. Do not hand-edit it.

Two rules the geometry has to respect, both learned the hard way:

- **Wall-jump shafts are 4 tiles wide.** A wall jump is `vx = ±168, vy = -258`,
  carrying about 3 tiles horizontally before the apex. Six tiles or more makes
  alternating walls impossible even though the level still *looks* like a shaft.
  Shaft walls also stop 2 tiles above the floor to leave a doorway, and rest
  ledges are one-way (`=`) — a solid ledge spanning the interior seals the shaft
  against anyone climbing from below.
- **Never enclose a region.** Two full-width ledges five rows apart formed a
  sealed chamber in `e3` that held two shards and four spikes nothing could ever
  reach, which silently made 100% completion impossible.

## The QA harness

Headless browsers throttle `requestAnimationFrame`, so screenshotting the normal
loop returns a blank canvas. A query flag runs the simulation in fixed steps
synchronously and draws once. It never engages without the flag.

```
?shot=<levelId|title|endless>   what to capture
&frames=240                     fixed steps at 1/120 s
&hold=right,jump                actions to hold down
&pulse=jump:26,dash:60          tap an action every N steps (jump and dash read a press edge)
&alt=30                         flip the horizontal axis every N steps
&bot=wall                       wall-climbing bot: jump and reverse on contact
&at=1650,286                    drop the player at a coordinate
&ui=select|settings|result      render a specific UI surface
```

Camera, bounds, player, audio and progress state are stamped onto
`<html data-shot="…">` as JSON.

```bash
npm run qa:browser   # download a Chromium via Playwright
npm run qa:sweep     # boot every level and report runtime health
tools/cap.sh coral "shot=c1&frames=260&hold=right&pulse=jump:26"
tools/diag.sh "shot=g2&at=736,316&frames=2000&bot=wall"
```

A caution learned from this harness: it builds its own input object and clears
press edges every step, so it exercised the *intended* input semantics and passed
happily while the shipped build halved its own jump height. **A harness that is
more correct than the product hides bugs.** When you add a test here, make it
drive the real `Input` where you can.

## Tests

```bash
npm test
```

The stack tests assert properties rather than snapshotting a template: the bucket
blocks public access and refuses plaintext, CloudFront reads it through OAC,
viewers are redirected to HTTPS, the CSP has no wildcard, HSTS is a year, and
deploys invalidate.

---

## Layout

```
frontend/                runs directly in the browser (native ES modules)
  index.html             DOM UI skeleton
  styles.css             UI layer
  src/core/              util · input · audio · save
  src/render/            stage (post-processing) · sky · tiles · particles · clawd (the rig)
  src/game/              config · level · levels (generated) · player · entities ·
                         enemies · world · endless
  src/ui/                screen transitions · menu navigation · HUD · settings
lib/  bin/               CDK stack (S3 + CloudFront + OAC)
tools/                   level builder (Python) · emitter (Node) · QA harness (bash)
test/                    stack unit tests
docs/img/                README screenshots
```

## By the numbers

| | |
|---|---|
| Engine (19 ES modules) | ~6,600 lines |
| Level data (generated) | 379 lines |
| UI (CSS + HTML) | 636 lines |
| Infrastructure + tests (TS) | 250 lines |
| Tooling (Python · Node · bash) | 557 lines |
| **What a player downloads** | **27 files · 304 KB** |
| Content | 9 zones · 3 biomes · 256 shards · 9 relics |
| Enemies · objects | 6 archetypes + projectile · 8 object types |
| Audio | 22 effects + 5 sequenced tracks, zero files |

## License

[MIT](LICENSE)
