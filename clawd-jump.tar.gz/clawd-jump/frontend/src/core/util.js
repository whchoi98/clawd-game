/**
 * Small, allocation-conscious helpers shared by every subsystem.
 * Everything here is pure: no DOM, no state.
 */

export const TAU = Math.PI * 2;

export const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);
export const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export const inverseLerp = (a, b, v) => (b === a ? 0 : (v - a) / (b - a));
export const sign = (v) => (v > 0 ? 1 : v < 0 ? -1 : 0);

/**
 * Frame-rate independent exponential smoothing.
 * `half` is the half-life in seconds — the time for the gap to halve.
 * Using half-life instead of a raw factor keeps feel identical at 60/120/144Hz.
 */
export const damp = (a, b, half, dt) => b + (a - b) * Math.pow(2, -dt / half);

/** Move `a` toward `b` by at most `maxDelta`. */
export function approach(a, b, maxDelta) {
  return a < b ? Math.min(a + maxDelta, b) : Math.max(a - maxDelta, b);
}

// ---------- easing ----------
export const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
export const easeOutBack = (t) => 1 + 2.70158 * Math.pow(t - 1, 3) + 1.70158 * Math.pow(t - 1, 2);
/** 0→1→0 hump, useful for one-shot squash pulses. */
export const hump = (t) => Math.sin(clamp01(t) * Math.PI);

// ---------- rng ----------
/** Deterministic 32-bit PRNG (mulberry32). Seeded runs make level gen reproducible. */
export function makeRng(seed = 1) {
  let a = seed >>> 0 || 1;
  const rng = () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  rng.range = (lo, hi) => lo + rng() * (hi - lo);
  rng.int = (lo, hi) => Math.floor(lo + rng() * (hi - lo + 1));
  rng.pick = (arr) => arr[Math.floor(rng() * arr.length)];
  rng.chance = (p) => rng() < p;
  rng.sign = () => (rng() < 0.5 ? -1 : 1);
  return rng;
}

export function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
}

/** Cheap tileable value noise — used for rock texture and wind fields. */
export function noise2(x, y) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const h = (a, b) => {
    let n = Math.imul(a, 374761393) + Math.imul(b, 668265263);
    n = Math.imul(n ^ (n >>> 13), 1274126177);
    return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
  };
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  return lerp(lerp(h(xi, yi), h(xi + 1, yi), u), lerp(h(xi, yi + 1), h(xi + 1, yi + 1), u), v);
}

export function fbm(x, y, oct = 3) {
  let sum = 0, amp = 0.5, norm = 0;
  for (let i = 0; i < oct; i++) {
    sum += noise2(x, y) * amp;
    norm += amp;
    amp *= 0.5; x *= 2.03; y *= 2.01;
  }
  return sum / norm;
}

// ---------- colour ----------
/** `rgba` from a hex string with alpha — cached because canvas style strings are hot. */
const _rgbaCache = new Map();
export function alpha(hex, a) {
  const key = hex + (a = Math.round(a * 1000) / 1000);
  let v = _rgbaCache.get(key);
  if (v) return v;
  const n = parseInt(hex.slice(1), 16);
  v = `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
  if (_rgbaCache.size < 4096) _rgbaCache.set(key, v);
  return v;
}

export function mixHex(a, b, t) {
  const x = parseInt(a.slice(1), 16), y = parseInt(b.slice(1), 16);
  const r = Math.round(lerp((x >> 16) & 255, (y >> 16) & 255, t));
  const g = Math.round(lerp((x >> 8) & 255, (y >> 8) & 255, t));
  const c = Math.round(lerp(x & 255, y & 255, t));
  return '#' + ((r << 16) | (g << 8) | c).toString(16).padStart(6, '0');
}

export function shade(hex, amt) {
  return mixHex(hex, amt < 0 ? '#000000' : '#ffffff', Math.abs(amt));
}

// ---------- geometry ----------
// ---------- formatting ----------
export function fmtTime(sec) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  const cs = Math.floor((sec * 100) % 100);
  return `${m}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
}
