/**
 * Persistence. Two documents in localStorage: settings and progress.
 * Both are versioned and defensively merged so a schema change never
 * bricks an existing player's save.
 */
import { DEFAULT_BINDS } from './input.js';

const KEY_SET = 'clawdjump.settings.v1';
const KEY_PRG = 'clawdjump.progress.v1';

export const DEFAULT_SETTINGS = {
  v: 1,
  master: 0.8,
  music: 0.55,
  sfx: 0.85,
  shake: 1,          // 0..1 screen-shake scale
  bloom: true,
  grain: true,
  quality: 'auto',   // auto | high | balanced | low
  flashes: true,     // photosensitivity: disables full-screen white flashes when false
  showTimer: true,
  skin: 'clawd',     // one of render/clawd.js SKINS
  assist: false,     // slower gravity + extra air jump + shorter dash cooldown
  invincible: false,
  binds: DEFAULT_BINDS,
};

export const DEFAULT_PROGRESS = {
  v: 1,
  levels: {},        // id -> { done, bestMs, bestShards, stars, relics:[], deaths }
  endless: { bestHeight: 0, bestShards: 0, runs: 0 },
  totals: { deaths: 0, shards: 0 },   // lifetime counters; replays add to both
  seen: {},          // one-shot tutorial flags
  lastLevel: null,
};

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return structuredClone(fallback);
    const obj = JSON.parse(raw);
    return deepMerge(structuredClone(fallback), obj);
  } catch {
    return structuredClone(fallback);
  }
}

function deepMerge(base, patch) {
  if (patch === null || typeof patch !== 'object' || Array.isArray(patch)) return patch ?? base;
  for (const k of Object.keys(patch)) {
    if (k in base && base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) {
      base[k] = deepMerge(base[k], patch[k]);
    } else {
      base[k] = patch[k];
    }
  }
  return base;
}

function write(key, obj) {
  try { localStorage.setItem(key, JSON.stringify(obj)); } catch { /* private mode / quota */ }
}

const hadSettings = (() => { try { return !!localStorage.getItem(KEY_SET); } catch { return false; } })();

export const settings = read(KEY_SET, DEFAULT_SETTINGS);
export const progress = read(KEY_PRG, DEFAULT_PROGRESS);

// The stylesheet honours prefers-reduced-motion for UI animation, but the game's
// own motion — screen shake, flashes, grain — lives in the canvas and cannot be
// reached by CSS. Seed those toggles from the OS preference on a first run, then
// leave the player's explicit choices alone.
if (!hadSettings && typeof matchMedia === 'function' &&
    matchMedia('(prefers-reduced-motion: reduce)').matches) {
  settings.shake = 0;
  settings.flashes = false;
  settings.grain = false;
  write(KEY_SET, settings);
}

let setTimer = 0, prgTimer = 0;
export function saveSettings() {
  clearTimeout(setTimer);
  setTimer = setTimeout(() => write(KEY_SET, settings), 250);
}
export function saveProgress() {
  clearTimeout(prgTimer);
  prgTimer = setTimeout(() => write(KEY_PRG, progress), 250);
}

export function levelRecord(id) {
  return (progress.levels[id] ||= { done: false, bestMs: Infinity, bestShards: 0, stars: 0, relics: [], deaths: 0 });
}

/** Infinity does not survive JSON — normalise on read. */
export function bestMs(id) {
  const r = progress.levels[id];
  if (!r || r.bestMs === null || r.bestMs === undefined) return Infinity;
  return r.bestMs === 0 ? Infinity : r.bestMs;
}

export function resetProgress() {
  Object.assign(progress, structuredClone(DEFAULT_PROGRESS));
  write(KEY_PRG, progress);
}

