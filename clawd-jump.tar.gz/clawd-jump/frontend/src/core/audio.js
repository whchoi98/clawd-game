/**
 * Fully procedural audio — zero downloaded assets, so the game is playable
 * the instant the HTML parses.
 *
 * Signal graph:
 *   voices ─┬─> sfxBus ──┐
 *           └─> musBus ──┤
 *                        ├─> masterGain ─> compressor ─> destination
 *              fxSend ───┘        (a soft limiter keeps stacked
 *                                  explosions from clipping)
 *
 * `fxSend` is a two-tap feedback delay with a lowpass in the loop: a cheap
 * stand-in for reverb that costs ~nothing and glues percussive hits together.
 */
import { settings } from './save.js';
import { clamp, lerp } from './util.js';

const SCALES = {
  dorian: [0, 2, 3, 5, 7, 9, 10],
  aeolian: [0, 2, 3, 5, 7, 8, 10],
  phrygian: [0, 1, 3, 5, 7, 8, 10],
  lydian: [0, 2, 4, 6, 7, 9, 11],
  pentMin: [0, 3, 5, 7, 10],
};

/** Per-biome musical identity. Each track is a different key, mode and texture. */
export const TRACKS = {
  menu:   { root: 50, scale: 'dorian',   bpm: 84,  pad: 0.30, arp: 0.16, bass: 0.20, drums: 0.00, bell: 0.16, prog: [0, 5, 3, 4] },
  coral:  { root: 52, scale: 'dorian',   bpm: 112, pad: 0.22, arp: 0.20, bass: 0.26, drums: 0.34, bell: 0.12, prog: [0, 3, 5, 4] },
  glass:  { root: 45, scale: 'aeolian',  bpm: 100, pad: 0.28, arp: 0.22, bass: 0.22, drums: 0.24, bell: 0.20, prog: [0, 5, 2, 4] },
  ember:  { root: 40, scale: 'phrygian', bpm: 132, pad: 0.18, arp: 0.16, bass: 0.32, drums: 0.42, bell: 0.08, prog: [0, 1, 5, 4] },
  endless:{ root: 47, scale: 'pentMin',  bpm: 124, pad: 0.22, arp: 0.24, bass: 0.26, drums: 0.32, bell: 0.16, prog: [0, 4, 2, 5] },
};

const midi = (n) => 440 * Math.pow(2, (n - 69) / 12);

class Audio {
  constructor() {
    this.ctx = null;
    this.ready = false;
    this.track = null;
    this.trackName = null;
    this.intensity = 1;     // 0..1 — ducks drums/arp for menus & calm moments
    this._targetIntensity = 1;
    this._step = 0;
    this._nextTime = 0;
    this._bar = 0;
    this._muffle = 0;
    this._targetMuffle = 0;
    this._lastSfx = new Map();
    this.comboPitch = 0;
    /** Voices constructed since init — a liveness signal for automated checks. */
    this.voices = 0;
  }

  /** Must be called from a user gesture (browser autoplay policy). */
  init() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const ctx = (this.ctx = new AC({ latencyHint: 'interactive' }));

    this.comp = ctx.createDynamicsCompressor();
    this.comp.threshold.value = -14;
    this.comp.knee.value = 24;
    this.comp.ratio.value = 6;
    this.comp.attack.value = 0.004;
    this.comp.release.value = 0.16;
    this.comp.connect(ctx.destination);

    this.master = ctx.createGain();
    this.master.gain.value = settings.master;
    this.master.connect(this.comp);

    this.sfxBus = ctx.createGain();
    this.sfxBus.gain.value = settings.sfx;
    this.sfxBus.connect(this.master);

    this.musBus = ctx.createGain();
    this.musBus.gain.value = settings.music;
    this.musLp = ctx.createBiquadFilter();
    this.musLp.type = 'lowpass';
    this.musLp.frequency.value = 20000;
    this.musBus.connect(this.musLp);
    this.musLp.connect(this.master);

    // --- feedback-delay "reverb": two INDEPENDENT comb filters ---
    // A single feedback gain feeding both delay lines makes the two return paths
    // sum at the shared damping filter, so the effective loop gain is g+g rather
    // than g. At g=0.42 that is 0.84, and a feedback delay settles at 1/(1-g)
    // times its input — 6.25x, reached over about seven seconds. Because the
    // music excites the bus continuously it never decayed back, so everything
    // audibly swelled for the first ten seconds and then stayed loud.
    //
    // Each comb now owns its damping and its feedback, so the loop gain is the
    // number written here and the two tails do not compound.
    this.fxSend = ctx.createGain();
    this.fxSend.gain.value = 1;
    const wet = ctx.createGain();
    wet.gain.value = 0.5;
    for (const [time, feedback] of [[0.147, 0.38], [0.211, 0.34]]) {
      const d = ctx.createDelay(1);
      d.delayTime.value = time;
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 2600;
      const fb = ctx.createGain();
      fb.gain.value = feedback;
      this.fxSend.connect(d);
      d.connect(lp);
      lp.connect(fb);
      fb.connect(d);
      lp.connect(wet);
    }
    wet.connect(this.master);

    // shared noise buffer for hats, dust and impacts
    const len = ctx.sampleRate * 1.2;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    this.noiseBuf = buf;

    this.ready = true;
    this._nextTime = ctx.currentTime + 0.06;
  }

  applySettings() {
    if (!this.ready) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(settings.master, t, 0.05);
    this.sfxBus.gain.setTargetAtTime(settings.sfx, t, 0.05);
    this.musBus.gain.setTargetAtTime(settings.music, t, 0.05);
  }

  // ---------------------------------------------------------------- primitives
  _noise(dur, { gain = 0.3, type = 'highpass', freq = 4000, q = 0.7, dest = null, at = 0, curve = 3 } = {}) {
    const ctx = this.ctx, t = ctx.currentTime + at;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.playbackRate.value = 0.8 + Math.random() * 0.5;
    const f = ctx.createBiquadFilter();
    f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f); f.connect(g);
    g.connect(dest || this.sfxBus);
    src.start(t, Math.random() * 0.4);
    src.stop(t + dur + 0.02);
    this.voices++;
    return { f, g };
  }

  _tone(freqA, freqB, dur, { type = 'sine', gain = 0.3, at = 0, dest = null, attack = 0.004, fx = 0, curve = 'exp' } = {}) {
    const ctx = this.ctx, t = ctx.currentTime + at;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freqA, t);
    if (freqB && freqB !== freqA) {
      if (curve === 'exp') o.frequency.exponentialRampToValueAtTime(Math.max(1, freqB), t + dur);
      else o.frequency.linearRampToValueAtTime(freqB, t + dur);
    }
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(dest || this.sfxBus);
    if (fx > 0) { const s = ctx.createGain(); s.gain.value = fx; g.connect(s); s.connect(this.fxSend); }
    o.start(t); o.stop(t + dur + 0.02);
    this.voices++;
    return { o, g };
  }

  /** Rate-limit identical one-shots so a particle storm can't machine-gun. */
  _gate(name, ms) {
    const now = performance.now();
    if ((this._lastSfx.get(name) || 0) + ms > now) return false;
    this._lastSfx.set(name, now);
    return true;
  }

  // ---------------------------------------------------------------- sfx
  sfx(name, opt = {}) {
    if (!this.ready || this.ctx.state !== 'running') return;
    const v = opt.vol ?? 1;
    switch (name) {
      case 'jump':
        if (!this._gate('jump', 40)) return;
        this._tone(300, 620, 0.16, { type: 'triangle', gain: 0.26 * v, attack: 0.002 });
        this._noise(0.09, { gain: 0.06 * v, type: 'highpass', freq: 1800 });
        break;
      case 'jump2':
        this._tone(420, 880, 0.2, { type: 'triangle', gain: 0.24 * v, fx: 0.2 });
        this._tone(640, 1300, 0.14, { type: 'sine', gain: 0.12 * v, at: 0.02 });
        break;
      case 'land': {
        if (!this._gate('land', 60)) return;
        const s = clamp(opt.impact ?? 0.5, 0, 1);
        this._noise(0.1 + s * 0.1, { gain: (0.07 + s * 0.16) * v, type: 'lowpass', freq: 900 + s * 700 });
        this._tone(150 - s * 40, 70, 0.1, { type: 'sine', gain: 0.12 * s * v });
        break;
      }
      case 'dash':
        this._noise(0.26, { gain: 0.2 * v, type: 'bandpass', freq: 1500, q: 1.1 });
        this._tone(900, 220, 0.24, { type: 'sawtooth', gain: 0.1 * v, fx: 0.25 });
        break;
      case 'walljump':
        this._tone(260, 700, 0.18, { type: 'square', gain: 0.14 * v });
        this._noise(0.12, { gain: 0.1 * v, type: 'highpass', freq: 2400 });
        break;
      case 'shard': {
        const step = clamp(opt.combo ?? 0, 0, 12);
        const f = midi(76 + step * 2);
        this._tone(f, f, 0.1, { type: 'triangle', gain: 0.2 * v, fx: 0.35 });
        this._tone(f * 2, f * 2, 0.16, { type: 'sine', gain: 0.1 * v, at: 0.03, fx: 0.4 });
        break;
      }
      case 'relic':
        [0, 4, 7, 12].forEach((s, i) =>
          this._tone(midi(72 + s), midi(72 + s), 0.5, { type: 'sine', gain: 0.15 * v, at: i * 0.07, fx: 0.6 }));
        break;
      case 'checkpoint':
        [0, 7, 12].forEach((s, i) =>
          this._tone(midi(64 + s), midi(64 + s), 0.4, { type: 'triangle', gain: 0.13 * v, at: i * 0.06, fx: 0.5 }));
        break;
      case 'hurt':
        this._tone(340, 90, 0.3, { type: 'sawtooth', gain: 0.22 * v });
        this._noise(0.2, { gain: 0.16 * v, type: 'lowpass', freq: 1200 });
        break;
      case 'die':
        this._tone(400, 55, 0.7, { type: 'square', gain: 0.2 * v, fx: 0.3 });
        this._noise(0.5, { gain: 0.18 * v, type: 'lowpass', freq: 700 });
        break;
      case 'stomp':
        this._tone(200, 60, 0.14, { type: 'square', gain: 0.2 * v });
        this._noise(0.16, { gain: 0.2 * v, type: 'lowpass', freq: 1400 });
        break;
      case 'enemyDie':
        this._noise(0.22, { gain: 0.18 * v, type: 'bandpass', freq: 900, q: 0.8 });
        this._tone(500, 140, 0.2, { type: 'triangle', gain: 0.14 * v, fx: 0.25 });
        break;
      case 'spring':
        this._tone(180, 1000, 0.22, { type: 'sine', gain: 0.22 * v, curve: 'lin', fx: 0.2 });
        break;
      case 'goal':
        [0, 4, 7, 12, 16].forEach((s, i) =>
          this._tone(midi(65 + s), midi(65 + s), 0.7, { type: 'triangle', gain: 0.16 * v, at: i * 0.085, fx: 0.7 }));
        break;
      case 'boom':
        this._noise(0.55, { gain: 0.3 * v, type: 'lowpass', freq: 500 });
        this._tone(110, 34, 0.45, { type: 'sine', gain: 0.3 * v });
        break;
      case 'shoot':
        if (!this._gate('shoot', 50)) return;
        this._tone(720, 260, 0.13, { type: 'square', gain: 0.09 * v });
        break;
      case 'uiMove':
        if (!this._gate('uiMove', 40)) return;
        this._tone(660, 660, 0.05, { type: 'sine', gain: 0.08 * v });
        break;
      case 'uiSelect':
        this._tone(520, 780, 0.11, { type: 'triangle', gain: 0.14 * v, fx: 0.2 });
        break;
      case 'uiBack':
        this._tone(420, 260, 0.11, { type: 'triangle', gain: 0.12 * v });
        break;
      case 'star':
        this._tone(midi(84), midi(91), 0.35, { type: 'sine', gain: 0.16 * v, fx: 0.6 });
        break;
      case 'crumble':
        if (!this._gate('crumble', 90)) return;
        this._noise(0.3, { gain: 0.12 * v, type: 'bandpass', freq: 700, q: 0.6 });
        break;
      case 'wind':
        this._noise(0.8, { gain: 0.05 * v, type: 'bandpass', freq: 500, q: 0.4 });
        break;
    }
  }

  // ---------------------------------------------------------------- music
  play(trackName, { intensity = 1 } = {}) {
    if (!TRACKS[trackName]) return;
    this._targetIntensity = intensity;
    if (this.trackName === trackName) return;
    this.trackName = trackName;
    this.track = TRACKS[trackName];
    this._step = 0;
    this._bar = 0;
    if (this.ready) this._nextTime = Math.max(this._nextTime, this.ctx.currentTime + 0.05);
  }

  stopMusic() { this.trackName = null; this.track = null; }

  setIntensity(v) { this._targetIntensity = clamp(v, 0, 1); }

  /** Muffle the music (pause menu) without touching the master volume. */
  setMuffle(on) { this._targetMuffle = on ? 1 : 0; }

  /** Called every frame; schedules ahead so timing never depends on rAF jitter. */
  tick(dt) {
    if (!this.ready || this.ctx.state !== 'running') return;
    this.intensity = lerp(this.intensity, this._targetIntensity, 1 - Math.pow(0.001, dt));
    this._muffle = lerp(this._muffle, this._targetMuffle, 1 - Math.pow(0.0005, dt));
    this.musLp.frequency.value = lerp(20000, 420, this._muffle);

    if (!this.track) return;
    const ctx = this.ctx;
    const spb = 60 / this.track.bpm;
    const stepDur = spb / 4; // sixteenths

    // rAF stops while the tab is hidden, so `_nextTime` can fall far behind the
    // audio clock. Without a resync the catch-up loop would schedule dozens of
    // steps at a negative offset, which WebAudio clamps to "now" — every one of
    // them firing simultaneously as one loud burst.
    if (this._nextTime < ctx.currentTime - 0.25) this._nextTime = ctx.currentTime + 0.02;

    const horizon = ctx.currentTime + 0.16;
    let guard = 0;
    while (this._nextTime < horizon && guard++ < 64) {
      this._schedule(this._nextTime - ctx.currentTime, stepDur);
      this._nextTime += stepDur;
      this._step++;
      if (this._step % 16 === 0) this._bar++;
    }
  }

  _schedule(at, stepDur) {
    const T = this.track;
    const sc = SCALES[T.scale];
    const deg = T.prog[this._bar % T.prog.length];
    const chordRoot = T.root + sc[deg % sc.length] + 12 * Math.floor(deg / sc.length);
    const s = this._step % 16;
    const inten = this.intensity;
    const mus = this.musBus;

    // --- pad: retrigger on the bar, long and soft ---
    if (s === 0) {
      const voices = [0, 2, 4].map((i) => chordRoot + sc[(deg + i) % sc.length] + (i === 4 ? 12 : 0));
      for (const n of voices) {
        for (const det of [-6, 6]) {
          this._tone(midi(n) * Math.pow(2, det / 1200), null, stepDur * 16.5, {
            type: 'sawtooth', gain: T.pad * 0.06, attack: 0.35, dest: mus, fx: 0.5,
          });
        }
      }
    }

    // --- bass ---
    if (s % 4 === 0 || (s === 14 && (this._bar & 1))) {
      const n = chordRoot - 24;
      this._tone(midi(n), midi(n) * 0.995, stepDur * 3.2, { type: 'triangle', gain: T.bass * 0.5, attack: 0.006, dest: mus });
      this._tone(midi(n) * 2, midi(n) * 2, stepDur * 1.2, { type: 'square', gain: T.bass * 0.08, dest: mus });
    }

    // --- arpeggio: rides the chord, density follows intensity ---
    const arpOn = [0, 3, 6, 8, 11, 14];
    if (arpOn.includes(s) && inten > 0.18) {
      const idx = (this._step * 3 + this._bar) % 5;
      const n = chordRoot + sc[(deg + idx * 2) % sc.length] + 12 * (idx > 2 ? 1 : 0);
      this._tone(midi(n), midi(n), stepDur * 2.4, {
        type: 'triangle', gain: T.arp * 0.34 * inten, attack: 0.004, dest: mus, fx: 0.35,
      });
    }

    // --- sparkle bell every other bar ---
    if (s === 6 && this._bar % 2 === 1) {
      const n = chordRoot + 24 + sc[(this._bar * 3) % sc.length];
      this._tone(midi(n), midi(n), stepDur * 6, { type: 'sine', gain: T.bell * 0.3, dest: mus, fx: 0.9 });
    }

    // --- drums ---
    const d = T.drums * inten;
    if (d > 0.02) {
      if (s === 0 || s === 6 || s === 10) {
        this._tone(120, 42, 0.16, { type: 'sine', gain: d * 0.8, attack: 0.002, dest: mus });
      }
      if (s === 4 || s === 12) {
        this._noise(0.13, { gain: d * 0.34, type: 'bandpass', freq: 1900, q: 0.7, dest: mus });
        this._tone(210, 170, 0.08, { type: 'triangle', gain: d * 0.2, dest: mus });
      }
      if (s % 2 === 0) {
        this._noise(0.045, { gain: d * (s % 4 === 0 ? 0.14 : 0.09), type: 'highpass', freq: 7200, dest: mus });
      }
    }
  }
}

export const audio = new Audio();
