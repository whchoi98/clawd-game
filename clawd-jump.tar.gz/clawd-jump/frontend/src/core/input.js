/**
 * Unified input: keyboard + gamepad + touch, expressed as named actions.
 *
 * Design note — why an event queue instead of polling `keydown` state:
 * a tap that starts and ends inside a single frame (very common on 144Hz
 * displays and on touch) would be invisible to a naive prev/cur diff. Events
 * are queued as they arrive and drained once per frame, so no press is ever lost.
 */

export const DEFAULT_BINDS = {
  left: ['ArrowLeft', 'KeyA'],
  right: ['ArrowRight', 'KeyD'],
  up: ['ArrowUp', 'KeyW'],
  down: ['ArrowDown', 'KeyS'],
  jump: ['Space', 'KeyZ', 'KeyJ'],
  dash: ['ShiftLeft', 'ShiftRight', 'KeyX', 'KeyK'],
  pause: ['Escape', 'KeyP'],
  confirm: ['Enter', 'Space'],
  cancel: ['Escape', 'Backspace'],
  restart: ['KeyR'],
};

const PAD_MAP = {
  0: 'jump',      // A / cross
  1: 'cancel',    // B / circle
  2: 'dash',      // X / square
  3: 'dash',      // Y / triangle
  5: 'dash',      // RB
  7: 'dash',      // RT
  8: 'restart',   // back / select
  9: 'pause',     // start
  12: 'up',
  13: 'down',
  14: 'left',
  15: 'right',
};

export class Input {
  constructor(binds) {
    this.binds = structuredClone(binds || DEFAULT_BINDS);
    this._rebuild();

    this.held = new Set();
    this.pressed = new Set();
    this.released = new Set();
    this._queue = [];
    this._keyHeld = new Set();

    this.axisX = 0;
    this.axisY = 0;
    this.padConnected = false;
    this.lastDevice = 'keyboard';
    /** Set while a rebind widget is capturing; suppresses normal handling. */
    this.captureFn = null;

    this._padPrev = [];
    this.touch = { x: 0, y: 0, active: false, jump: false, dash: false };
    this._touchBtns = new Set();

    this._onKeyDown = (e) => {
      if (this.captureFn) {
        e.preventDefault();
        if (e.code !== 'Escape') this.captureFn(e.code);
        else this.captureFn(null);
        return;
      }
      if (e.repeat) return;
      // Space/arrows scroll the page and steal focus from the canvas otherwise.
      if (this._owned.has(e.code)) e.preventDefault();
      if (this._keyHeld.has(e.code)) return;
      this._keyHeld.add(e.code);
      this.lastDevice = 'keyboard';
      for (const a of this._codeToActions(e.code)) this._queue.push([a, 1]);
    };
    this._onKeyUp = (e) => {
      if (!this._keyHeld.delete(e.code)) return;
      for (const a of this._codeToActions(e.code)) this._queue.push([a, 0]);
    };
    this._onBlur = () => {
      for (const code of this._keyHeld) for (const a of this._codeToActions(code)) this._queue.push([a, 0]);
      this._keyHeld.clear();
    };

    addEventListener('keydown', this._onKeyDown, { passive: false });
    addEventListener('keyup', this._onKeyUp);
    addEventListener('blur', this._onBlur);
    addEventListener('gamepadconnected', () => { this.padConnected = true; });
    addEventListener('gamepaddisconnected', () => { this.padConnected = false; });
  }

  _rebuild() {
    this._map = new Map();
    this._owned = new Set();
    for (const [action, codes] of Object.entries(this.binds)) {
      for (const c of codes) {
        if (!this._map.has(c)) this._map.set(c, []);
        this._map.get(c).push(action);
        if (c.startsWith('Arrow') || c === 'Space' || c === 'Tab') this._owned.add(c);
      }
    }
  }

  _codeToActions(code) { return this._map.get(code) || []; }

  setBinds(binds) { this.binds = structuredClone(binds); this._rebuild(); }

  /** Capture the next physical key for `action` at `slot`. Returns a cancel fn. */
  capture(cb) {
    this.captureFn = (code) => { this.captureFn = null; cb(code); };
    return () => { this.captureFn = null; };
  }

  /** Drain queued events and poll continuous devices. Call once per frame, first. */
  update() {
    this.pressed.clear();
    this.released.clear();

    for (let i = 0; i < this._queue.length; i++) {
      const [a, on] = this._queue[i];
      if (on) {
        this.pressed.add(a);
        this.held.add(a);
      } else {
        // A tap that opened and closed inside this frame reports both `pressed`
        // and `released`, so variable-height jump cuts still trigger correctly.
        this.released.add(a);
        this.held.delete(a);
      }
    }
    this._queue.length = 0;

    this._pollPad();
    this._pollTouch();

    const l = this.held.has('left'), r = this.held.has('right');
    let ax = (r ? 1 : 0) - (l ? 1 : 0);
    if (ax === 0 && Math.abs(this._padX) > 0.001) ax = this._padX;
    if (ax === 0 && this.touch.active) ax = this.touch.x;
    this.axisX = Math.max(-1, Math.min(1, ax));

    const u = this.held.has('up'), d = this.held.has('down');
    let ay = (d ? 1 : 0) - (u ? 1 : 0);
    if (ay === 0 && Math.abs(this._padY) > 0.001) ay = this._padY;
    if (ay === 0 && this.touch.active) ay = this.touch.y;
    this.axisY = Math.max(-1, Math.min(1, ay));
  }

  _pollPad() {
    this._padX = 0; this._padY = 0;
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    let any = false;
    for (const p of pads) {
      if (!p) continue;
      any = true;
      const dz = 0.28;
      const ax = p.axes[0] || 0, ay = p.axes[1] || 0;
      if (Math.abs(ax) > dz) this._padX = (ax - Math.sign(ax) * dz) / (1 - dz);
      if (Math.abs(ay) > dz) this._padY = (ay - Math.sign(ay) * dz) / (1 - dz);
      const prev = this._padPrev[p.index] || (this._padPrev[p.index] = []);
      for (let b = 0; b < p.buttons.length; b++) {
        const on = p.buttons[b].pressed || p.buttons[b].value > 0.55;
        const action = PAD_MAP[b];
        if (on !== !!prev[b]) {
          prev[b] = on;
          if (action) {
            if (on) { this.pressed.add(action); this.held.add(action); this.lastDevice = 'pad'; }
            else { this.released.add(action); this.held.delete(action); }
          }
          if (on && (b === 0 || b === 9)) { this.pressed.add('confirm'); }
        }
      }
      break; // first connected pad wins
    }
    this.padConnected = any;
  }

  _pollTouch() {
    for (const name of ['jump', 'dash']) {
      const on = this.touch[name];
      const was = this._touchBtns.has(name);
      if (on && !was) { this._touchBtns.add(name); this.pressed.add(name); this.held.add(name); this.lastDevice = 'touch'; }
      else if (!on && was) { this._touchBtns.delete(name); this.released.add(name); this.held.delete(name); }
    }
  }

  /**
   * Drop the press/release edges while keeping `held` intact.
   *
   * The simulation runs at a fixed 120Hz behind an accumulator, so `world.update`
   * may run several times per rendered frame while `update()` here runs once. If
   * the edges survived into the later substeps, a single tap would be consumed
   * repeatedly: the ground jump and the air jump would both fire on one press,
   * and the variable-height cut would apply several times. The loop calls this
   * after the first substep so every press is worth exactly one edge.
   */
  clearEdges() {
    this.pressed.clear();
    this.released.clear();
  }

  /** Clear every held action — used on scene changes so movement doesn't leak. */
  reset() {
    this.held.clear(); this.pressed.clear(); this.released.clear();
    this._queue.length = 0; this._keyHeld.clear();
    this.touch.active = false; this.touch.x = 0; this.touch.y = 0;
    this.touch.jump = false; this.touch.dash = false;
    this._touchBtns.clear();
  }

  down(a) { return this.held.has(a); }
  hit(a) { return this.pressed.has(a); }
  up_(a) { return this.released.has(a); }
}

/** Human-readable label for a KeyboardEvent.code. */
export function keyLabel(code) {
  if (!code) return '—';
  const table = {
    ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓',
    Space: 'SPACE', ShiftLeft: 'L SHIFT', ShiftRight: 'R SHIFT',
    ControlLeft: 'L CTRL', ControlRight: 'R CTRL', AltLeft: 'ALT', AltRight: 'ALT GR',
    Enter: 'ENTER', Escape: 'ESC', Backspace: 'BKSP', Tab: 'TAB',
  };
  if (table[code]) return table[code];
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  if (code.startsWith('Numpad')) return 'NUM ' + code.slice(6);
  return code.toUpperCase();
}
