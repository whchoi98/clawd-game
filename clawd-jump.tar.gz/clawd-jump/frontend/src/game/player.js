/**
 * The player controller. Every number that matters lives in config.PHYS.
 *
 * Feel features, in the order a player notices them:
 *   • coyote time + jump buffering            — jumps land when you meant them
 *   • asymmetric gravity with an apex window  — snappy fall, generous peak
 *   • turn boost                              — direction changes bite immediately
 *   • corner correction                       — heads slide past 1-unit ledge lips
 *   • 8-way dash with a freeze frame          — reads as an impact, not a teleport
 *   • wall slide / wall jump with input lock  — the kick always visually lands
 *   • squash & stretch driven by real physics  — not a scripted animation
 */
import { PHYS, ASSIST, PLAYER_W, PLAYER_H, TILE, C } from './config.js';
import { clamp, clamp01, sign, approach, damp, hump, lerp, TAU, alpha } from '../core/util.js';
import { drawClawd, SKINS } from '../render/clawd.js';
import { particles } from '../render/particles.js';
import { audio } from '../core/audio.js';
import { settings } from '../core/save.js';
import { stage } from '../render/stage.js';

const TRAIL_N = 14;

export class Player {
  constructor(world) {
    this.world = world;
    this.w = PLAYER_W;
    this.h = PLAYER_H;
    this.skin = SKINS[world.skinId] || SKINS.clawd;
    this.trail = [];
    for (let i = 0; i < TRAIL_N; i++) this.trail.push({ x: 0, y: 0, a: 0, sx: 1, sy: 1, rot: 0, state: 'idle', facing: 1 });
    this.trailHead = 0;
    this.reset(world.level.start.x, world.level.start.y);
  }

  reset(x, y) {
    this.x = x - this.w / 2;
    this.y = y - this.h;
    this.vx = 0; this.vy = 0;
    this.facing = 1;
    this.grounded = false;
    this.wasGrounded = false;
    this.jumps = 0;
    this.coyote = 0;
    this.jumpBuf = -1;
    this.jumpHeld = false;
    this.dashBuf = -1;
    this.dashT = 0;
    this.dashCd = 0;
    this.dashReady = true;
    this.dashDirX = 1; this.dashDirY = 0;
    this.dashFlash = 0;
    this.wallDir = 0;
    this.wallStickT = 0;
    this.wallLock = 0;
    this.stomping = false;
    this.squash = 0;
    this.anim = 0;
    this.blink = 0;
    this.blinkT = 1.5;
    this.invuln = 0;
    this.hp = PHYS.maxHp;
    this.dead = false;
    this.deadT = 0;
    this.deadSpin = 0;
    this.inWater = false;
    // Must be seeded: an undefined value makes the first frame after every spawn
    // and respawn read as a water transition, splashing on dry land.
    this._wasWater = this.world.level.waterPx(x, y - this.h * 0.6);
    this.t = 0;
    this.alpha = 1;
    this.frozen = 0;
    this.spawnT = 0.42;
    for (const tr of this.trail) { tr.a = 0; tr.x = this.x; tr.y = this.y; }
  }

  // ------------------------------------------------------------------ query
  solidAt(x, y) { return this.world.level.solidPx(x, y); }

  /** Sample the three points along an edge; inset avoids catching on seams. */
  _edge(x, y, w, h, axis, dir) {
    const L = this.world.level;
    const i = 1.2;
    if (axis === 0) {
      const px = dir > 0 ? x + w : x;
      return L.solidPx(px, y + i) || L.solidPx(px, y + h / 2) || L.solidPx(px, y + h - i);
    }
    const py = dir > 0 ? y + h : y;
    return L.solidPx(x + i, py) || L.solidPx(x + w / 2, py) || L.solidPx(x + w - i, py);
  }

  checkGround() {
    const L = this.world.level;
    const y = this.y + this.h + 0.6;
    if (L.solidPx(this.x + 1.5, y) || L.solidPx(this.x + this.w / 2, y) || L.solidPx(this.x + this.w - 1.5, y)) return true;
    // one-way platforms count as ground when you are resting on the lip
    for (const px of [this.x + 1.5, this.x + this.w / 2, this.x + this.w - 1.5]) {
      const tx = Math.floor(px / TILE), ty = Math.floor(y / TILE);
      if (L.oneWay(tx, ty) && this.y + this.h <= ty * TILE + 2.5 && this.vy >= 0) return true;
    }
    return this.world.platformUnder(this) !== null;
  }

  // ------------------------------------------------------------------ update
  update(dt, input) {
    this.t += dt;
    const P = this.world.assist ? ASSIST_P : PHYS;

    if (this.dead) { this._updateDead(dt); return; }
    if (this.spawnT > 0) this.spawnT -= dt;

    // ---- blink ----
    this.blinkT -= dt;
    if (this.blinkT <= 0) { this.blinkT = 2 + Math.random() * 4; this.blink = 1; }
    this.blink = Math.max(0, this.blink - dt * 7);

    if (this.invuln > 0) this.invuln -= dt;
    if (this.dashCd > 0) this.dashCd -= dt;
    this.dashFlash = Math.max(0, this.dashFlash - dt * 3);
    if (this.wallLock > 0) this.wallLock -= dt;

    // ---- buffered inputs ----
    if (input.hit('jump')) this.jumpBuf = P.jumpBuffer;
    else if (this.jumpBuf > 0) this.jumpBuf -= dt;
    if (input.hit('dash')) this.dashBuf = PHYS.dashGrace;
    else if (this.dashBuf > 0) this.dashBuf -= dt;
    this.jumpHeld = input.down('jump');

    const ax = this.wallLock > 0 ? 0 : input.axisX;
    const ay = input.axisY;

    this.inWater = this.world.level.waterPx(this.x + this.w / 2, this.y + this.h * 0.4);

    // ---- dash ----
    if (this.dashT > 0) {
      this._updateDash(dt);
    } else {
      if (this.dashBuf > 0 && this.dashReady && this.dashCd <= 0 && !this.inWater) {
        this._startDash(ax, ay);
      } else {
        this._updateMove(dt, ax, ay, input, P);
      }
    }

    this._integrate(dt);
    this._postMove(dt, P);
    this._pushTrail();
  }

  _updateMove(dt, ax, ay, input, P) {
    const wasAir = !this.grounded;

    // ---------- horizontal ----------
    const maxRun = PHYS.maxRun * (this.inWater ? 0.72 : 1);
    if (ax !== 0) {
      this.facing = ax > 0 ? 1 : -1;
      const turning = sign(this.vx) !== 0 && sign(this.vx) !== sign(ax);
      let acc = this.grounded ? PHYS.accelGround : PHYS.accelAir;
      if (turning) acc *= PHYS.turnBoost;
      if (this.inWater) acc *= 0.6;
      this.vx = approach(this.vx, maxRun * ax, acc * dt);
    } else {
      const fr = this.grounded ? PHYS.frictionGround : PHYS.frictionAir;
      this.vx = approach(this.vx, 0, fr * dt * (this.inWater ? 1.8 : 1));
    }

    // ---------- wall detection ----------
    const touchL = this._edge(this.x - 1.2, this.y, this.w, this.h, 0, -1);
    const touchR = this._edge(this.x + 1.2, this.y, this.w, this.h, 0, 1);
    let wall = 0;
    if (!this.grounded && this.vy > -40) {
      if (touchL && ax <= 0) wall = -1;
      else if (touchR && ax >= 0) wall = 1;
      else if (touchL && this.wallDir === -1) wall = -1;
      else if (touchR && this.wallDir === 1) wall = 1;
    }
    if (wall !== 0) {
      this.wallDir = wall;
      this.wallStickT = PHYS.wallStick;
      this.facing = -wall;
    } else if (this.wallStickT > 0) {
      this.wallStickT -= dt;
      if (this.wallStickT <= 0) this.wallDir = 0;
    } else this.wallDir = 0;

    const sliding = this.wallDir !== 0 && this.vy > 0;

    // ---------- gravity ----------
    // `P` is the assist table when assist mode is on, so the assist gravity
    // constants are the single source of truth instead of a stray multiplier.
    let g;
    if (this.inWater) g = P.waterGrav;
    else if (this.vy < 0) g = this.jumpHeld ? P.gravity : P.gravity / P.jumpCut * 0.55;
    else g = P.gravityFall;
    if (Math.abs(this.vy) < P.apexWindow && !this.inWater) g = P.gravityApex;

    if (this.stomping) g = P.gravityFall * 2.2;
    this.vy += g * dt;

    const maxFall = this.inWater ? PHYS.terminalWater : sliding ? PHYS.wallSlide : this.stomping ? PHYS.stompVel : PHYS.maxFall;
    if (this.vy > maxFall) this.vy = approach(this.vy, maxFall, 2600 * dt);

    // ---------- variable jump cut ----------
    if (input.up_('jump') && this.vy < 0 && !this.inWater) this.vy *= PHYS.jumpCut;

    // ---------- coyote ----------
    if (this.grounded) this.coyote = PHYS.coyote;
    else if (this.coyote > 0) this.coyote -= dt;

    // ---------- jump ----------
    const maxJumps = this.world.assist ? ASSIST.maxJumps : PHYS.maxJumps;
    if (this.jumpBuf > 0) {
      if (this.wallDir !== 0) this._wallJump();
      else if (this.grounded || this.coyote > 0) this._jump(1);
      else if (this.inWater) { this.vy = PHYS.waterJump; this.jumpBuf = -1; audio.sfx('jump', { vol: 0.5 }); }
      else if (this.jumps < maxJumps) this._jump(2);
    }

    // ---------- stomp ----------
    if (!this.grounded && !this.inWater && ay > 0.6 && this.vy > -30 && !this.stomping) {
      this.stomping = true;
      this.vy = Math.max(this.vy, 120);
      particles.spark(this.x + this.w / 2, this.y + this.h, 5, C.shardHi, 90, Math.PI / 2, 1.1, 0.7);
    }
    if (this.stomping && (this.grounded || ay < 0.4)) this.stomping = false;

    // ---------- animation phase ----------
    if (this.grounded && Math.abs(this.vx) > 12) {
      this.anim += dt * (0.5 + Math.abs(this.vx) / PHYS.maxRun * 1.3) * 1.5;
      // footstep puffs
      const ph = this.anim % 0.5;
      if (ph < dt * 2 && Math.abs(this.vx) > 60) {
        particles.dust(this.x + this.w / 2 - this.facing * 3, this.y + this.h - 1, 2,
          this.facing > 0 ? Math.PI : 0, this.world.biome.crustHi, 34);
      }
    } else this.anim += dt * 0.3;

    // wall slide dust
    if (sliding && Math.random() < dt * 34) {
      particles.dust(this.x + (this.wallDir > 0 ? this.w : 0), this.y + this.h * (0.3 + Math.random() * 0.6),
        1, this.wallDir > 0 ? Math.PI : 0, this.world.biome.crustHi, 26);
    }
  }

  _jump(kind) {
    const P = PHYS;
    this.vy = kind === 1 ? P.jumpVel : P.jumpVel2;
    this.jumps = kind === 1 ? 1 : this.jumps + 1;
    this.grounded = false;
    this.coyote = 0;
    this.jumpBuf = -1;
    this.stomping = false;
    this.squash = -0.34;
    this.world.stats.jumps++;
    const cx = this.x + this.w / 2, cy = this.y + this.h;
    if (kind === 1) {
      audio.sfx('jump');
      particles.dust(cx, cy, 7, 0, this.world.biome.crustHi, 62);
    } else {
      audio.sfx('jump2');
      particles.ring(cx, cy - 3, 3, 15, 0.34, C.shardHi, 1.6, 1);
      particles.spark(cx, cy, 9, C.shardHi, 120, Math.PI / 2, 2.2, 1);
    }
  }

  _wallJump() {
    this.vx = PHYS.wallJumpX * -this.wallDir;
    this.vy = PHYS.wallJumpY;
    this.facing = -this.wallDir;
    this.jumps = 1;
    this.jumpBuf = -1;
    this.wallLock = PHYS.wallJumpLock;
    this.squash = -0.28;
    this.wallStickT = 0;
    this.world.stats.wallJumps++;
    audio.sfx('walljump');
    const wx = this.x + (this.wallDir > 0 ? this.w : 0);
    particles.dust(wx, this.y + this.h * 0.6, 8, this.wallDir > 0 ? Math.PI : 0, this.world.biome.crustHi, 90);
    particles.spark(wx, this.y + this.h * 0.6, 6, this.world.biome.crustHi, 130, this.wallDir > 0 ? Math.PI : 0, 1.4, 0.7);
    this.wallDir = 0;
  }

  _startDash(ax, ay) {
    let dx = ax, dy = ay;
    if (dx === 0 && dy === 0) { dx = this.facing; dy = 0; }
    const m = Math.hypot(dx, dy) || 1;
    dx /= m; dy /= m;
    // snap to 8 directions so diagonals are consistent
    const a = Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) * (Math.PI / 4);
    dx = Math.cos(a); dy = Math.sin(a);
    if (Math.abs(dx) < 0.01) dx = 0;
    if (Math.abs(dy) < 0.01) dy = 0;

    this.dashDirX = dx; this.dashDirY = dy;
    this.dashT = PHYS.dashTime;
    this.dashReady = false;
    this.dashBuf = -1;
    this.dashCd = this.world.assist ? ASSIST.dashCooldown : PHYS.dashCooldown;
    this.stomping = false;
    if (dx !== 0) this.facing = sign(dx);
    this.world.stats.dashes++;
    this.world.hitstop(0.055);
    this.world.shake(0.5);
    this.world.zoomPulse(0.035);
    audio.sfx('dash');
    const cx = this.x + this.w / 2, cy = this.y + this.h / 2;
    particles.ring(cx, cy, 4, 26, 0.32, this.skin.glow, 2.2, 1.2);
    particles.spark(cx, cy, 16, this.skin.glow, 230, Math.atan2(-dy, -dx), 1.5, 1.2);
  }

  _updateDash(dt) {
    this.dashT -= dt;
    this.vx = this.dashDirX * PHYS.dashSpeed;
    this.vy = this.dashDirY * PHYS.dashSpeed;
    if (this.dashT <= 0) {
      this.vx = this.dashDirX * PHYS.dashEndSpeed;
      this.vy = this.dashDirY * (this.dashDirY < 0 ? PHYS.dashEndSpeed * 0.72 : PHYS.dashEndSpeed * 0.4);
      this.dashT = 0;
    }
  }

  // ------------------------------------------------------------------ movement
  _integrate(dt) {
    const stepMax = 3.5;
    let mx = this.vx * dt, my = this.vy * dt;
    const steps = Math.max(1, Math.ceil(Math.max(Math.abs(mx), Math.abs(my)) / stepMax));
    const sx = mx / steps, sy = my / steps;
    for (let i = 0; i < steps; i++) {
      if (sx !== 0) this._moveX(sx);
      if (sy !== 0) this._moveY(sy);
    }
  }

  _moveX(d) {
    const nx = this.x + d;
    if (this._edge(nx, this.y, this.w, this.h, 0, d > 0 ? 1 : -1)) {
      // corner correction: a 2-unit lip should not stop a dash or a run
      for (const lift of [1, 2, 3]) {
        if (!this._edge(nx, this.y - lift, this.w, this.h, 0, d > 0 ? 1 : -1) &&
            !this._edge(nx, this.y - lift, this.w, this.h, 1, -1)) {
          this.y -= lift;
          this.x = nx;
          return;
        }
      }
      this.x = d > 0
        ? Math.floor((this.x + this.w + d) / TILE) * TILE - this.w - 0.01
        : Math.floor((this.x + d) / TILE) * TILE + TILE + 0.01;
      if (this.dashT > 0 && this.dashDirY === 0) {
        this.dashT = 0;
        this.world.shake(0.4);
        particles.spark(this.x + (d > 0 ? this.w : 0), this.y + this.h / 2, 8, this.world.biome.crustHi, 140,
          d > 0 ? Math.PI : 0, 1.6, 0.9);
      }
      this.vx = 0;
      return;
    }
    this.x = nx;
  }

  _moveY(d) {
    const L = this.world.level;
    const ny = this.y + d;
    if (d > 0) {
      // one-way platforms: only block when crossing the top edge
      let hitOneWay = false;
      for (const px of [this.x + 1.5, this.x + this.w / 2, this.x + this.w - 1.5]) {
        const ty = Math.floor((ny + this.h) / TILE);
        if (L.oneWay(Math.floor(px / TILE), ty) && this.y + this.h <= ty * TILE + 1.0) { hitOneWay = true; break; }
      }
      if (hitOneWay || this._edge(this.x, ny, this.w, this.h, 1, 1)) {
        this.y = Math.floor((this.y + this.h + d) / TILE) * TILE - this.h - 0.01;
        this._land();
        return;
      }
    } else if (this._edge(this.x, ny, this.w, this.h, 1, -1)) {
      // ceiling corner correction — nudge sideways past a 1-tile lip
      for (const nudge of [1, 2, 3, -1, -2, -3]) {
        if (!this._edge(this.x + nudge, ny, this.w, this.h, 1, -1)) {
          this.x += nudge;
          this.y = ny;
          return;
        }
      }
      this.y = Math.floor((this.y + d) / TILE) * TILE + TILE + 0.01;
      this.vy = Math.max(0, this.vy);
      if (this.dashT > 0) this.dashT = 0;
      particles.dust(this.x + this.w / 2, this.y, 4, -Math.PI / 2, this.world.biome.crustHi, 40);
      return;
    }
    this.y = ny;
  }

  _land() {
    const impact = clamp01(this.vy / 380);
    const wasStomp = this.stomping;
    this.vy = 0;
    if (!this.grounded) {
      this.squash = 0.2 + impact * 0.5 + (wasStomp ? 0.3 : 0);
      audio.sfx('land', { impact: impact + (wasStomp ? 0.4 : 0) });
      const cx = this.x + this.w / 2, cy = this.y + this.h;
      particles.dust(cx, cy, 4 + Math.round(impact * 12), 0, this.world.biome.crustHi, 40 + impact * 110);
      if (impact > 0.55 || wasStomp) {
        particles.ring(cx, cy, 2, 22 + impact * 18, 0.3, this.world.biome.crustHi, 1.8, 0.7);
        this.world.shake(0.35 + impact * 0.7 + (wasStomp ? 0.5 : 0));
      }
      if (wasStomp) {
        this.world.stompShock(cx, cy);
        particles.spark(cx, cy, 14, this.world.biome.crustHi, 200, 0, Math.PI, 0.8);
      }
    }
    this.grounded = true;
    this.stomping = false;
    this.jumps = 0;
    if (!this.dashReady) { this.dashReady = true; this.dashFlash = 1; }

    // crumbling tiles under the feet start their countdown
    const L = this.world.level;
    const fy = Math.floor((this.y + this.h + 1) / TILE);
    for (const px of [this.x + 1.5, this.x + this.w / 2, this.x + this.w - 1.5]) {
      L.touchCrumble(Math.floor(px / TILE), fy);
    }
  }

  _postMove(dt, P) {
    this.wasGrounded = this.grounded;
    this.grounded = this.dashT > 0 && this.dashDirY < 0 ? false : this.checkGround();
    if (this.grounded && this.vy >= 0) {
      this.jumps = 0;
      if (!this.dashReady && this.dashT <= 0) { this.dashReady = true; this.dashFlash = 1; }
    }
    if (this.grounded && !this.wasGrounded && this.vy > 60) this._land();

    // squash relaxes with a spring feel
    this.squash = damp(this.squash, 0, 0.055, dt);

    // ride moving platforms
    const plat = this.world.platformUnder(this);
    if (plat && this.vy >= 0) {
      this.x += plat.dx;
      this.y += plat.dy;
      this.grounded = true;
    }

    // out of bounds / hazards
    const cx = this.x + this.w / 2;
    if (this.y > this.world.level.pxH + 40) this.kill('pit');
    if (!this.world.invincible && this.invuln <= 0) {
      if (this.world.level.hazardPx(cx, this.y + this.h - 2) ||
          this.world.level.hazardPx(cx, this.y + 2) ||
          this.world.level.hazardPx(this.x + 1, this.y + this.h / 2) ||
          this.world.level.hazardPx(this.x + this.w - 1, this.y + this.h / 2)) {
        this.hurt(0, 'spike');
      }
    }

    // water splash + bubbles
    const nowWater = this.world.level.waterPx(cx, this.y + this.h * 0.4);
    if (nowWater !== this._wasWater) {
      particles.spark(cx, this.y + this.h * 0.4, 12, '#BFF0FF', 140, -Math.PI / 2, 2, 0.8);
      particles.dust(cx, this.y + this.h * 0.4, 6, 0, '#BFF0FF', 60);
      audio.sfx('land', { impact: 0.4 });
      this._wasWater = nowWater;
    }
    if (nowWater && Math.random() < dt * 8) {
      particles.mote(cx + (Math.random() - 0.5) * 8, this.y + this.h * 0.5, 0, -26, 0.9, '#CFF6FF', 1, 0.4);
    }
  }

  _pushTrail() {
    const tr = this.trail[this.trailHead];
    this.trailHead = (this.trailHead + 1) % TRAIL_N;
    tr.x = this.x; tr.y = this.y;
    tr.facing = this.facing;
    tr.state = this.dashT > 0 ? 'dash' : this.grounded ? 'run' : 'fall';
    tr.a = this.dashT > 0 ? 1 : Math.abs(this.vx) > 200 || Math.abs(this.vy) > 300 ? 0.45 : 0;
    tr.vx = this.vx; tr.vy = this.vy;
  }

  // ------------------------------------------------------------------ damage
  hurt(fromX, cause = 'hit') {
    if (this.dead || this.invuln > 0 || this.world.invincible) return;
    this.hp--;
    this.world.onHurt(this.hp);
    if (this.hp <= 0) { this.kill(cause); return; }
    this.invuln = this.world.assist ? ASSIST.hurtInvuln : PHYS.hurtInvuln;
    const dir = fromX === 0 ? -this.facing : sign(this.x + this.w / 2 - fromX) || 1;
    this.vx = PHYS.hurtKnockX * dir;
    this.vy = PHYS.hurtKnockY;
    this.grounded = false;
    this.dashT = 0;
    this.stomping = false;
    audio.sfx('hurt');
    this.world.hitstop(0.09);
    this.world.shake(1.1);
    this.world.flash(0.22, C.danger);
    const cx = this.x + this.w / 2, cy = this.y + this.h / 2;
    particles.spark(cx, cy, 18, C.dangerHi, 220, 0, TAU, 1.2);
    particles.ring(cx, cy, 3, 32, 0.4, C.danger, 2.4, 1.2);
  }

  kill(cause = 'hit') {
    if (this.dead) return;
    this.dead = true;
    this.deadT = 0;
    this.dashT = 0;
    this.vx = -this.facing * 40;
    this.vy = -190;
    audio.sfx('die');
    this.world.onDeath(cause);
    const cx = this.x + this.w / 2, cy = this.y + this.h / 2;
    particles.tri(cx, cy, 12, this.skin.shell, 190, 0.8);
    particles.spark(cx, cy, 22, this.skin.glow, 260, 0, TAU, 1.2);
    particles.ring(cx, cy, 3, 44, 0.55, this.skin.glow, 3, 1.4);
  }

  _updateDead(dt) {
    this.deadT += dt;
    // The respawn/game-over handler takes over long before this, but a paused
    // or backgrounded tab shouldn't let the corpse integrate forever.
    if (this.deadT > 2.5) return;
    this.vy += 900 * dt;
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.deadSpin += dt * 7 * -sign(this.vx || 1);
    this.alpha = clamp01(1 - this.deadT * 1.2);
    if (Math.random() < dt * 20) {
      particles.smoke(this.x + this.w / 2, this.y + this.h / 2, 1, this.skin.shell, 14, 3);
    }
  }

  // ------------------------------------------------------------------ render
  rig() {
    return {
      x: this.x + this.w / 2,
      y: this.y + this.h,
      vx: this.vx, vy: this.vy,
      grounded: this.grounded,
      facing: this.facing,
      state: this.dead ? 'dead'
        : this.dashT > 0 ? 'dash'
        : this.invuln > PHYS.hurtInvuln - 0.35 ? 'hurt'
        : this.wallDir !== 0 && !this.grounded ? 'wall'
        : !this.grounded ? (this.vy < 0 ? 'jump' : 'fall')
        : Math.abs(this.vx) > 14 ? 'run' : 'idle',
      t: this.t,
      anim: this.anim,
      squash: this.squash,
      invuln: this.invuln,
      blink: this.blink,
      skin: this.skin,
      dashReady: this.dashReady,
      dashFlash: this.dashFlash,
      deadSpin: this.dead ? this.deadSpin : 0,
      alpha: this.alpha,
    };
  }

  draw() {
    const ctx = stage.ctx, gctx = stage.gctx;

    // ---- afterimages ----
    for (let i = 0; i < TRAIL_N; i++) {
      const idx = (this.trailHead + i) % TRAIL_N;
      const tr = this.trail[idx];
      if (tr.a <= 0.01) continue;
      const age = i / TRAIL_N;                 // 0 = oldest
      const a = tr.a * age * age * 0.5;
      if (a < 0.02) continue;
      ctx.save();
      ctx.globalAlpha = a;
      ctx.globalCompositeOperation = 'lighter';
      ctx.fillStyle = this.skin.glow;
      ctx.beginPath();
      ctx.ellipse(tr.x + this.w / 2, tr.y + this.h / 2, 6.4, 5.6, 0, 0, TAU);
      ctx.fill();
      ctx.restore();
    }

    // ---- spawn-in warp ----
    if (this.spawnT > 0) {
      const k = 1 - this.spawnT / 0.42;
      ctx.save();
      ctx.globalAlpha = 1 - k;
      ctx.strokeStyle = this.skin.glow;
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(this.x + this.w / 2, this.y + this.h / 2, 6 + (1 - k) * 40, 0, TAU);
      ctx.stroke();
      ctx.restore();
    }

    // ---- ground shadow ----
    if (!this.dead) {
      const L = this.world.level;
      let gy = this.y + this.h;
      for (let i = 0; i < 9; i++) {
        if (L.solidPx(this.x + this.w / 2, gy + i * TILE)) { gy += i * TILE; break; }
        if (i === 8) gy = -1;
      }
      if (gy > 0) {
        const gd = clamp01(1 - (gy - this.y - this.h) / 120);
        const ty = Math.floor(gy / TILE) * TILE;
        ctx.save();
        ctx.globalAlpha = 0.3 * gd;
        ctx.fillStyle = '#000000';
        ctx.beginPath();
        ctx.ellipse(this.x + this.w / 2, ty + 1.5, 5.5 * (0.5 + gd * 0.5), 1.7 * gd, 0, 0, TAU);
        ctx.fill();
        ctx.restore();
      }
    }

    drawClawd(ctx, gctx, this.rig());
  }
}

// Assist-mode physics snapshot, built once.
const ASSIST_P = { ...PHYS, ...{
  gravity: PHYS.gravity * ASSIST.gravity,
  gravityFall: PHYS.gravityFall * ASSIST.gravityFall,
  gravityApex: PHYS.gravityApex * ASSIST.gravity,
  maxJumps: ASSIST.maxJumps,
  hurtInvuln: ASSIST.hurtInvuln,
  dashCooldown: ASSIST.dashCooldown,
} };
