/**
 * Static and semi-static level furniture. Everything exposes the same shape:
 *   { x, y, w, h, dead, update(dt, world), draw(t) }
 * plus optional `overlap(player, world)`.
 */
import { TILE, C, PHYS } from './config.js';
import { stage } from '../render/stage.js';
import { particles } from '../render/particles.js';
import { audio } from '../core/audio.js';
import { alpha, clamp01, lerp, damp, TAU, hump, mixHex, easeOutCubic, easeOutBack } from '../core/util.js';
import { settings } from '../core/save.js';

const G = () => stage.gctx;

// ============================================================ SHARD
export class Shard {
  constructor(sp) {
    this.x = sp.x; this.y = sp.y;
    this.hx = sp.x; this.hy = sp.y;
    this.w = 9; this.h = 9;
    this.ph = (sp.tx * 3 + sp.ty * 7) % 100;
    this.taken = false;
    this.dead = false;
    this.pop = 0;
  }
  update(dt, world) {
    if (this.taken) { this.pop += dt; if (this.pop > 0.4) this.dead = true; return; }
    this.ph += dt;
    const p = world.player;
    const cx = p.x + p.w / 2, cy = p.y + p.h / 2;
    const d = Math.hypot(cx - this.hx, cy - this.hy);
    // gentle magnetism makes collection feel generous without widening the hitbox
    if (d < 34) {
      const k = 1 - d / 34;
      this.x = lerp(this.x, cx, k * k * 0.42);
      this.y = lerp(this.y, cy, k * k * 0.42);
    } else {
      this.x = damp(this.x, this.hx, 0.12, dt);
      this.y = damp(this.y, this.hy, 0.12, dt);
    }
    if (d < 11) this.collect(world);
  }
  collect(world) {
    this.taken = true;
    world.onShard(this.x, this.y);
  }
  draw(t) {
    if (this.taken) {
      const k = clamp01(this.pop / 0.4);
      const ctx = stage.ctx;
      ctx.save();
      ctx.globalAlpha = 1 - k;
      ctx.strokeStyle = C.shardHi;
      ctx.lineWidth = 1.6 * (1 - k);
      ctx.beginPath(); ctx.arc(this.x, this.y, 5 + k * 22, 0, TAU); ctx.stroke();
      ctx.restore();
      return;
    }
    const ctx = stage.ctx, gctx = G();
    const bob = Math.sin(this.ph * 2.1) * 2.2;
    const spin = this.ph * 2.4;
    const sc = 1 + Math.sin(this.ph * 3.3) * 0.06;
    const x = this.x, y = this.y + bob;

    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(Math.sin(spin) * 0.35);
    ctx.scale(sc * (0.55 + 0.45 * Math.abs(Math.cos(spin))), sc);
    const g = ctx.createLinearGradient(-4, -6, 4, 6);
    g.addColorStop(0, '#FFFFFF');
    g.addColorStop(0.35, C.shardHi);
    g.addColorStop(1, '#2196A8');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(0, -6.2); ctx.lineTo(3.6, 0); ctx.lineTo(0, 6.2); ctx.lineTo(-3.6, 0);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = alpha('#FFFFFF', 0.75);
    ctx.lineWidth = 0.5;
    ctx.stroke();
    ctx.fillStyle = alpha('#FFFFFF', 0.55);
    ctx.beginPath();
    ctx.moveTo(0, -5); ctx.lineTo(1.6, -0.6) ; ctx.lineTo(0, 2); ctx.lineTo(-1.4, -0.6);
    ctx.closePath(); ctx.fill();
    ctx.restore();

    if (settings.bloom) {
      const pulse = 0.55 + 0.45 * Math.sin(this.ph * 3.1);
      gctx.fillStyle = alpha(C.shard, 0.3 * pulse);
      gctx.beginPath(); gctx.arc(x, y, 4.6, 0, TAU); gctx.fill();
    }
  }
}

// ============================================================ RELIC
export class Relic {
  constructor(sp) {
    this.x = sp.x; this.y = sp.y; this.w = 14; this.h = 14;
    this.ph = (sp.tx * 5) % 100;
    this.taken = false; this.dead = false; this.pop = 0;
    this.idx = 0;
  }
  update(dt, world) {
    this.ph += dt;
    if (this.taken) { this.pop += dt; if (this.pop > 0.7) this.dead = true; return; }
    const p = world.player;
    if (Math.abs(p.x + p.w / 2 - this.x) < 12 && Math.abs(p.y + p.h / 2 - this.y) < 12) {
      this.taken = true;
      world.onRelic(this);
    }
  }
  draw(t) {
    const ctx = stage.ctx, gctx = G();
    if (this.taken) {
      const k = clamp01(this.pop / 0.7);
      ctx.save();
      ctx.globalAlpha = 1 - k;
      ctx.strokeStyle = C.relicHi;
      ctx.lineWidth = 2.4 * (1 - k);
      ctx.beginPath(); ctx.arc(this.x, this.y, 6 + easeOutCubic(k) * 46, 0, TAU); ctx.stroke();
      ctx.restore();
      return;
    }
    const bob = Math.sin(this.ph * 1.6) * 3;
    const y = this.y + bob;
    ctx.save();
    ctx.translate(this.x, y);
    // orbiting motes
    for (let i = 0; i < 3; i++) {
      const a = this.ph * 1.7 + (i / 3) * TAU;
      const ox = Math.cos(a) * 11, oy = Math.sin(a) * 4.5;
      ctx.fillStyle = alpha(C.relicHi, 0.55 + 0.35 * Math.sin(a * 2));
      ctx.beginPath(); ctx.arc(ox, oy, 1.2, 0, TAU); ctx.fill();
    }
    ctx.rotate(Math.sin(this.ph) * 0.18);
    const g = ctx.createLinearGradient(-7, -7, 7, 7);
    g.addColorStop(0, '#FFF8DC');
    g.addColorStop(0.4, C.relic);
    g.addColorStop(1, '#A87418');
    ctx.fillStyle = g;
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * TAU - Math.PI / 2;
      const r = i % 2 === 0 ? 7.4 : 5.2;
      const px = Math.cos(a) * r, py = Math.sin(a) * r;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = alpha('#FFFDF0', 0.8);
    ctx.lineWidth = 0.6; ctx.stroke();
    ctx.fillStyle = alpha('#FFFFFF', 0.6);
    ctx.beginPath(); ctx.ellipse(-1.8, -2.2, 2.2, 1.3, -0.6, 0, TAU); ctx.fill();
    ctx.restore();

    if (settings.bloom) {
      const pulse = 0.6 + 0.4 * Math.sin(this.ph * 2.4);
      gctx.fillStyle = alpha(C.relic, 0.42 * pulse);
      gctx.beginPath(); gctx.arc(this.x, y, 8.5, 0, TAU); gctx.fill();
    }
  }
}

// ============================================================ CHECKPOINT
export class Checkpoint {
  constructor(sp) {
    this.x = sp.x; this.y = sp.ty * TILE + TILE;
    this.w = 16; this.h = 28;
    this.on = false;
    this.ph = 0; this.lit = 0;
    this.dead = false;
  }
  update(dt, world) {
    this.ph += dt;
    this.lit = damp(this.lit, this.on ? 1 : 0, 0.12, dt);
    if (this.on) return;
    const p = world.player;
    if (Math.abs(p.x + p.w / 2 - this.x) < 16 && Math.abs(p.y + p.h - this.y) < 26) {
      this.on = true;
      world.onCheckpoint(this);
    }
  }
  draw(t) {
    const ctx = stage.ctx, gctx = G();
    const x = this.x, y = this.y;
    // pillar
    const g = ctx.createLinearGradient(x - 3, 0, x + 3, 0);
    g.addColorStop(0, '#4A4258'); g.addColorStop(0.5, '#8D839F'); g.addColorStop(1, '#332C40');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.roundRect(x - 2.6, y - 24, 5.2, 24, 2); ctx.fill();
    ctx.fillStyle = '#2A2434';
    ctx.beginPath(); ctx.ellipse(x, y, 7, 2.4, 0, 0, TAU); ctx.fill();

    // crystal head
    const lit = this.lit;
    const col = lit > 0.5 ? C.checkpoint : '#6C6480';
    const pulse = 0.7 + 0.3 * Math.sin(this.ph * (lit > 0.5 ? 4 : 1.6));
    ctx.save();
    ctx.translate(x, y - 27 + Math.sin(this.ph * 1.8) * (0.6 + lit));
    ctx.rotate(this.ph * (0.4 + lit * 1.4));
    const cg = ctx.createLinearGradient(-5, -5, 5, 5);
    cg.addColorStop(0, lit > 0.5 ? '#FFFFFF' : '#9A93AC');
    cg.addColorStop(1, col);
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.moveTo(0, -6); ctx.lineTo(4.4, 0); ctx.lineTo(0, 6); ctx.lineTo(-4.4, 0);
    ctx.closePath(); ctx.fill();
    ctx.restore();

    if (lit > 0.02) {
      // rising light ribbons when active
      for (let i = 0; i < 3; i++) {
        const ph = (this.ph * 0.7 + i / 3) % 1;
        ctx.strokeStyle = alpha(C.checkpoint, (1 - ph) * 0.5 * lit);
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(x, y - 4 - ph * 30, 4 + ph * 8, 0, Math.PI, true);
        ctx.stroke();
      }
      if (settings.bloom) {
        gctx.fillStyle = alpha(C.checkpoint, 0.6 * lit * pulse);
        gctx.beginPath(); gctx.arc(x, y - 27, 14, 0, TAU); gctx.fill();
      }
    }
  }
}

// ============================================================ GOAL
export class Goal {
  constructor(sp) {
    this.x = sp.x; this.y = sp.ty * TILE + TILE;
    this.w = 22; this.h = 34;
    this.ph = 0; this.open = 0; this.dead = false;
    this.taken = false;
  }
  update(dt, world) {
    this.ph += dt;
    this.open = damp(this.open, 1, 0.4, dt);
    if (this.taken) return;
    const p = world.player;
    if (Math.abs(p.x + p.w / 2 - this.x) < 14 && Math.abs(p.y + p.h - this.y) < 30) {
      this.taken = true;
      world.onGoal();
    }
  }
  draw(t) {
    const ctx = stage.ctx, gctx = G();
    const x = this.x, y = this.y - 18;
    const k = this.open;

    // swirling portal — layered arcs rotating at different rates
    ctx.save();
    ctx.translate(x, y);
    for (let i = 4; i >= 0; i--) {
      const r = (5 + i * 3.4) * k;
      const a0 = this.ph * (1.1 + i * 0.5) + i;
      ctx.strokeStyle = alpha(i % 2 ? C.goal : C.relicHi, 0.28 + 0.14 * (4 - i));
      ctx.lineWidth = 1.6 - i * 0.16;
      ctx.beginPath();
      ctx.ellipse(0, 0, r, r * 1.28, 0, a0, a0 + 2.4 + i * 0.3);
      ctx.stroke();
    }
    const core = ctx.createRadialGradient(0, 0, 0, 0, 0, 9 * k);
    core.addColorStop(0, alpha('#FFFFFF', 0.9));
    core.addColorStop(0.4, alpha(C.goal, 0.6));
    core.addColorStop(1, alpha(C.goal, 0));
    ctx.fillStyle = core;
    ctx.beginPath(); ctx.arc(0, 0, 10 * k, 0, TAU); ctx.fill();
    ctx.restore();

    // base ring
    ctx.strokeStyle = alpha(C.goal, 0.5);
    ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.ellipse(x, this.y, 12, 3.4, 0, 0, TAU); ctx.stroke();

    if (settings.bloom) {
      gctx.fillStyle = alpha(C.goal, 0.55);
      gctx.beginPath(); gctx.arc(x, y, 20 * k, 0, TAU); gctx.fill();
    }
  }
}

// ============================================================ SPRING
export class Spring {
  constructor(sp) {
    this.x = sp.x; this.y = sp.ty * TILE + TILE;
    this.w = 14; this.h = 8;
    this.c = 0; this.cool = 0; this.dead = false;
  }
  update(dt, world) {
    this.c = damp(this.c, 0, 0.07, dt);
    if (this.cool > 0) { this.cool -= dt; return; }
    const p = world.player;
    if (p.vy >= -10 &&
        Math.abs(p.x + p.w / 2 - this.x) < 12 &&
        p.y + p.h >= this.y - 9 && p.y + p.h <= this.y + 5) {
      p.vy = PHYS.springVel;
      p.y = this.y - 10 - p.h;
      p.grounded = false;
      p.jumps = 0;
      p.stomping = false;
      p.dashReady = true;
      p.squash = -0.4;
      this.c = 1;
      this.cool = 0.15;
      audio.sfx('spring');
      world.shake(0.5);
      particles.ring(this.x, this.y - 4, 3, 26, 0.32, C.spring, 2, 1);
      particles.spark(this.x, this.y - 4, 12, C.spring, 190, -Math.PI / 2, 1.7, 1);
    }
  }
  draw(t) {
    const ctx = stage.ctx, gctx = G();
    const c = this.c;
    const top = this.y - 9 + c * 6;
    ctx.save();
    // base
    ctx.fillStyle = '#3A3448';
    ctx.beginPath(); ctx.roundRect(this.x - 8, this.y - 3.5, 16, 3.5, 1.5); ctx.fill();
    // coil
    ctx.strokeStyle = '#8D839F';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    const coils = 3;
    for (let i = 0; i <= coils * 8; i++) {
      const u = i / (coils * 8);
      const yy = lerp(this.y - 3.5, top + 2, u);
      const xx = this.x + Math.sin(u * coils * TAU) * 5.4;
      if (i === 0) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy);
    }
    ctx.stroke();
    // pad
    const g = ctx.createLinearGradient(0, top - 3, 0, top + 3);
    g.addColorStop(0, '#D8FFC0'); g.addColorStop(0.5, C.spring); g.addColorStop(1, '#3E8F2A');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.roundRect(this.x - 8.5, top - 2.6, 17, 5.2, 2.6); ctx.fill();
    ctx.fillStyle = alpha('#FFFFFF', 0.5);
    ctx.beginPath(); ctx.roundRect(this.x - 6.5, top - 1.8, 13, 1.5, 1); ctx.fill();
    ctx.restore();
    if (settings.bloom) {
      gctx.fillStyle = alpha(C.spring, 0.3 + c * 0.5);
      gctx.beginPath(); gctx.ellipse(this.x, top, 12, 5, 0, 0, TAU); gctx.fill();
    }
  }
}

// ============================================================ MOVING PLATFORM
export class MovePlat {
  constructor(sp, level, vertical) {
    this.vertical = vertical;
    this.w = 3 * TILE; this.h = 6;
    this.x0 = sp.tx * TILE;
    this.y0 = sp.ty * TILE + TILE / 2;
    const span = vertical
      ? Math.max(TILE * 2, level.patrolSpan(sp.tx, sp.ty, 0, 1, 8))
      : Math.max(TILE * 2, level.patrolSpan(sp.tx, sp.ty, 1, 0, 8));
    this.span = span;
    this.ph = ((sp.tx + sp.ty) % 4) / 4 * TAU;
    this.speed = 0.62;
    this.x = this.x0; this.y = this.y0;
    this.dx = 0; this.dy = 0;
    this.dead = false;
  }
  update(dt, world) {
    this.ph += dt * this.speed;
    const k = (1 - Math.cos(this.ph)) / 2;   // eased ping-pong
    const nx = this.vertical ? this.x0 : this.x0 + k * this.span;
    const ny = this.vertical ? this.y0 + k * this.span : this.y0;
    this.dx = nx - this.x; this.dy = ny - this.y;
    this.x = nx; this.y = ny;
  }
  draw(t) {
    const ctx = stage.ctx, gctx = G();
    const x = this.x, y = this.y;
    ctx.save();
    // rail guide
    ctx.strokeStyle = alpha('#FFFFFF', 0.08);
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 4]);
    ctx.beginPath();
    if (this.vertical) { ctx.moveTo(x + this.w / 2, this.y0); ctx.lineTo(x + this.w / 2, this.y0 + this.span); }
    else { ctx.moveTo(this.x0, y + 2); ctx.lineTo(this.x0 + this.span + this.w, y + 2); }
    ctx.stroke();
    ctx.setLineDash([]);

    const g = ctx.createLinearGradient(0, y - 3, 0, y + 5);
    g.addColorStop(0, '#C9C2D8'); g.addColorStop(0.4, '#8D839F'); g.addColorStop(1, '#39334A');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.roundRect(x, y - 3, this.w, 7, 3); ctx.fill();
    ctx.fillStyle = alpha(C.shard, 0.85);
    for (let i = 0; i < 3; i++) ctx.fillRect(x + 6 + i * 16, y - 1.6, 4, 1.4);
    ctx.restore();
    if (settings.bloom) {
      gctx.fillStyle = alpha(C.shard, 0.3);
      gctx.fillRect(x + 4, y - 2, this.w - 8, 3);
    }
  }
}

// ============================================================ SAW
export class Saw {
  constructor(sp, level) {
    this.cx = sp.x; this.cy = sp.y;
    const spanR = level.patrolSpan(sp.tx, sp.ty, 1, 0, 7);
    const spanL = level.patrolSpan(sp.tx, sp.ty, -1, 0, 7);
    const spanD = level.patrolSpan(sp.tx, sp.ty, 0, 1, 7);
    this.vertical = spanR + spanL < TILE * 1.5 && spanD > TILE;
    this.a = this.vertical ? this.cy : this.cx - spanL;
    this.b = this.vertical ? this.cy + spanD : this.cx + spanR;
    this.ph = ((sp.tx * 3 + sp.ty * 5) % 7) / 7 * TAU;
    this.r = 9.5;
    this.w = 19; this.h = 19;
    this.x = this.cx; this.y = this.cy;
    this.spin = 0;
    this.dead = false;
  }
  update(dt, world) {
    this.ph += dt * 0.9;
    this.spin += dt * 14;
    const k = (1 - Math.cos(this.ph)) / 2;
    if (this.vertical) { this.x = this.cx; this.y = lerp(this.a, this.b, k); }
    else { this.x = lerp(this.a, this.b, k); this.y = this.cy; }
    const p = world.player;
    if (Math.hypot(p.x + p.w / 2 - this.x, p.y + p.h / 2 - this.y) < this.r + 4.5) p.hurt(this.x, 'saw');
  }
  draw(t) {
    const ctx = stage.ctx, gctx = G();
    ctx.save();
    // path guide
    ctx.strokeStyle = alpha('#FF6B7A', 0.1);
    ctx.lineWidth = 1.4;
    ctx.setLineDash([2, 5]);
    ctx.beginPath();
    if (this.vertical) { ctx.moveTo(this.cx, this.a); ctx.lineTo(this.cx, this.b); }
    else { ctx.moveTo(this.a, this.cy); ctx.lineTo(this.b, this.cy); }
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.translate(this.x, this.y);
    ctx.rotate(this.spin);
    const teeth = 10;
    const g = ctx.createRadialGradient(0, 0, 1, 0, 0, this.r);
    g.addColorStop(0, '#F2ECF8'); g.addColorStop(0.6, '#B6ACC6'); g.addColorStop(1, '#6B6180');
    ctx.fillStyle = g;
    ctx.beginPath();
    for (let i = 0; i < teeth * 2; i++) {
      const a = (i / (teeth * 2)) * TAU;
      const r = i % 2 === 0 ? this.r : this.r * 0.72;
      const px = Math.cos(a) * r, py = Math.sin(a) * r;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#2E2838';
    ctx.beginPath(); ctx.arc(0, 0, this.r * 0.3, 0, TAU); ctx.fill();
    ctx.strokeStyle = alpha(C.danger, 0.6);
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(0, 0, this.r * 0.5, 0, TAU); ctx.stroke();
    ctx.restore();

    if (settings.bloom) {
      gctx.fillStyle = alpha(C.danger, 0.2);
      gctx.beginPath(); gctx.arc(this.x, this.y, this.r * 1.3, 0, TAU); gctx.fill();
    }
  }
}

// ============================================================ UPDRAFT
export class Updraft {
  constructor(sp, level) {
    this.x = sp.tx * TILE;
    this.h = Math.max(TILE * 3, level.patrolSpan(sp.tx, sp.ty, 0, -1, 12) + TILE);
    this.y = sp.ty * TILE + TILE - this.h;
    this.w = TILE;
    this.ph = 0;
    this.dead = false;
    this.streaks = [];
    for (let i = 0; i < 7; i++) this.streaks.push({ x: Math.random(), y: Math.random(), s: 0.5 + Math.random() });
  }
  update(dt, world) {
    this.ph += dt;
    for (const s of this.streaks) {
      s.y -= dt * s.s * 0.9;
      if (s.y < 0) { s.y = 1; s.x = Math.random(); }
    }
    const p = world.player;
    if (p.x + p.w > this.x && p.x < this.x + this.w && p.y + p.h > this.y && p.y < this.y + this.h) {
      p.vy = Math.max(-260, p.vy - 900 * dt);
      p.stomping = false;
      if (Math.random() < dt * 20) {
        particles.mote(p.x + p.w / 2 + (Math.random() - 0.5) * 10, p.y + p.h, 0, -140, 1, '#DFF6FF', 0.5, 0.6);
      }
    }
  }
  draw(t) {
    const ctx = stage.ctx, gctx = G();
    ctx.save();
    const g = ctx.createLinearGradient(0, this.y + this.h, 0, this.y);
    g.addColorStop(0, alpha('#BFF0FF', 0.16));
    g.addColorStop(1, alpha('#BFF0FF', 0));
    ctx.fillStyle = g;
    ctx.fillRect(this.x, this.y, this.w, this.h);
    ctx.strokeStyle = alpha('#DFF6FF', 0.5);
    ctx.lineWidth = 0.9;
    for (const s of this.streaks) {
      const x = this.x + 2 + s.x * (this.w - 4);
      const y = this.y + s.y * this.h;
      ctx.globalAlpha = 0.5 * Math.sin(s.y * Math.PI);
      ctx.beginPath();
      ctx.moveTo(x, y); ctx.lineTo(x, y - 7 * s.s);
      ctx.stroke();
    }
    ctx.restore();
    if (settings.bloom) {
      gctx.fillStyle = alpha('#BFF0FF', 0.08);
      gctx.fillRect(this.x, this.y, this.w, this.h);
    }
  }
}
