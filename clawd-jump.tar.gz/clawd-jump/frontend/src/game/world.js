/**
 * World = one level instance. Owns the camera, the entity lists, the
 * feedback bus (shake / hitstop / flash / zoom) and the run statistics.
 *
 * Camera notes: X and Y are damped with different half-lives and the vertical
 * axis is *ground-locked* — it only follows the player's feet while they are
 * supported. Without that, every jump drags the whole screen up and down and
 * the game reads as nauseating no matter how good the platforming is.
 */
import { TILE, BIOMES, C, PHYS, rankFor } from './config.js';
import { Level } from './level.js';
import { Player } from './player.js';
import { Terrain } from '../render/tiles.js';
import { sky } from '../render/sky.js';
import { particles } from '../render/particles.js';
import { stage, VIEW_W, VIEW_H } from '../render/stage.js';
import { audio } from '../core/audio.js';
import { settings } from '../core/save.js';
import { clamp, clamp01, damp, lerp, TAU, alpha, easeOutCubic } from '../core/util.js';
import { Shard, Relic, Checkpoint, Goal, Spring, MovePlat, Saw, Updraft } from './entities.js';
import { FOE_BY_CH, Spiker, Bolt } from './enemies.js';

export class World {
  constructor(def, opts = {}) {
    this.level = new Level(def);
    this.biome = BIOMES[def.biome] || BIOMES.coral;
    this.skinId = opts.skin || 'clawd';
    // Read live rather than snapshotted: toggling either in the settings panel
    // mid-level used to do nothing until the next restart, with no hint why.
    this.onEvent = opts.onEvent || (() => {});

    sky.setBiome(this.biome, this.level.seed);
    this.terrain = new Terrain(this.level, this.biome);

    this.t = 0;
    this.runT = 0;
    this.phase = 'intro';
    this.phaseT = 0;

    this.trauma = 0;
    this.hitstopT = 0;
    this.flashA = 0;
    this.flashCol = '#ffffff';
    this.fade = 1;
    this.fadeTarget = 0;
    this.zoom = 1;
    this.zoomTarget = 1;
    this.aberr = 0;
    this.timeScale = 1;

    this.stats = { shards: 0, relics: 0, deaths: 0, jumps: 0, dashes: 0, wallJumps: 0, foes: 0, combo: 0, bestCombo: 0 };
    this.comboT = 0;

    this.entities = [];
    this.foes = [];
    this.bolts = [];
    this.plats = [];
    this.respawn = { x: this.level.start.x, y: this.level.start.y };

    // Endless mode: a rising tide chases the player up the tower.
    this.endless = !!def.endless;
    if (this.endless) {
      this.baseY = (def.baseY ?? this.level.h - 4) * TILE;
      this.floodY = this.baseY + TILE * 6;
      this.floodSpeed = 11;
      this.height = 0;
      this.maxHeight = 0;
      this.gameOver = false;
    }

    this._spawnAll();
    this.player = new Player(this);

    this.camX = this.player.x + this.player.w / 2;
    this.camY = this.player.y - 12;
    this.camGroundY = this.camY;
    this.cleared = false;
  }

  get assist() { return !!settings.assist; }
  get invincible() { return !!settings.invincible; }

  // ------------------------------------------------------------------ setup
  _spawnAll() {
    const L = this.level;
    for (const sp of L.spawns) {
      switch (sp.ch) {
        case 'o': this.entities.push(new Shard(sp)); break;
        case 'R': this.entities.push(new Relic(sp)); break;
        case 'C': this.entities.push(new Checkpoint(sp)); break;
        case 'G': this.goal = new Goal(sp); this.entities.push(this.goal); break;
        case 'S': this.entities.push(new Spring(sp)); break;
        case 'm': { const p = new MovePlat(sp, L, false); this.plats.push(p); this.entities.push(p); break; }
        case 'M': { const p = new MovePlat(sp, L, true); this.plats.push(p); this.entities.push(p); break; }
        case 's': this.entities.push(new Saw(sp, L)); break;
        case 'z': this.entities.push(new Updraft(sp, L)); break;
        case 'w': case 'h': case 'f': case 't': case 'c': {
          const Cls = FOE_BY_CH[sp.ch];
          const foe = new Cls(sp);
          this.foes.push(foe);
          break;
        }
      }
    }
    // levels can opt into armoured walkers via def.spikers = [[tx,ty],...]
    for (const [tx, ty] of this.level.def.spikers || []) {
      this.foes.push(new Spiker({ x: tx * TILE + TILE / 2, y: ty * TILE + TILE / 2, tx, ty }));
    }
    // Capture the real starting hp: restoring `hp || 1` gave 2-hp foes (turrets,
    // chasers) only 1 hp after a respawn, so they got easier every death.
    this._foeSeed = this.foes.map((f) => ({ f, x: f.x, y: f.y, face: f.face, hp: f.hp }));
  }

  // ------------------------------------------------------------------ fx bus
  shake(a) { this.trauma = Math.min(1.6, this.trauma + a * (settings.shake ?? 1)); }
  hitstop(s) { this.hitstopT = Math.max(this.hitstopT, s); }
  flash(a, col = '#ffffff') { this.flashA = Math.max(this.flashA, a); this.flashCol = col; this.aberr = Math.max(this.aberr, a * 2); }
  zoomPulse(a) { this.zoomTarget = 1 + a * (settings.shake ?? 1); }

  /** Stomp shockwave: damages nearby grounded foes. */
  stompShock(x, y) {
    particles.ring(x, y, 4, 46, 0.34, this.biome.crustHi, 2.4, 0.9);
    for (const f of this.foes) {
      if (f.dead || f.dying > 0) continue;
      if (Math.abs(f.x - x) < 34 && Math.abs(f.y - y) < 22) f.damage(this, 1);
    }
  }

  // ------------------------------------------------------------------ events
  onShard(x, y) {
    this.stats.shards++;
    this.stats.combo++;
    this.comboT = 2.2;
    this.stats.bestCombo = Math.max(this.stats.bestCombo, this.stats.combo);
    audio.sfx('shard', { combo: this.stats.combo - 1 });
    particles.spark(x, y, 10, C.shardHi, 150, 0, TAU, 1.1);
    particles.ring(x, y, 2, 16, 0.26, C.shardHi, 1.4, 1);
    if (this.stats.combo > 2) particles.text(x, y - 10, `×${this.stats.combo}`, C.shardHi, 0.8);
    this.onEvent('shard', { n: this.stats.shards, total: this.level.totalShards, combo: this.stats.combo });
  }

  onRelic(r) {
    this.stats.relics++;
    audio.sfx('relic');
    this.hitstop(0.11);
    this.shake(0.7);
    this.flash(0.3, C.relicHi);
    this.timeScale = 0.35;
    particles.spark(r.x, r.y, 26, C.relicHi, 240, 0, TAU, 1.3);
    particles.ring(r.x, r.y, 3, 60, 0.6, C.relic, 3, 1.4);
    this.player.dashReady = true;
    this.onEvent('relic', { n: this.stats.relics, total: this.level.totalRelics });
  }

  onCheckpoint(c) {
    this.respawn = { x: c.x, y: c.y };
    audio.sfx('checkpoint');
    this.flash(0.14, C.checkpoint);
    particles.ring(c.x, c.y - 20, 4, 40, 0.5, C.checkpoint, 2, 1.2);
    this.onEvent('checkpoint', {});
  }

  onGoal() {
    if (this.cleared) return;
    this.cleared = true;
    this.phase = 'clear';
    this.phaseT = 0;
    this.timeScale = 0.3;
    audio.sfx('goal');
    this.flash(0.4, C.goal);
    this.shake(0.8);
    for (let i = 0; i < 5; i++) {
      particles.ring(this.goal.x, this.goal.y - 18, 3 + i * 6, 70 + i * 18, 0.7 + i * 0.1, i % 2 ? C.goal : C.relicHi, 2.2, 1.2);
    }
    particles.spark(this.goal.x, this.goal.y - 18, 40, C.goal, 260, 0, TAU, 1.4);
    this.onEvent('goal', this.summary());
  }

  onHurt(hp) { this.onEvent('hurt', { hp }); }

  onDeath(cause) {
    this.stats.deaths++;
    this.phase = 'dying';
    this.phaseT = 0;
    this.stats.combo = 0;
    this.shake(1.2);
    this.flash(0.3, '#ffffff');
    this.onEvent('death', { cause, deaths: this.stats.deaths });
  }

  onFoeKilled(f) {
    this.stats.foes++;
    this.hitstop(0.04);
    particles.text(f.x, f.y - 8, '+', C.enemyHi, 0.55, 0.8);
  }

  spawnBolt(x, y, vx, vy) { this.bolts.push(new Bolt(x, y, vx, vy)); }

  endlessSummary() {
    return {
      height: Math.floor(this.maxHeight),
      shards: this.stats.shards,
      relics: this.stats.relics,
      foes: this.stats.foes,
      time: this.runT,
      bestCombo: this.stats.bestCombo,
    };
  }

  summary() {
    const L = this.level;
    return {
      id: L.id,
      time: this.runT,
      shards: this.stats.shards,
      totalShards: L.totalShards,
      relics: this.stats.relics,
      totalRelics: L.totalRelics,
      deaths: this.stats.deaths,
      par: L.par,
      rank: rankFor(this.runT, L.par, this.stats.shards, L.totalShards, this.stats.deaths),
    };
  }

  // ------------------------------------------------------------------ helpers
  platformUnder(p) {
    for (const pl of this.plats) {
      if (p.x + p.w > pl.x + 1 && p.x < pl.x + pl.w - 1 &&
          p.y + p.h >= pl.y - 4 && p.y + p.h <= pl.y + 5 && p.vy >= -1) {
        p.y = pl.y - 3 - p.h;
        return pl;
      }
    }
    return null;
  }

  // ------------------------------------------------------------------ update
  update(dtRaw, input) {
    const dtWall = Math.min(dtRaw, 1 / 20);
    this.t += dtWall;

    // hitstop freezes simulation but not presentation
    if (this.hitstopT > 0) {
      this.hitstopT -= dtWall;
      this._decayFx(dtWall);
      this._camera(dtWall * 0.2);
      return;
    }

    this.timeScale = damp(this.timeScale, 1, 0.22, dtWall);
    const dt = dtWall * this.timeScale;

    switch (this.phase) {
      case 'intro':
        this.phaseT += dtWall;
        this.fadeTarget = 0;
        if (this.phaseT > 0.45) { this.phase = 'play'; input.reset(); }
        break;
      case 'play':
        this.runT += dt;
        break;
      case 'dying':
        this.phaseT += dtWall;
        if (this.phaseT > 0.7) { this.fadeTarget = 1; }
        if (this.phaseT > 1.05) {
          if (this.endless) {
            if (!this.gameOver) { this.gameOver = true; this.onEvent('endlessOver', this.endlessSummary()); }
          } else this._doRespawn(input);
        }
        break;
      case 'clear':
        this.phaseT += dtWall;
        break;
    }

    if (this.phase === 'play' || this.phase === 'clear') {
      this.player.update(dt, input);
    } else if (this.phase === 'dying') {
      this.player.update(dt, input);
    }

    // entities
    for (let i = this.entities.length - 1; i >= 0; i--) {
      const e = this.entities[i];
      e.update(dt, this);
      if (e.dead) this.entities.splice(i, 1);
    }
    for (let i = this.foes.length - 1; i >= 0; i--) {
      const f = this.foes[i];
      if (stage.visible(f.x - 40, f.y - 40, 80, 80, 140) || f.dying > 0) f.update(dt, this);
      if (f.dead) this.foes.splice(i, 1);
    }
    for (let i = this.bolts.length - 1; i >= 0; i--) {
      const b = this.bolts[i];
      b.update(dt, this);
      if (b.dead) this.bolts.splice(i, 1);
    }

    if (this.endless && this.phase === 'play') {
      this.floodSpeed = 11 + this.runT * 0.42 + this.maxHeight * 0.05;
      this.floodY -= this.floodSpeed * dt;
      this.height = Math.max(0, (this.baseY - (this.player.y + this.player.h)) / TILE);
      if (this.height > this.maxHeight) {
        this.maxHeight = this.height;
        // the tide never falls further behind than 26 tiles: keeps pressure on
        this.floodY = Math.min(this.floodY, this.player.y + this.player.h + TILE * 26);
      }
      if (this.player.y + this.player.h > this.floodY && !this.player.dead) {
        this.flash(0.3, '#8FE6FF');
        this.player.kill('tide');
      }
      if (Math.random() < dt * 26) {
        particles.mote(
          this.camX + (Math.random() - 0.5) * stage.viewW,
          this.floodY + Math.random() * 20, 0, -34 - Math.random() * 40,
          1 + Math.random(), '#BFF0FF', 1.1, 0.7);
      }
    }

    const broke = this.level.updateCrumble(dt);
    if (broke) {
      audio.sfx('crumble');
      for (const { tx, ty } of broke) {
        particles.chunk(tx * TILE + TILE / 2, ty * TILE + TILE / 2, 7, this.biome.rockHi, 110, 0);
        particles.dust(tx * TILE + TILE / 2, ty * TILE + TILE / 2, 6, 0, this.biome.rock, 50);
      }
      this.shake(0.3);
    }

    if (this.comboT > 0) {
      this.comboT -= dt;
      if (this.comboT <= 0) this.stats.combo = 0;
    }

    particles.update(dt, (x, y) => this.level.solidPx(x, y));
    sky.update(dt, this.camX, this.camY);

    this._decayFx(dtWall);
    this._camera(dtWall);

    // adaptive music: intensity rises with danger nearby
    let threat = 0;
    for (const f of this.foes) {
      const d = Math.hypot(f.x - this.player.x, f.y - this.player.y);
      if (d < 150) threat = Math.max(threat, 1 - d / 150);
    }
    audio.setIntensity(this.phase === 'clear' ? 0.25 : 0.55 + threat * 0.45);
  }

  _decayFx(dt) {
    this.trauma = Math.max(0, this.trauma - dt * 2.4);
    this.flashA = Math.max(0, this.flashA - dt * 3.2);
    this.aberr = Math.max(0, this.aberr - dt * 2.6);
    this.zoomTarget = damp(this.zoomTarget, 1, 0.1, dt);
    this.zoom = damp(this.zoom, this.zoomTarget, 0.07, dt);
    this.fade = damp(this.fade, this.fadeTarget, 0.1, dt);
  }

  _doRespawn(input) {
    this.level.resetCrumble();
    for (const s of this._foeSeed) {
      if (!this.foes.includes(s.f)) this.foes.push(s.f);
      s.f.x = s.x; s.f.y = s.y; s.f.face = s.face; s.f.vx = 0; s.f.vy = 0;
      s.f.hp = s.hp; s.f.dying = 0; s.f.dead = false; s.f.flash = 0;
    }
    this.bolts.length = 0;
    this.player.reset(this.respawn.x, this.respawn.y);
    this.player.hp = PHYS.maxHp;
    this.phase = 'intro';
    this.phaseT = 0;
    this.fadeTarget = 0;
    this.camX = this.player.x + this.player.w / 2;
    this.camY = this.player.y - 12;
    this.camGroundY = this.camY;
    particles.clear();
    particles.ring(this.respawn.x, this.respawn.y - 8, 2, 34, 0.4, this.player.skin.glow, 2, 1.2);
    input.reset();
    this.onEvent('respawn', {});
  }

  // ------------------------------------------------------------------ camera
  _camera(dt) {
    const p = this.player;
    const px = p.x + p.w / 2;
    const py = p.y + p.h;

    // horizontal: lead the player by their velocity, damped
    const lead = clamp(p.vx / PHYS.maxRun, -1, 1) * 46 + (p.dashT > 0 ? p.dashDirX * 22 : 0);
    const tx = px + lead;
    this.camX = damp(this.camX, tx, 0.16, dt);

    // vertical: only chase the feet when supported, else use a wide deadzone
    if (p.grounded || p.dead) this.camGroundY = py;
    const dz = 46;
    if (py < this.camGroundY - dz) this.camGroundY = py + dz;
    else if (py > this.camGroundY + dz * 1.5) this.camGroundY = py - dz * 1.5;
    const ty = this.camGroundY - 26 + (p.stomping ? 18 : 0);
    this.camY = damp(this.camY, ty, p.grounded ? 0.2 : 0.34, dt);

    // clamp to level, centring when the level is smaller than the viewport
    const halfW = (stage.viewW / this.zoom) / 2;
    const halfH = (stage.viewH / this.zoom) / 2;
    const L = this.level;
    this.camX = L.pxW > halfW * 2 ? clamp(this.camX, halfW, L.pxW - halfW) : L.pxW / 2;
    // Clamp hard to the level box: a sliver of empty space past the last tile
    // reads as a rendering hole, not as depth.
    this.camY = L.pxH > halfH * 2 ? clamp(this.camY, halfH, L.pxH - halfH) : L.pxH / 2;
  }

  _drawFlood() {
    const ctx = stage.ctx, gctx = stage.gctx;
    const y = this.floodY;
    if (y > stage.wBottom + 20) return;
    const x0 = stage.wLeft - 20, w = stage.viewW + 40;
    const g = ctx.createLinearGradient(0, y - 10, 0, y + 90);
    g.addColorStop(0, alpha('#8FE6FF', 0.0));
    g.addColorStop(0.12, alpha('#5BD8E0', 0.5));
    g.addColorStop(1, alpha('#123C5A', 0.9));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(x0, y + 6);
    const n = 22;
    for (let i = 0; i <= n; i++) {
      const x = x0 + (i / n) * w;
      const yy = y + Math.sin(this.t * 2.4 + i * 0.7) * 2.6 + Math.sin(this.t * 1.1 + i * 0.31) * 1.8;
      ctx.lineTo(x, yy);
    }
    ctx.lineTo(x0 + w, stage.wBottom + 40);
    ctx.lineTo(x0, stage.wBottom + 40);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = alpha('#DFF6FF', 0.75);
    ctx.lineWidth = 1.1;
    ctx.beginPath();
    for (let i = 0; i <= n; i++) {
      const x = x0 + (i / n) * w;
      const yy = y + Math.sin(this.t * 2.4 + i * 0.7) * 2.6 + Math.sin(this.t * 1.1 + i * 0.31) * 1.8;
      if (i === 0) ctx.moveTo(x, yy); else ctx.lineTo(x, yy);
    }
    ctx.stroke();
    if (settings.bloom) {
      gctx.fillStyle = alpha('#8FE6FF', 0.24);
      gctx.fillRect(x0, y - 4, w, 10);
    }
  }

  // ------------------------------------------------------------------ draw
  draw() {
    const tr = this.trauma * this.trauma;
    const sx = (Math.random() * 2 - 1) * tr * 7;
    const sy = (Math.random() * 2 - 1) * tr * 7;
    const rot = (Math.random() * 2 - 1) * tr * 0.012;

    stage.begin();
    sky.draw(this.camX, this.camY);
    stage.world(this.camX, this.camY, sx, sy, this.zoom, rot);

    this.terrain.draw(this.t);
    this.terrain.drawHazards(this.t);

    for (const e of this.entities) e.draw(this.t);
    for (const f of this.foes) if (stage.visible(f.x - 20, f.y - 20, 40, 40)) f.draw(this.t);
    for (const b of this.bolts) b.draw(this.t);

    this.player.draw();
    particles.draw('Outfit, system-ui, sans-serif');

    if (this.endless) this._drawFlood();

    // foreground haze band adds depth separation from the terrain
    stage.screen();
    const ctx = stage.ctx;
    const fg = ctx.createLinearGradient(0, stage.viewH * 0.72, 0, stage.viewH);
    fg.addColorStop(0, alpha(this.biome.fog, 0));
    fg.addColorStop(1, alpha(this.biome.fog, 0.14));
    ctx.fillStyle = fg;
    ctx.fillRect(0, stage.viewH * 0.72, stage.viewW, stage.viewH * 0.28);

    stage.composite({
      flash: this.flashA,
      flashColor: this.flashCol,
      fade: this.fade,
      aberr: this.aberr,
      vignette: clamp01(this.trauma * 0.6),
    });
  }
}
