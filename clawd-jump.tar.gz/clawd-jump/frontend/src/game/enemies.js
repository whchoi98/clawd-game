/**
 * Foes. Each is small and readable: silhouette first, then one signature
 * behaviour. Stompable foes flash a highlight on their crown so the player can
 * tell at a glance what is safe to land on.
 */
import { TILE, C, PHYS } from './config.js';
import { stage } from '../render/stage.js';
import { particles } from '../render/particles.js';
import { audio } from '../core/audio.js';
import { alpha, clamp, clamp01, damp, lerp, sign, TAU, mixHex, hump } from '../core/util.js';
import { settings } from '../core/save.js';

class Foe {
  constructor(sp) {
    this.x = sp.x; this.y = sp.y;
    this.spawnX = sp.x; this.spawnY = sp.y;
    this.vx = 0; this.vy = 0;
    this.w = 14; this.h = 12;
    this.face = -1;
    this.hp = 1;
    this.stompable = true;
    this.dead = false;
    this.dying = 0;
    this.t = (sp.tx * 7 + sp.ty * 3) % 10;
    this.flash = 0;
    this.grounded = false;
  }

  get cx() { return this.x; }
  get cy() { return this.y; }

  hitbox() { return [this.x - this.w / 2, this.y - this.h / 2, this.w, this.h]; }

  gravity(dt, world, g = 900, maxFall = 320) {
    this.vy = Math.min(maxFall, this.vy + g * dt);
    const L = world.level;
    // vertical
    const ny = this.y + this.vy * dt;
    const half = this.h / 2;
    if (this.vy > 0 && (L.solidPx(this.x - this.w / 2 + 2, ny + half) || L.solidPx(this.x + this.w / 2 - 2, ny + half))) {
      this.y = Math.floor((ny + half) / TILE) * TILE - half - 0.01;
      this.vy = 0; this.grounded = true;
    } else if (this.vy < 0 && (L.solidPx(this.x - this.w / 2 + 2, ny - half) || L.solidPx(this.x + this.w / 2 - 2, ny - half))) {
      this.y = Math.floor((ny - half) / TILE) * TILE + TILE + half + 0.01;
      this.vy = 0;
    } else { this.y = ny; this.grounded = false; }
  }

  walkStep(dt, world, speed, turnAtLedge = true) {
    const L = world.level;
    const nx = this.x + this.face * speed * dt;
    const lead = nx + this.face * (this.w / 2 + 1);
    const hitWall = L.solidPx(lead, this.y) || L.solidPx(lead, this.y - this.h / 2 + 2);
    const noFloor = turnAtLedge && this.grounded && !L.solidPx(lead, this.y + this.h / 2 + 3);
    if (hitWall || noFloor) { this.face *= -1; return; }
    this.x = nx;
  }

  /** Contact resolution shared by all foes. */
  contact(world) {
    const p = world.player;
    if (p.dead || this.dying > 0) return;
    const [bx, by, bw, bh] = this.hitbox();
    if (p.x + p.w < bx || p.x > bx + bw || p.y + p.h < by || p.y > by + bh) return;

    const fromAbove = p.vy > 40 && p.y + p.h - p.vy * 0.016 <= by + bh * 0.55;
    if (this.stompable && (fromAbove || p.stomping)) {
      this.damage(world, p.stomping ? 2 : 1);
      p.vy = PHYS.stompBounce * (p.stomping ? 1.15 : 1);
      p.jumps = 0;
      p.stomping = false;
      p.dashReady = true;
      p.dashFlash = 1;
      p.squash = 0.4;
      world.hitstop(0.05);
      world.shake(0.65);
      audio.sfx('stomp');
      return;
    }
    if (p.dashT > 0) { this.damage(world, 2); return; }
    p.hurt(this.x, 'foe');
  }

  damage(world, n = 1) {
    this.hp -= n;
    this.flash = 1;
    if (this.hp <= 0) this.die(world);
    else { audio.sfx('enemyDie', { vol: 0.5 }); particles.spark(this.x, this.y, 6, C.enemyHi, 130, 0, TAU, 0.8); }
  }

  die(world) {
    if (this.dying > 0) return;
    this.dying = 0.001;
    audio.sfx('enemyDie');
    world.onFoeKilled(this);
    particles.tri(this.x, this.y, 8, C.enemy, 170, 0.7);
    particles.spark(this.x, this.y, 14, C.enemyHi, 210, 0, TAU, 1);
    particles.ring(this.x, this.y, 2, 26, 0.32, C.enemyHi, 1.8, 1);
  }

  update(dt, world) {
    this.t += dt;
    this.flash = Math.max(0, this.flash - dt * 5);
    if (this.dying > 0) {
      this.dying += dt;
      if (this.dying > 0.28) this.dead = true;
      return;
    }
    this.step(dt, world);
    this.contact(world);
  }

  step() {}
  draw() {}

  _dieScale() { return this.dying > 0 ? 1 + this.dying * 3 : 1; }
  _dieAlpha() { return this.dying > 0 ? clamp01(1 - this.dying / 0.28) : 1; }

  _tint(ctx) {
    if (this.flash > 0.02) { ctx.globalAlpha *= 1; ctx.filter = ''; }
  }
}

// ============================================================ WALKER
export class Walker extends Foe {
  constructor(sp) { super(sp); this.w = 15; this.h = 12; this.speed = 44; }
  step(dt, world) { this.gravity(dt, world); this.walkStep(dt, world, this.speed); }
  draw(t) {
    const ctx = stage.ctx, gctx = stage.gctx;
    const sc = this._dieScale();
    ctx.save();
    ctx.globalAlpha = this._dieAlpha();
    ctx.translate(this.x, this.y);
    ctx.scale(sc, sc);
    const wob = Math.sin(this.t * 9) * 0.9;

    // legs
    ctx.strokeStyle = '#4A3A82';
    ctx.lineWidth = 1.5; ctx.lineCap = 'round';
    for (let i = -1; i <= 1; i++) {
      const ph = this.t * 9 + i * 1.6;
      ctx.beginPath();
      ctx.moveTo(i * 4, 3.4);
      ctx.lineTo(i * 4 + Math.cos(ph) * 2.4, 6.2 - Math.max(0, Math.sin(ph)) * 1.6);
      ctx.stroke();
    }
    // body
    const g = ctx.createLinearGradient(-7, -6, 5, 6);
    g.addColorStop(0, this.flash > 0.1 ? '#FFFFFF' : C.enemyHi);
    g.addColorStop(0.5, this.flash > 0.1 ? '#FFD8D8' : C.enemy);
    g.addColorStop(1, '#3A2A6A');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(0, wob * 0.3, 7.4, 5.6, 0, 0, TAU);
    ctx.fill();
    // stompable crown highlight
    ctx.strokeStyle = alpha('#FFE9A8', 0.55 + 0.25 * Math.sin(t * 4));
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.ellipse(0, -1.4 + wob * 0.3, 5.4, 3.4, 0, Math.PI * 1.12, Math.PI * 1.88); ctx.stroke();
    // eyes
    for (const s of [-1, 1]) {
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath(); ctx.arc(this.face * 2.2 + s * 1.9, -0.6, 1.5, 0, TAU); ctx.fill();
      ctx.fillStyle = '#150C28';
      ctx.beginPath(); ctx.arc(this.face * 2.9 + s * 1.9, -0.5, 0.75, 0, TAU); ctx.fill();
    }
    ctx.restore();
    if (settings.bloom) {
      gctx.fillStyle = alpha(C.enemyHi, 0.16 + this.flash * 0.5);
      gctx.beginPath(); gctx.arc(this.x, this.y, 10, 0, TAU); gctx.fill();
    }
  }
}

// ============================================================ SPIKER (no stomp)
export class Spiker extends Walker {
  constructor(sp) { super(sp); this.stompable = false; this.speed = 34; this.hp = 2; }
  draw(t) {
    super.draw(t);
    const ctx = stage.ctx;
    ctx.save();
    ctx.globalAlpha = this._dieAlpha();
    ctx.translate(this.x, this.y);
    ctx.scale(this._dieScale(), this._dieScale());
    ctx.fillStyle = '#E8E2F2';
    for (let i = -2; i <= 2; i++) {
      const bx = i * 2.8;
      ctx.beginPath();
      ctx.moveTo(bx - 1.3, -4.2); ctx.lineTo(bx, -8.4); ctx.lineTo(bx + 1.3, -4.2);
      ctx.closePath(); ctx.fill();
    }
    ctx.fillStyle = alpha(C.danger, 0.55 + 0.3 * Math.sin(t * 5));
    for (let i = -2; i <= 2; i++) {
      const bx = i * 2.8;
      ctx.beginPath();
      ctx.moveTo(bx - 0.5, -6); ctx.lineTo(bx, -8.4); ctx.lineTo(bx + 0.5, -6);
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }
}

// ============================================================ HOPPER
export class Hopper extends Foe {
  constructor(sp) { super(sp); this.w = 13; this.h = 13; this.cd = 0.6 + Math.random(); this.sq = 0; }
  step(dt, world) {
    this.gravity(dt, world, 1000);
    this.sq = damp(this.sq, 0, 0.09, dt);
    if (this.grounded) {
      this.vx = damp(this.vx, 0, 0.08, dt);
      this.cd -= dt;
      if (this.cd < 0.25) this.sq = lerp(this.sq, 0.45, dt * 8);
      if (this.cd <= 0) {
        const p = world.player;
        this.face = sign(p.x - this.x) || this.face;
        this.vy = -300;
        this.vx = this.face * 76;
        this.cd = 1.1 + Math.random() * 0.7;
        this.sq = -0.4;
        this.grounded = false;
        particles.dust(this.x, this.y + this.h / 2, 5, 0, C.enemyHi, 55);
      }
    }
    const L = world.level;
    const nx = this.x + this.vx * dt;
    if (!L.solidPx(nx + sign(this.vx) * this.w / 2, this.y)) this.x = nx;
    else this.vx *= -0.5;
  }
  draw(t) {
    const ctx = stage.ctx, gctx = stage.gctx;
    ctx.save();
    ctx.globalAlpha = this._dieAlpha();
    ctx.translate(this.x, this.y);
    const s = this._dieScale();
    ctx.scale(s * (1 + this.sq * 0.5), s * (1 - this.sq * 0.45));
    const g = ctx.createRadialGradient(-2, -3, 1, 0, 1, 8);
    g.addColorStop(0, this.flash > 0.1 ? '#FFFFFF' : '#9AE8C8');
    g.addColorStop(0.6, '#3FA98A');
    g.addColorStop(1, '#1E5F4E');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(-6.6, 5.5);
    ctx.quadraticCurveTo(-7.4, -6.4, 0, -6.4);
    ctx.quadraticCurveTo(7.4, -6.4, 6.6, 5.5);
    ctx.quadraticCurveTo(0, 7.2, -6.6, 5.5);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = alpha('#FFE9A8', 0.5 + 0.25 * Math.sin(t * 4));
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.ellipse(0, -2.4, 4.6, 3, 0, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke();
    for (const sd of [-1, 1]) {
      ctx.fillStyle = '#0E2A24';
      ctx.beginPath(); ctx.ellipse(sd * 2.4 + this.face * 0.8, -1.4, 1.1, 1.5, 0, 0, TAU); ctx.fill();
    }
    ctx.restore();
    if (settings.bloom) {
      gctx.fillStyle = alpha('#9AE8C8', 0.14 + this.flash * 0.5);
      gctx.beginPath(); gctx.arc(this.x, this.y, 10, 0, TAU); gctx.fill();
    }
  }
}

// ============================================================ FLYER
export class Flyer extends Foe {
  constructor(sp) {
    super(sp);
    this.w = 14; this.h = 15;
    this.amp = 26 + (sp.tx % 3) * 8;
    this.stompable = true;
    this.tent = [0, 0, 0, 0];
  }
  step(dt, world) {
    const p = world.player;
    const near = Math.hypot(p.x - this.x, p.y - this.y) < 110;
    this.y = this.spawnY + Math.sin(this.t * 1.15) * this.amp * 0.5;
    if (near) {
      // drifts toward the player, but slowly enough to dodge
      this.x = damp(this.x, p.x + p.w / 2, 1.4, dt);
      this.y = damp(this.y, p.y + p.h / 2 - 24, 1.9, dt);
    } else {
      this.x = this.spawnX + Math.sin(this.t * 0.8) * this.amp;
    }
    for (let i = 0; i < 4; i++) this.tent[i] = Math.sin(this.t * 3.2 + i * 0.9) * 2.4;
  }
  draw(t) {
    const ctx = stage.ctx, gctx = stage.gctx;
    ctx.save();
    ctx.globalAlpha = this._dieAlpha();
    ctx.translate(this.x, this.y);
    ctx.scale(this._dieScale(), this._dieScale());
    // tentacles
    ctx.strokeStyle = alpha('#C9B4FF', 0.75);
    ctx.lineWidth = 1.1; ctx.lineCap = 'round';
    for (let i = 0; i < 4; i++) {
      const bx = -4.2 + i * 2.8;
      ctx.beginPath();
      ctx.moveTo(bx, 3.4);
      ctx.quadraticCurveTo(bx + this.tent[i], 7, bx + this.tent[i] * 1.7, 11);
      ctx.stroke();
    }
    // bell
    const pump = 1 + Math.sin(this.t * 3.2) * 0.08;
    const g = ctx.createRadialGradient(0, -3, 1, 0, 1, 9);
    g.addColorStop(0, this.flash > 0.1 ? '#FFFFFF' : '#EDE4FF');
    g.addColorStop(0.5, '#A78BFA');
    g.addColorStop(1, '#5B3FA8');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(0, 0, 7.2 * pump, 6.2 / pump, 0, Math.PI, TAU);
    ctx.quadraticCurveTo(4, 4.4, 0, 3.6);
    ctx.quadraticCurveTo(-4, 4.4, -7.2 * pump, 0);
    ctx.fill();
    ctx.strokeStyle = alpha('#FFFFFF', 0.5);
    ctx.lineWidth = 0.7;
    ctx.beginPath(); ctx.ellipse(0, 0, 7.2 * pump, 6.2 / pump, 0, Math.PI, TAU); ctx.stroke();
    for (const sd of [-1, 1]) {
      ctx.fillStyle = '#1C1030';
      ctx.beginPath(); ctx.arc(sd * 2.4, -1.4, 1.15, 0, TAU); ctx.fill();
    }
    ctx.restore();
    if (settings.bloom) {
      gctx.fillStyle = alpha('#A78BFA', 0.3 + this.flash * 0.5);
      gctx.beginPath(); gctx.arc(this.x, this.y, 13, 0, TAU); gctx.fill();
    }
  }
}

// ============================================================ PROJECTILE
export class Bolt {
  constructor(x, y, vx, vy, col = C.dangerHi) {
    this.x = x; this.y = y; this.vx = vx; this.vy = vy;
    this.w = 6; this.h = 6; this.dead = false; this.t = 0; this.col = col;
  }
  update(dt, world) {
    this.t += dt;
    this.x += this.vx * dt; this.y += this.vy * dt;
    // One-way platforms stop the player, so they stop bolts too — otherwise the
    // collision rule silently differs by entity with no visual cue.
    const L = world.level;
    const blocked = L.solidPx(this.x, this.y) ||
      L.oneWay(Math.floor(this.x / TILE), Math.floor(this.y / TILE));
    if (this.t > 3.4 || blocked) {
      this.dead = true;
      particles.spark(this.x, this.y, 6, this.col, 110, 0, TAU, 0.9);
      return;
    }
    const p = world.player;
    if (p.x + p.w > this.x - 3 && p.x < this.x + 3 && p.y + p.h > this.y - 3 && p.y < this.y + 3) {
      if (p.dashT > 0) { this.dead = true; particles.spark(this.x, this.y, 8, this.col, 150, 0, TAU, 1); return; }
      p.hurt(this.x, 'bolt');
      this.dead = true;
    }
    if (Math.random() < dt * 40) particles.mote(this.x, this.y, -this.vx * 0.1, -this.vy * 0.1, 0.9, this.col, 0.28, 0.9);
  }
  draw(t) {
    const ctx = stage.ctx, gctx = stage.gctx;
    const a = Math.atan2(this.vy, this.vx);
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(a);
    const g = ctx.createLinearGradient(-6, 0, 4, 0);
    g.addColorStop(0, alpha(this.col, 0));
    g.addColorStop(1, this.col);
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.ellipse(-1, 0, 6, 2.1, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath(); ctx.arc(1.6, 0, 1.5, 0, TAU); ctx.fill();
    ctx.restore();
    if (settings.bloom) {
      gctx.fillStyle = alpha(this.col, 0.75);
      gctx.beginPath(); gctx.arc(this.x, this.y, 6, 0, TAU); gctx.fill();
    }
  }
}

// ============================================================ TURRET
export class Turret extends Foe {
  constructor(sp) {
    super(sp);
    this.w = 15; this.h = 15;
    this.stompable = true;
    this.hp = 2;
    this.cd = 1.2;
    this.aim = 0;
    this.charge = 0;
  }
  step(dt, world) {
    const p = world.player;
    const dx = p.x + p.w / 2 - this.x, dy = p.y + p.h / 2 - this.y;
    const d = Math.hypot(dx, dy);
    if (d < 190) {
      this.aim = damp(this.aim, Math.atan2(dy, dx), 0.16, dt);
      this.cd -= dt;
      this.charge = clamp01(1 - this.cd / 0.4);
      if (this.cd <= 0) {
        this.cd = 1.5;
        this.charge = 0;
        const sp = 150;
        world.spawnBolt(this.x + Math.cos(this.aim) * 9, this.y + Math.sin(this.aim) * 9,
          Math.cos(this.aim) * sp, Math.sin(this.aim) * sp);
        audio.sfx('shoot');
        particles.spark(this.x + Math.cos(this.aim) * 10, this.y + Math.sin(this.aim) * 10, 5, C.dangerHi, 120, this.aim, 0.9, 1);
      }
    } else { this.charge = 0; this.cd = Math.min(this.cd + dt, 1.2); }
  }
  draw(t) {
    const ctx = stage.ctx, gctx = stage.gctx;
    ctx.save();
    ctx.globalAlpha = this._dieAlpha();
    ctx.translate(this.x, this.y);
    ctx.scale(this._dieScale(), this._dieScale());
    // barrel
    ctx.save();
    ctx.rotate(this.aim);
    ctx.fillStyle = '#57506B';
    ctx.beginPath(); ctx.roundRect(2, -2.4, 9, 4.8, 2); ctx.fill();
    ctx.fillStyle = alpha(C.danger, 0.4 + this.charge * 0.6);
    ctx.beginPath(); ctx.arc(10, 0, 1.6 + this.charge * 1.6, 0, TAU); ctx.fill();
    ctx.restore();
    // shell
    const g = ctx.createRadialGradient(-2, -3, 1, 0, 0, 9);
    g.addColorStop(0, this.flash > 0.1 ? '#FFFFFF' : '#8D839F');
    g.addColorStop(1, '#332D42');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(0, 0, 7.4, 0, TAU); ctx.fill();
    ctx.strokeStyle = alpha('#FFE9A8', 0.45 + 0.25 * Math.sin(t * 4));
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(0, 0, 5.6, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke();
    ctx.fillStyle = alpha(C.danger, 0.65 + 0.3 * Math.sin(t * 6));
    ctx.beginPath(); ctx.arc(0, 0, 2.4, 0, TAU); ctx.fill();
    ctx.restore();
    if (settings.bloom) {
      gctx.fillStyle = alpha(C.danger, 0.2 + this.charge * 0.5 + this.flash * 0.4);
      gctx.beginPath(); gctx.arc(this.x, this.y, 11, 0, TAU); gctx.fill();
    }
  }
}

// ============================================================ CHASER
export class Chaser extends Foe {
  constructor(sp) {
    super(sp);
    this.w = 15; this.h = 15;
    this.stompable = false;
    this.hp = 2;
    this.state = 'idle';
    this.wind = 0;
    this.spin = 0;
  }
  step(dt, world) {
    const p = world.player;
    const dx = p.x + p.w / 2 - this.x, dy = p.y + p.h / 2 - this.y;
    const d = Math.hypot(dx, dy);
    this.spin += dt * (this.state === 'charge' ? 18 : 4);
    if (this.state === 'idle') {
      this.vx = damp(this.vx, 0, 0.2, dt);
      this.vy = damp(this.vy, 0, 0.2, dt);
      if (d < 130) { this.state = 'wind'; this.wind = 0.5; }
    } else if (this.state === 'wind') {
      this.wind -= dt;
      this.face = sign(dx) || this.face;
      if (this.wind <= 0) {
        this.state = 'charge';
        const m = d || 1;
        this.vx = (dx / m) * 210; this.vy = (dy / m) * 210;
        this.wind = 0.85;
        audio.sfx('wind', { vol: 0.6 });
      }
    } else {
      this.wind -= dt;
      this.vx = damp(this.vx, 0, 0.5, dt);
      this.vy = damp(this.vy, 0, 0.5, dt);
      if (this.wind <= 0) { this.state = 'idle'; }
      if (Math.random() < dt * 30) particles.mote(this.x, this.y, 0, 0, 1.4, C.enemyHi, 0.3, 0.8);
    }
    const L = world.level;
    const nx = this.x + this.vx * dt, ny = this.y + this.vy * dt;
    if (!L.solidPx(nx + sign(this.vx) * this.w / 2, this.y)) this.x = nx;
    else { this.vx *= -0.35; this.state = 'idle'; particles.spark(this.x, this.y, 8, C.enemyHi, 130, 0, TAU, 0.8); }
    if (!L.solidPx(this.x, ny + sign(this.vy) * this.h / 2)) this.y = ny;
    else { this.vy *= -0.35; }
  }
  draw(t) {
    const ctx = stage.ctx, gctx = stage.gctx;
    const charging = this.state === 'charge';
    ctx.save();
    ctx.globalAlpha = this._dieAlpha();
    ctx.translate(this.x, this.y);
    if (this.state === 'wind') {
      const k = 1 - this.wind / 0.5;
      ctx.scale(1 + k * 0.16, 1 - k * 0.1);
    }
    ctx.scale(this._dieScale(), this._dieScale());
    ctx.save();
    ctx.rotate(this.spin * 0.3);
    ctx.fillStyle = charging ? '#FFD9DE' : '#C9C2D8';
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU;
      ctx.save(); ctx.rotate(a);
      ctx.beginPath();
      ctx.moveTo(-1.5, -5.6); ctx.lineTo(0, -10.4); ctx.lineTo(1.5, -5.6);
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    ctx.restore();
    const g = ctx.createRadialGradient(-2, -2, 1, 0, 0, 7);
    g.addColorStop(0, this.flash > 0.1 ? '#FFFFFF' : charging ? '#FF9AA6' : '#7A6BA8');
    g.addColorStop(1, '#2A1F4A');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(0, 0, 6.2, 0, TAU); ctx.fill();
    ctx.fillStyle = charging ? C.danger : '#E8E2F2';
    ctx.beginPath(); ctx.arc(this.face * 1.4, -0.4, 2.4, 0, TAU); ctx.fill();
    ctx.fillStyle = '#120B20';
    ctx.beginPath(); ctx.arc(this.face * 2.1, -0.4, 1.1, 0, TAU); ctx.fill();
    ctx.restore();
    if (settings.bloom) {
      gctx.fillStyle = alpha(charging ? C.danger : C.enemyHi, 0.2 + (charging ? 0.4 : 0) + this.flash * 0.4);
      gctx.beginPath(); gctx.arc(this.x, this.y, 13, 0, TAU); gctx.fill();
    }
  }
}

export const FOE_BY_CH = { w: Walker, h: Hopper, f: Flyer, t: Turret, c: Chaser };
