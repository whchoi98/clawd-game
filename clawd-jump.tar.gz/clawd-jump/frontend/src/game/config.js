/**
 * Tuning constants and art direction, in one place.
 * Units are world-units and seconds. TILE is 16 world units; the player is
 * 11x15, so a 1-tile gap is passable and a 2-tile ceiling is comfortable.
 */

export const TILE = 16;

export const PHYS = {
  // --- horizontal ---
  maxRun: 132,
  accelGround: 1150,
  accelAir: 820,
  frictionGround: 1500,
  frictionAir: 260,
  turnBoost: 1.9,        // extra accel when reversing — kills the "ice" feeling

  // --- vertical ---
  gravity: 860,
  gravityFall: 1120,     // heavier on the way down: snappy arc, forgiving apex
  gravityApex: 620,      // floatier near the apex, where players aim
  apexWindow: 42,        // |vy| under this counts as apex
  maxFall: 340,
  jumpVel: -272,         // ~43u rise ≈ 2.7 tiles
  jumpVel2: -238,
  jumpCut: 0.42,         // release multiplier for variable height
  coyote: 0.095,
  jumpBuffer: 0.13,
  maxJumps: 2,

  // --- dash ---
  dashSpeed: 300,
  dashTime: 0.145,
  dashEndSpeed: 168,     // carried momentum when the dash ends
  dashCooldown: 0.22,
  dashGrace: 0.06,       // input-buffer for dash

  // --- wall ---
  wallSlide: 62,
  wallStick: 0.1,        // hold-away grace before you actually leave the wall
  wallJumpX: 168,
  wallJumpY: -258,
  wallJumpLock: 0.13,    // horizontal input ignored so the kick always reads

  // --- misc ---
  stompVel: 400,
  stompBounce: -300,
  springVel: -430,
  hurtInvuln: 1.35,
  hurtKnockX: 130,
  hurtKnockY: -170,
  maxHp: 3,
  terminalWater: 90,
  waterGrav: 300,
  waterJump: -190,
};

/** Assist mode softens the numbers without changing level design. */
export const ASSIST = {
  gravity: 0.82,
  gravityFall: 0.8,
  maxJumps: 3,
  hurtInvuln: 2.2,
  dashCooldown: 0.12,
};

export const PLAYER_W = 11;
export const PLAYER_H = 15;

// ============================================================
// BIOMES — each is a full art direction, not a palette swap
// ============================================================
export const BIOMES = {
  coral: {
    id: 'coral',
    name: 'CORAL CANYON',
    kr: '산호 협곡',
    track: 'coral',
    sky: ['#2A1533', '#6E2E4C', '#C4585B', '#F09A62'],
    skyLight: '#FFD9A8',
    sun: { x: 0.74, y: 0.30, r: 46, color: '#FFF3D4', glow: '#FF9C5B', kind: 'disc' },
    fog: '#F0A070',
    ridge: ['#3A1B3E', '#54234A', '#75315A'],
    rock: '#5C4048',
    rockHi: '#856068',
    rockDeep: '#33222C',
    crust: '#E8825C',
    crustHi: '#FFB98C',
    accent: '#5BD8E0',
    weather: 'motes',
    ambient: 0.0,
    spike: { hi: '#FFF2F5', mid: '#CFC2DA', lo: '#5E5370' },
    props: ['coral', 'kelp'],
  },
  glass: {
    id: 'glass',
    name: 'GLASS FOREST',
    kr: '유리 숲',
    track: 'glass',
    sky: ['#05060F', '#0C1230', '#1B2360', '#3B3A86'],
    skyLight: '#9FB4FF',
    sun: { x: 0.24, y: 0.22, r: 30, color: '#F2F6FF', glow: '#7C8CFF', kind: 'disc' },
    fog: '#2B3170',
    ridge: ['#0A0D22', '#121840', '#1D2559'],
    rock: '#333A68',
    rockHi: '#525C99',
    rockDeep: '#1A1E3C',
    crust: '#8B7BF0',
    crustHi: '#C0B4FF',
    accent: '#5BD8E0',
    weather: 'snow',
    ambient: 0.22,
    spike: { hi: '#EAF4FF', mid: '#A9BEE0', lo: '#3D4A70' },
    props: ['crystal', 'glowcap'],
  },
  ember: {
    id: 'ember',
    name: 'EMBER CORE',
    kr: '용광로 심부',
    track: 'ember',
    sky: ['#0B0406', '#2A0A0C', '#5E1410', '#9E2E12'],
    skyLight: '#FFB05A',
    sun: { x: 0.5, y: 1.06, r: 96, color: '#FFC978', glow: '#FF5C1E', kind: 'glow' },
    fog: '#7A2410',
    ridge: ['#160608', '#2E0B0B', '#48120E'],
    rock: '#4A2822',
    rockHi: '#75402F',
    rockDeep: '#251110',
    crust: '#FF6B35',
    crustHi: '#FFC06B',
    accent: '#FFD166',
    weather: 'ash',
    ambient: 0.14,
    spike: { hi: '#F0C9A8', mid: '#8A5240', lo: '#2A1210' },
    props: ['vent', 'obsidian'],
  },
};

export const BIOME_ORDER = ['coral', 'glass', 'ember'];

// ============================================================
// SHARED COLOURS
// ============================================================
export const C = {
  clawd: '#E8825C',
  clawdHi: '#FFB088',
  clawdLo: '#B24A3B',
  shell: '#F2A07A',
  ink: '#120B14',
  shard: '#5BD8E0',
  shardHi: '#CFFBFF',
  relic: '#F4C95D',
  relicHi: '#FFF0BE',
  danger: '#FF4D63',
  dangerHi: '#FF9AA6',
  spring: '#8BE86A',
  checkpoint: '#7DE1FF',
  goal: '#FFE27A',
  enemy: '#7A5CC7',
  enemyHi: '#B49BFF',
  water: '#2E7FA8',
};

// ============================================================
// SCORING
// ============================================================
/** Star 1 = clear, star 2 = all shards, star 3 = under the par time. */
export function rankFor(timeSec, par, shards, totalShards, deaths) {
  const t = timeSec / Math.max(0.001, par);
  let score = 0;
  if (t <= 0.8) score += 3; else if (t <= 1.0) score += 2; else if (t <= 1.35) score += 1;
  if (totalShards > 0 && shards >= totalShards) score += 2;
  else if (totalShards > 0 && shards / totalShards >= 0.6) score += 1;
  if (deaths === 0) score += 2;
  else if (deaths <= 2) score += 1;
  return ['C', 'C', 'B', 'B', 'A', 'A', 'S', 'S'][Math.min(7, score)];
}
