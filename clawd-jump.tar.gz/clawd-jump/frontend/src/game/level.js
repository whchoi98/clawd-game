/**
 * Level = a rectangular char grid plus metadata. Terrain lives in the grid;
 * everything that moves is extracted into `spawns` at load time and removed
 * from the grid so it can't also be collided with.
 *
 * Grid legend
 *   .  empty             #  solid rock
 *   =  one-way platform  X  crumbling block   ~  water surface   W  water body
 *   ^  spikes up         V  spikes down       {  spikes right    }  spikes left
 *
 * Spawn legend (removed from the grid)
 *   P player   G goal    C checkpoint   o shard   R relic   S spring
 *   w walker   h hopper  f flyer        t turret  c chaser
 *   m platform-h  M platform-v  s saw   z updraft
 */
import { TILE } from './config.js';

const SOLID_CH = '#X';
const SPAWN_CH = 'PGCoRSwhftcmMsz';

export class Level {
  constructor(def) {
    this.def = def;
    this.id = def.id;
    this.name = def.name;
    this.biomeId = def.biome;
    this.par = def.par || 60;
    this.seed = def.seed ?? 1;
    this.hint = def.hint || null;

    const rows = def.rows;
    this.h = rows.length;
    this.w = rows.reduce((m, r) => Math.max(m, r.length), 0);

    this.grid = new Array(this.h);
    this.spawns = [];
    for (let y = 0; y < this.h; y++) {
      const src = rows[y].padEnd(this.w, '.');
      const line = new Array(this.w);
      for (let x = 0; x < this.w; x++) {
        const ch = src[x];
        if (SPAWN_CH.includes(ch)) {
          this.spawns.push({ ch, tx: x, ty: y, x: x * TILE + TILE / 2, y: y * TILE + TILE / 2 });
          line[x] = '.';
        } else {
          line[x] = ch === ' ' ? '.' : ch;
        }
      }
      this.grid[y] = line;
    }

    /** Crumbling tiles: key = ty*w+tx, value = remaining seconds (0 = gone). */
    this.crumble = new Map();
    this.broken = new Set();

    this.pxW = this.w * TILE;
    this.pxH = this.h * TILE;

    const p = this.spawns.find((s) => s.ch === 'P');
    this.start = p ? { x: p.x, y: p.ty * TILE + TILE } : { x: TILE * 2, y: TILE * 2 };
    this.totalShards = this.spawns.filter((s) => s.ch === 'o').length;
    this.totalRelics = this.spawns.filter((s) => s.ch === 'R').length;
  }

  at(tx, ty) {
    if (tx < 0 || ty < 0 || tx >= this.w || ty >= this.h) return ty >= this.h ? '.' : '#';
    const k = ty * this.w + tx;
    if (this.broken.has(k)) return '.';
    return this.grid[ty][tx];
  }

  /** Out-of-bounds sides read as solid so the player can't leave the map. */
  solid(tx, ty) {
    if (ty >= this.h) return false;         // below the map is a death pit
    if (tx < 0 || tx >= this.w) return true;
    if (ty < 0) return false;               // open sky above
    return SOLID_CH.includes(this.at(tx, ty));
  }

  oneWay(tx, ty) { return this.at(tx, ty) === '='; }

  solidPx(x, y) { return this.solid(Math.floor(x / TILE), Math.floor(y / TILE)); }

  hazardPx(x, y) {
    const ch = this.at(Math.floor(x / TILE), Math.floor(y / TILE));
    return ch === '^' || ch === 'V' || ch === '{' || ch === '}';
  }

  waterPx(x, y) {
    const ch = this.at(Math.floor(x / TILE), Math.floor(y / TILE));
    return ch === '~' || ch === 'W';
  }

  /** Start the countdown on a crumbling tile. */
  touchCrumble(tx, ty) {
    if (this.at(tx, ty) !== 'X') return;
    const k = ty * this.w + tx;
    if (!this.crumble.has(k)) this.crumble.set(k, 0.42);
  }

  /** @returns array of {tx,ty} that broke this frame. */
  updateCrumble(dt) {
    if (!this.crumble.size) return null;
    let broke = null;
    for (const [k, v] of this.crumble) {
      const nv = v - dt;
      if (nv <= 0) {
        this.crumble.delete(k);
        this.broken.add(k);
        (broke ||= []).push({ tx: k % this.w, ty: Math.floor(k / this.w) });
      } else this.crumble.set(k, nv);
    }
    return broke;
  }

  resetCrumble() { this.crumble.clear(); this.broken.clear(); }

  /** How far a marker can travel before hitting rock, in world units. */
  patrolSpan(tx, ty, dx, dy, max = 12) {
    let n = 0;
    while (n < max && !this.solid(tx + dx * (n + 1), ty + dy * (n + 1))) n++;
    return n * TILE;
  }
}
