/**
 * Endless Ascent — a procedurally generated tower.
 *
 * Generation is a single upward sweep under a reachability contract: a measured
 * jump-plus-double-jump reaches 4.92 tiles up and ~7 tiles across at that height,
 * so every step rises at most 4 rows. Five-row steps are technically climbable by
 * wall-jumping off a platform's side face, but Endless has no prerequisite on the
 * title screen while wall-jumping is first taught in the third story level — so
 * the generator stays inside what a player arriving here already knows.
 *
 * Danger density and foe variety scale with height; the biome rotates every 90 rows.
 */
import { makeRng } from '../core/util.js';
import { BIOME_ORDER } from './config.js';

const W = 44;

export function makeEndlessLevel(seed = Date.now() & 0xffff) {
  const rng = makeRng(seed | 1);
  const H = 560;
  const g = [];
  for (let y = 0; y < H; y++) g.push(new Array(W).fill('.'));

  const set = (x, y, ch) => { if (x >= 0 && x < W && y >= 0 && y < H) g[y][x] = ch; };
  const plat = (x0, x1, y, ch = '#') => { for (let x = x0; x <= x1; x++) set(x, y, ch); };

  // ---- base camp ----
  const baseY = H - 4;
  for (let y = baseY; y < H; y++) plat(0, W - 1, y);
  plat(0, W - 1, baseY - 1, '.');
  set(W >> 1, baseY - 1, 'P');

  // side walls the whole way up — gives the player something to wall-jump
  for (let y = 0; y < H; y++) { set(0, y, '#'); set(1, y, '#'); set(W - 2, y, '#'); set(W - 1, y, '#'); }

  let ax = W >> 1;          // current anchor column
  let y = baseY - 4;
  let idx = 0;

  while (y > 6) {
    const depth = (baseY - y) / (baseY - 6);     // 0 at the bottom, 1 at the top
    const tier = Math.floor((baseY - y) / 90);

    const rise = rng.int(3, 4);                  // rows gained per platform (<= measured apex)
    y -= rise;
    const width = Math.max(2, rng.int(6, 9) - Math.floor(depth * 3));
    const spread = Math.min(9, 4 + Math.floor(depth * 5));
    ax = Math.max(3, Math.min(W - 4 - width, ax + rng.int(-spread, spread)));

    // platform type
    const roll = rng();
    let ch = '#';
    if (roll < 0.16 + depth * 0.16) ch = 'X';          // crumbling
    else if (roll < 0.3 + depth * 0.1) ch = '=';       // one-way
    plat(ax, ax + width, y, ch);

    // shards along the platform
    const nS = rng.int(1, 3);
    for (let i = 0; i < nS; i++) set(ax + 1 + rng.int(0, Math.max(0, width - 2)), y - 1, 'o');

    // furniture
    if (rng.chance(0.14)) set(ax + (width >> 1), y - 1, 'S');            // spring
    if (rng.chance(0.1 + depth * 0.1)) set(ax + rng.int(0, width), y - 1, rng.chance(0.5) ? 'w' : 'h');
    if (depth > 0.16 && rng.chance(0.08 + depth * 0.12)) set(ax + (width >> 1), y - 4, 'f');
    if (depth > 0.34 && rng.chance(0.07 + depth * 0.1)) set(ax + rng.int(0, width), y - 1, 't');
    if (depth > 0.5 && rng.chance(0.06 + depth * 0.1)) set(ax + (width >> 1), y - 3, 'c');
    if (depth > 0.22 && rng.chance(0.12)) {
      // spike garnish on one end
      const sx = rng.chance(0.5) ? ax : ax + width;
      set(sx, y - 1, '^');
    }
    if (depth > 0.28 && rng.chance(0.1)) set(ax + (width >> 1), y - 2, 's');   // saw
    if (depth > 0.4 && rng.chance(0.09)) set(ax + (width >> 1), y - 1, 'z');   // updraft

    // occasional relic-shaped bonus every ~20 platforms
    if (idx > 0 && idx % 20 === 0) set(ax + (width >> 1), y - 2, 'R');

    // wall-jump chimneys: a stub column that narrows the route
    if (rng.chance(0.14)) {
      const wx = rng.chance(0.5) ? ax - 2 : ax + width + 2;
      if (wx > 2 && wx < W - 3) for (let k = 0; k < rng.int(3, 6); k++) set(wx, y - k, '#');
    }
    idx++;
  }

  // summit
  plat(3, W - 4, 4);
  set(W >> 1, 3, 'G');

  const rows = g.map((r) => r.join(''));
  return {
    id: 'endless',
    biome: BIOME_ORDER[0],
    name: '끝없는 등반',
    en: 'ENDLESS ASCENT',
    par: 999,
    seed,
    endless: true,
    baseY,
    hint: '아래에서 조류가 밀려온다. 멈추지 마라.',
    rows,
  };
}
