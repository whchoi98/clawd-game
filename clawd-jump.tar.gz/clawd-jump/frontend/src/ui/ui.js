/**
 * DOM UI layer.
 *
 * The canvas draws the world; everything readable is real DOM. That buys crisp
 * text at any DPR, CSS transitions, focus rings, and screen-reader access for
 * free — none of which a canvas-drawn bitmap font can offer.
 *
 * Navigation is unified: mouse, touch, keyboard and gamepad all drive the same
 * "cursor" concept, so the menus feel identical on a controller and a trackpad.
 */
import { settings, progress, saveSettings, saveProgress, levelRecord, bestMs, resetProgress } from '../core/save.js';
import { audio } from '../core/audio.js';
import { keyLabel, DEFAULT_BINDS } from '../core/input.js';
import { BIOMES, BIOME_ORDER } from '../game/config.js';
import { CHAPTERS, LEVELS } from '../game/levels.js';
import { sky } from '../render/sky.js';
import { drawClawd, drawClawdPortrait, SKINS } from '../render/clawd.js';
import { fmtTime, clamp, clamp01 } from '../core/util.js';

/** Rebindable gameplay actions, in panel order. Also the conflict-check set. */
const BIND_ROWS = [
  ['left', '왼쪽'], ['right', '오른쪽'], ['up', '위 / 조준'], ['down', '아래 / 스톰프'],
  ['jump', '점프'], ['dash', '대시'], ['pause', '일시정지'], ['restart', '재시작'],
];

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

class UI {
  constructor() {
    this.screens = {};
    for (const el of $$('.screen')) this.screens[el.id.replace('scr-', '')] = el;
    this.stack = [];          // modal stack on top of the base screen
    this.base = 'boot';
    this.cursor = 0;
    this.navEls = [];
    this.handlers = {};
    this._navCd = 0;
    this._toastT = 0;
    this._lastHud = {};
    this._bindListening = null;

    this._wireClicks();
    this._buildSettings();
    this._buildCredits();
    this._wireTouch();
    this._wireOrientation();
  }

  on(evt, fn) { (this.handlers[evt] ||= []).push(fn); }
  emit(evt, arg) { for (const f of this.handlers[evt] || []) f(arg); }

  // ------------------------------------------------------------ screens
  show(name, { modal = false } = {}) {
    if (modal) {
      if (!this.stack.includes(name)) this.stack.push(name);
    } else {
      for (const m of this.stack) this._hide(m);
      this.stack.length = 0;
      if (this.base && this.base !== name) this._hide(this.base);
      this.base = name;
    }
    const el = this.screens[name];
    if (!el) return;
    el.classList.remove('is-leaving');
    el.classList.add('is-active');
    this._refreshNav();
  }

  closeModal() {
    const name = this.stack.pop();
    if (name) this._hide(name);
    this._refreshNav();
    return name;
  }

  get top() { return this.stack.length ? this.stack[this.stack.length - 1] : this.base; }

  _hide(name) {
    const el = this.screens[name];
    if (!el || !el.classList.contains('is-active')) return;
    el.classList.remove('is-active');
    el.classList.add('is-leaving');
    setTimeout(() => el.classList.remove('is-leaving'), 280);
  }

  // ------------------------------------------------------------ navigation
  _refreshNav() {
    const el = this.screens[this.top];
    if (!el) { this.navEls = []; return; }
    this.navEls = [...el.querySelectorAll('button:not([disabled]):not([hidden]), .card:not([disabled])')]
      .filter((n) => n.offsetParent !== null && !n.closest('[hidden]'));
    this.cursor = Math.max(0, this.navEls.findIndex((n) => n.classList.contains('menu__item')));
    this._paintCursor();
  }

  _paintCursor() {
    // Clear globally, not just within navEls: layering a dialog over a live
    // screen otherwise leaves the earlier screen's item highlighted too.
    for (const n of document.querySelectorAll('.is-cursor')) n.classList.remove('is-cursor');
    const n = this.navEls[this.cursor];
    if (n) n.classList.add('is-cursor');
  }

  /** Drive the cursor from unified input. Called each frame. */
  tick(input, dt) {
    if (this._bindListening) return;
    if (this.top === 'hud') return;
    this._navCd -= dt;
    const ay = input.axisY, ax = input.axisX;
    const step = (d) => {
      if (!this.navEls.length) return;
      this.cursor = (this.cursor + d + this.navEls.length) % this.navEls.length;
      this._paintCursor();
      this.navEls[this.cursor]?.scrollIntoView?.({ block: 'nearest' });
      audio.sfx('uiMove');
      this._navCd = 0.16;
    };
    if (this._navCd <= 0) {
      if (ay > 0.5) step(1);
      else if (ay < -0.5) step(-1);
      else if (this.top === 'select' && Math.abs(ax) > 0.5) step(ax > 0 ? 1 : -1);
    }
    if (input.hit('confirm') || input.hit('jump')) {
      const n = this.navEls[this.cursor];
      if (n) { n.click(); }
    } else if (input.hit('cancel')) {
      const el = this.screens[this.top];
      const back = el?.querySelector('[data-act="back"],[data-act="close"],[data-act="resume"]');
      if (back) back.click();
    }
  }

  // ------------------------------------------------------------ clicks
  _wireClicks() {
    document.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-act]');
      if (!btn) return;
      const act = btn.dataset.act;
      audio.init();
      audio.sfx(act === 'back' || act === 'close' || act === 'resume' ? 'uiBack' : 'uiSelect');
      this.emit('act', { act, btn });
    });
    document.addEventListener('pointerenter', (e) => {
      const n = e.target.closest?.('.menu__item,.card');
      if (!n) return;
      const i = this.navEls.indexOf(n);
      if (i >= 0 && i !== this.cursor) { this.cursor = i; this._paintCursor(); }
    }, true);
    for (const tab of $$('#set-tabs .tab')) {
      tab.addEventListener('click', () => {
        for (const t of $$('#set-tabs .tab')) t.classList.toggle('is-active', t === tab);
        for (const p of $$('.pane')) p.classList.toggle('is-active', p.dataset.pane === tab.dataset.tab);
        this._refreshNav();
      });
    }
  }

  // ------------------------------------------------------------ boot
  bootProgress(k, label) {
    $('#boot-fill').style.width = `${Math.round(clamp01(k) * 100)}%`;
    if (label) $('#boot-hint').textContent = label;
  }

  // ------------------------------------------------------------ title
  refreshTitle() {
    const last = progress.lastLevel;
    const btn = $('#title-menu [data-act="continue"]');
    if (last && LEVELS.some((l) => l.id === last)) {
      const lv = LEVELS.find((l) => l.id === last);
      btn.hidden = false;
      $('#continue-note').textContent = `${BIOMES[lv.biome].kr} · ${lv.name}`;
    } else btn.hidden = true;
    this._refreshNav();
  }

  // ------------------------------------------------------------ level select
  buildSelect() {
    const host = $('#sel-biomes');
    host.innerHTML = '';
    let done = 0;
    let unlockedCount = 0;
    for (const ch of CHAPTERS) {
      const b = BIOMES[ch.biome];
      const sec = document.createElement('div');
      const head = document.createElement('div');
      head.className = 'biome__name';
      head.innerHTML = `<span style="color:${b.crust}">${b.name}</span><b>${b.kr}</b>`;
      sec.appendChild(head);
      const grid = document.createElement('div');
      grid.className = 'biome__cards';
      for (let i = 0; i < ch.levels.length; i++) {
        const lv = ch.levels[i];
        const rec = progress.levels[lv.id];
        if (rec?.done) done++;
        const unlocked = this.isUnlocked(lv.id);
        if (unlocked) unlockedCount++;
        grid.appendChild(this._card(lv, i, rec, unlocked));
      }
      sec.appendChild(grid);
      host.appendChild(sec);
    }
    $('#sel-progress').textContent = `${done} / ${LEVELS.length} 구역 돌파 · ${unlockedCount} 해금`;
    this._refreshNav();
  }

  isUnlocked(id) {
    const idx = LEVELS.findIndex((l) => l.id === id);
    if (idx <= 0) return true;
    const prev = LEVELS[idx - 1];
    return !!progress.levels[prev.id]?.done;
  }

  _card(lv, i, rec, unlocked) {
    const b = BIOMES[lv.biome];
    const card = document.createElement('button');
    card.className = 'card';
    card.dataset.act = 'level';
    card.dataset.id = lv.id;
    if (!unlocked) { card.disabled = true; card.setAttribute('aria-disabled', 'true'); }

    const cv = document.createElement('canvas');
    cv.width = 320; cv.height = 200;
    const g = cv.getContext('2d');
    sky.drawThumb(g, 320, 200, b, lv.seed);
    // a tiny Clawd stands on the thumbnail horizon, not in the corner
    g.save();
    g.translate(320 * 0.26, 200 * 0.86);
    g.scale(2.1, 2.1);
    drawClawd(g, null, {
      x: 0, y: 0, vx: 0, vy: 0, grounded: true, facing: 1, state: 'idle',
      t: i * 1.7, anim: 0, squash: 0, invuln: 0, blink: 0,
      skin: SKINS.clawd, dashReady: true, dashFlash: 0, alpha: 1,
    });
    g.restore();
    card.appendChild(cv);

    const stars = document.createElement('div');
    stars.className = 'card__stars';
    for (let s = 0; s < 3; s++) stars.appendChild(starSvg((rec?.stars || 0) > s));
    card.appendChild(stars);

    const body = document.createElement('div');
    body.className = 'card__body';
    const best = bestMs(lv.id);
    body.innerHTML = `
      <div class="card__idx">${b.name} · ${String(i + 1).padStart(2, '0')}</div>
      <div class="card__title">${lv.name}</div>
      <div class="card__meta">
        <span>${isFinite(best) ? fmtTime(best / 1000) : '—:——'}</span>
        <span>◈ ${rec?.bestShards || 0}</span>
        <span>${rec?.relics?.length ? '✦' : ''}</span>
      </div>`;
    card.appendChild(body);

    if (!unlocked) {
      const lock = document.createElement('div');
      lock.className = 'card__lock';
      lock.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
        stroke-linecap="round"><rect x="4.5" y="10.5" width="15" height="10.5" rx="2.5"/>
        <path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/></svg><span>잠김</span>`;
      card.appendChild(lock);
    }
    return card;
  }

  // ------------------------------------------------------------ HUD
  hudInit(level) {
    const hearts = $('#hud-hearts');
    hearts.innerHTML = '';
    for (let i = 0; i < 3; i++) {
      const h = document.createElement('i');
      h.className = 'heart';
      hearts.appendChild(h);
    }
    $('#hud-shards-total').textContent = `/${level.totalShards}`;
    $('#hud-relic-chip').style.display = level.totalRelics > 0 ? '' : 'none';
    $('#hud-relics').textContent = '0';
    $('#hud-relic-chip').querySelector('em').textContent = `/${level.totalRelics}`;
    $('#hud-level').textContent = `${BIOMES[level.biomeId].name} · ${level.name}`;
    $('#hud-timer').style.display = settings.showTimer ? '' : 'none';
    this._lastHud = {};
    $('#hud-touch').hidden = !this.touchMode;
  }

  hudUpdate(world) {
    const L = this._lastHud;
    const p = world.player;

    if (p.hp !== L.hp) {
      $('#hud-hearts').setAttribute('aria-label', `체력 ${p.hp} / 3`);
      this._announce(`체력 ${p.hp}`);
      const hs = $$('#hud-hearts .heart');
      hs.forEach((h, i) => {
        const on = i < p.hp;
        h.classList.toggle('off', !on);
        if (L.hp !== undefined && i === p.hp && !on) h.classList.add('pulse');
      });
      setTimeout(() => $$('#hud-hearts .heart').forEach((h) => h.classList.remove('pulse')), 500);
      L.hp = p.hp;
    }
    if (world.stats.shards !== L.shards) {
      this._announce(`파편 ${world.stats.shards} / ${world.level.totalShards}`);
      $('#hud-shards').textContent = world.stats.shards;
      bump($('.hud__chip--shard'));
      L.shards = world.stats.shards;
    }
    if (world.stats.relics !== L.relics) {
      $('#hud-relics').textContent = world.stats.relics;
      bump($('#hud-relic-chip'));
      L.relics = world.stats.relics;
    }
    if (settings.showTimer !== L.showTimer) {
      $('#hud-timer').style.display = settings.showTimer ? '' : 'none';
      L.showTimer = settings.showTimer;
    }
    if (settings.showTimer) {
      const t = fmtTime(world.runT);
      if (t !== L.time) { $('#hud-timer').textContent = t; L.time = t; }
    }
    // dash meter
    const dash = $('#hud-dash');
    const ready = p.dashReady && p.dashCd <= 0;
    const k = ready ? 1 : clamp01(1 - p.dashCd / 0.22);
    dash.classList.toggle('show', !ready || p.dashFlash > 0.05);
    dash.firstElementChild.style.transform = `scaleX(${k})`;
  }

  /**
   * Push gameplay state to a polite live region. Throttled: shard pickups can
   * land several times a second and a screen reader would never catch up.
   */
  _announce(text) {
    const now = performance.now();
    if (now - (this._srAt || 0) < 900) { this._srPending = text; return; }
    this._srAt = now;
    this._srPending = null;
    const el = $('#hud-sr');
    if (el) el.textContent = text;
  }

  toast(text, color) {
    const el = $('#hud-toast');
    el.textContent = text;
    el.style.color = color || '#fff';
    el.classList.remove('show');
    void el.offsetWidth;
    el.classList.add('show');
  }

  banner(text, color) {
    const el = $('#hud-banner');
    el.textContent = text;
    el.style.color = color || '#fff';
    el.classList.remove('show');
    void el.offsetWidth;
    el.classList.add('show');
  }

  // ------------------------------------------------------------ results
  showResult(sum, lv, isBest, newStars) {
    $('#res-rank').textContent = sum.rank;
    $('#res-rank').dataset.rank = sum.rank;
    $('#res-title').textContent = '구역 돌파';
    const rows = $('#res-rows');
    const best = bestMs(lv.id);
    rows.innerHTML = `
      <div class="res__row${isBest ? ' best' : ''}"><span>기록${isBest ? ' · 신기록!' : ''}</span><b>${fmtTime(sum.time)}</b></div>
      <div class="res__row"><span>최고 기록</span><b>${isFinite(best) ? fmtTime(best / 1000) : '—'}</b></div>
      <div class="res__row"><span>목표 시간</span><b>${fmtTime(sum.par)}</b></div>
      <div class="res__row"><span>파편</span><b>${sum.shards} / ${sum.totalShards}</b></div>
      ${sum.totalRelics ? `<div class="res__row"><span>유물</span><b>${sum.relics} / ${sum.totalRelics}</b></div>` : ''}
      <div class="res__row"><span>쓰러진 횟수</span><b>${sum.deaths}</b></div>`;
    const st = $('#res-stars');
    st.innerHTML = '';
    for (let i = 0; i < 3; i++) st.appendChild(starSvg(newStars > i));
    const next = $('#scr-result [data-act="next"]');
    const idx = LEVELS.findIndex((l) => l.id === lv.id);
    next.hidden = idx < 0 || idx >= LEVELS.length - 1;
    this.show('result', { modal: true });
    if (newStars > 0) setTimeout(() => audio.sfx('star'), 220);
  }

  showPause(world) {
    $('#pause-stats').innerHTML = `
      <div><b>${fmtTime(world.runT)}</b>경과</div>
      <div><b>${world.stats.shards}/${world.level.totalShards}</b>파편</div>
      <div><b>${world.stats.deaths}</b>사망</div>`;
    this.show('pause', { modal: true });
  }

  // ------------------------------------------------------------ settings
  _buildSettings() {
    const av = $('#pane-av');
    av.innerHTML = '';
    av.append(
      sliderRow('마스터 볼륨', 'master', 0, 1, 0.05, () => audio.applySettings()),
      sliderRow('음악', 'music', 0, 1, 0.05, () => audio.applySettings()),
      sliderRow('효과음', 'sfx', 0, 1, 0.05, () => { audio.applySettings(); audio.sfx('uiSelect'); }),
      segRow('화질', 'quality', [['auto', '자동'], ['high', '높음'], ['balanced', '균형'], ['low', '낮음']]),
      segRow('캐릭터', 'skin', Object.values(SKINS).map((s2) => [s2.id, s2.kr])),
      toggleRow('블룸 (발광)', 'bloom', '발광체 주변의 빛 번짐'),
      toggleRow('필름 그레인', 'grain', '미세한 입자감'),
      sliderRow('화면 흔들림', 'shake', 0, 1, 0.1),
    );

    const ctrl = $('#pane-ctrl');
    ctrl.innerHTML = '';
    for (const [action, label] of BIND_ROWS) ctrl.appendChild(this._bindRow(action, label));
    const reset = document.createElement('div');
    reset.className = 'row';
    reset.innerHTML = '<div class="row__label">기본값으로</div>';
    const rb = document.createElement('button');
    rb.className = 'bindbtn';
    rb.textContent = 'RESET';
    rb.onclick = () => {
      settings.binds = structuredClone(DEFAULT_BINDS);
      saveSettings();
      this.emit('rebind', settings.binds);
      this._buildSettings();
      audio.sfx('uiBack');
    };
    reset.appendChild(rb);
    ctrl.appendChild(reset);

    const a11y = $('#pane-a11y');
    a11y.innerHTML = '';
    a11y.append(
      toggleRow('보조 모드', 'assist', '중력 완화 · 3단 점프 · 짧은 대시 쿨다운'),
      toggleRow('무적', 'invincible', '가시와 적에게 피해를 입지 않는다'),
      toggleRow('섬광 효과', 'flashes', '끄면 전체 화면 번쩍임을 억제한다'),
      toggleRow('타이머 표시', 'showTimer'),
    );
    const wipe = document.createElement('div');
    wipe.className = 'row';
    wipe.innerHTML = '<div class="row__label">진행도 초기화<small>되돌릴 수 없다</small></div>';
    const wb = document.createElement('button');
    wb.className = 'bindbtn';
    wb.textContent = 'WIPE';
    wb.onclick = () => {
      if (wb.dataset.armed) { resetProgress(); this.buildSelect(); this.refreshTitle(); wb.textContent = 'DONE'; }
      else { wb.dataset.armed = '1'; wb.textContent = '정말?'; wb.classList.add('listening'); }
    };
    wipe.appendChild(wb);
    a11y.appendChild(wipe);
  }

  _bindRow(action, label) {
    const row = document.createElement('div');
    row.className = 'row';
    row.innerHTML = `<div class="row__label">${label}</div>`;
    const ctl = document.createElement('div');
    ctl.className = 'row__ctl';
    for (let slot = 0; slot < 2; slot++) {
      const b = document.createElement('button');
      b.className = 'bindbtn';
      b.textContent = keyLabel(settings.binds[action]?.[slot]);
      b.onclick = () => {
        b.classList.add('listening');
        b.textContent = '입력…';
        this._bindListening = { action, slot, b };
        this.emit('capture', (code) => {
          this._bindListening = null;
          b.classList.remove('listening');
          // Refuse a key another gameplay action already owns. `confirm` and
          // `cancel` are excluded: they deliberately share Space and Escape with
          // jump and pause, so they are not conflicts.
          const clash = code && BIND_ROWS.find(([a]) =>
            a !== action && (settings.binds[a] || []).includes(code));
          if (clash) {
            b.classList.add('bindbtn--clash');
            b.textContent = `${clash[1]} 중복`;
            setTimeout(() => {
              b.classList.remove('bindbtn--clash');
              b.textContent = keyLabel(settings.binds[action]?.[slot]);
            }, 1400);
            return;
          }
          if (code) {
            const arr = (settings.binds[action] ||= []);
            arr[slot] = code;
            saveSettings();
            this.emit('rebind', settings.binds);
          }
          b.textContent = keyLabel(settings.binds[action]?.[slot]);
        });
      };
      ctl.appendChild(b);
    }
    row.appendChild(ctl);
    return row;
  }

  _buildCredits() {
    $('#credits-body').innerHTML = `
      <h3>설계</h3>
      <ul>
        <li>월드는 <code>&lt;canvas&gt;</code>, 읽는 모든 글자는 DOM — 어떤 해상도에서도 선명하고 스크린리더가 읽는다.</li>
        <li>캐릭터는 스프라이트 시트가 아니라 <b>절차적 리그</b>. 착지 스쿼시, 도약 스트레치, 지면을 향해 뻗는 다리가 물리값에서 직접 나온다.</li>
        <li>발광체는 1/4 해상도 별도 버퍼에 그린 뒤 블러·가산 합성 — Canvas2D에서 실사용 가능한 블룸.</li>
        <li>지형은 보이는 타일을 하나의 <code>Path2D</code>로 병합해 한 번에 칠한다. 암반 지층이 타일 경계를 넘어 연속된다.</li>
      </ul>
      <h3>감각</h3>
      <ul>
        <li>코요테 타임 · 점프 버퍼 · 가변 점프 높이 · 정점 중력 완화</li>
        <li>모서리 보정 — 1~3유닛 턱은 머리와 발이 알아서 미끄러진다</li>
        <li>8방향 대시 + 프리즈 프레임 · 히트스톱 · 트라우마 기반 화면 흔들림</li>
        <li>벽 슬라이드 / 벽 점프 (입력 잠금으로 킥이 항상 읽힌다)</li>
      </ul>
      <h3>사운드</h3>
      <ul>
        <li>게임 에셋(스프라이트 · 타일셋 · 오디오) 0바이트. 모든 효과음과 음악이 <code>WebAudio</code>로 실시간 합성된다. 외부에서 받는 것은 UI 서체뿐이다.</li>
        <li>생물권마다 조성·모드·템포가 다르고, 근처 위협에 따라 편성 밀도가 변한다.</li>
      </ul>
      <h3>조작</h3>
      <ul>
        <li>키보드 · 게임패드 · 터치 모두 같은 액션 레이어로 들어온다</li>
        <li>모든 키 재지정 가능 · 보조 모드 · 섬광 억제 · <code>prefers-reduced-motion</code>을 첫 실행 시 화면 흔들림 · 섬광 · 그레인 기본값에 반영</li>
      </ul>`;
  }

  /**
   * Ask a phone held upright to turn: the design box is 16:9 and a portrait
   * viewport would show a sliver of world with the touch pad on top of it.
   */
  _wireOrientation() {
    const nag = $('#nag-rotate');
    const check = () => {
      const portrait = innerHeight > innerWidth * 1.05;
      nag.hidden = !(this.touchMode && portrait);
    };
    addEventListener('resize', check);
    addEventListener('orientationchange', () => setTimeout(check, 120));
    check();
  }

  // ------------------------------------------------------------ touch
  _wireTouch() {
    this.touchMode = matchMedia('(hover: none) and (pointer: coarse)').matches;
    this.touch = { x: 0, y: 0, active: false, jump: false, dash: false };
    const pad = $('#tpad-move');
    const knob = pad.firstElementChild;
    let pid = null, cx = 0, cy = 0, R = 40;

    const start = (e) => {
      const t = e.changedTouches ? e.changedTouches[0] : e;
      const r = pad.getBoundingClientRect();
      cx = r.left + r.width / 2; cy = r.top + r.height / 2; R = r.width / 2;
      pid = t.identifier ?? 'm';
      this.touch.active = true;
      move(e);
    };
    const move = (e) => {
      if (!this.touch.active) return;
      const list = e.changedTouches || [e];
      for (const t of list) {
        if ((t.identifier ?? 'm') !== pid) continue;
        const dx = clamp((t.clientX - cx) / R, -1, 1);
        const dy = clamp((t.clientY - cy) / R, -1, 1);
        this.touch.x = Math.abs(dx) < 0.24 ? 0 : dx;
        this.touch.y = Math.abs(dy) < 0.3 ? 0 : dy;
        knob.style.translate = `${-50 + dx * 34}% ${-50 + dy * 34}%`;
      }
    };
    const end = () => {
      this.touch.active = false; this.touch.x = 0; this.touch.y = 0; pid = null;
      knob.style.translate = '-50% -50%';
    };
    pad.addEventListener('touchstart', (e) => { e.preventDefault(); start(e); }, { passive: false });
    pad.addEventListener('touchmove', (e) => { e.preventDefault(); move(e); }, { passive: false });
    pad.addEventListener('touchend', end);
    pad.addEventListener('touchcancel', end);

    for (const b of $$('[data-touch]')) {
      const key = b.dataset.touch;
      const on = (v) => (e) => { e.preventDefault(); this.touch[key] = v; };
      b.addEventListener('touchstart', on(true), { passive: false });
      b.addEventListener('touchend', on(false));
      b.addEventListener('touchcancel', on(false));
    }
  }
}

// ------------------------------------------------------------ widgets
function bump(el) {
  if (!el) return;
  el.classList.remove('bump');
  void el.offsetWidth;
  el.classList.add('bump');
}

function starSvg(on) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24');
  s.setAttribute('class', 'star' + (on ? ' on' : ''));
  const p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  p.setAttribute('d', 'M12 2l3.1 6.5 7 .9-5.1 4.9 1.3 7L12 18l-6.3 3.3 1.3-7L2 9.4l7-.9z');
  p.setAttribute('fill', on ? '#F4C95D' : '#6B6584');
  s.appendChild(p);
  return s;
}

function row(label, sub) {
  const r = document.createElement('div');
  r.className = 'row';
  r.innerHTML = `<div class="row__label">${label}${sub ? `<small>${sub}</small>` : ''}</div>`;
  const c = document.createElement('div');
  c.className = 'row__ctl';
  r.appendChild(c);
  return [r, c];
}

function toggleRow(label, key, sub) {
  const [r, c] = row(label, sub);
  const b = document.createElement('button');
  b.className = 'switch';
  b.setAttribute('role', 'switch');
  b.setAttribute('aria-checked', String(!!settings[key]));
  b.setAttribute('aria-label', label);
  b.onclick = () => {
    settings[key] = !settings[key];
    b.setAttribute('aria-checked', String(!!settings[key]));
    saveSettings();
    audio.sfx('uiSelect');
  };
  c.appendChild(b);
  return r;
}

function sliderRow(label, key, min, max, step, onInput) {
  const [r, c] = row(label);
  const i = document.createElement('input');
  i.type = 'range'; i.min = min; i.max = max; i.step = step;
  i.value = settings[key];
  i.setAttribute('aria-label', label);
  const v = document.createElement('span');
  v.className = 'row__val';
  const paint = () => { v.textContent = Math.round(settings[key] * 100) + '%'; };
  paint();
  i.oninput = () => { settings[key] = +i.value; paint(); saveSettings(); onInput?.(); };
  c.append(i, v);
  return r;
}

function segRow(label, key, opts) {
  const [r, c] = row(label);
  const seg = document.createElement('div');
  seg.className = 'seg';
  for (const [val, text] of opts) {
    const b = document.createElement('button');
    b.textContent = text;
    b.classList.toggle('on', settings[key] === val);
    b.onclick = () => {
      settings[key] = val;
      for (const x of seg.children) x.classList.toggle('on', x === b);
      saveSettings();
      audio.sfx('uiSelect');
    };
    seg.appendChild(b);
  }
  c.appendChild(seg);
  return r;
}

export const ui = new UI();
