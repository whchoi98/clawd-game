/**
 * The render target and post-processing chain.
 *
 * Two canvases are drawn every frame:
 *   • main  — opaque world, full resolution
 *   • glow  — emissive-only, quarter resolution, blurred and added back
 *
 * Keeping emission on its own low-res buffer is what makes real bloom
 * affordable in Canvas2D: the blur runs over 1/16th of the pixels, and the
 * upscale does the wide-radius spreading for free.
 *
 * Scaling strategy is "expand": the design box (VIEW_W x VIEW_H) is always
 * fully visible, and extra viewport aspect reveals *more* world rather than
 * cropping or letterboxing. Level design therefore only has to guarantee the
 * design box is safe.
 */
import { settings } from '../core/save.js';
import { clamp } from '../core/util.js';

export const VIEW_W = 512;
export const VIEW_H = 288;

/**
 * How much extra world an unusual viewport aspect may reveal before the frame is
 * letterboxed instead. Unbounded expansion showed ~185 units of empty space above
 * and below a 352-unit-tall level on a portrait window, and gave away 73% of a
 * level's width on an ultra-wide one.
 */
const MAX_EXPAND_W = 1.6;
const MAX_EXPAND_H = 1.35;

class Stage {
  constructor() {
    this.cv = document.getElementById('world');
    this.ctx = this.cv.getContext('2d', { alpha: false, desynchronized: true });

    this.gcv = document.createElement('canvas');
    this.gctx = this.gcv.getContext('2d');
    // ping-pong buffer: the blur runs at glow resolution, never at full res
    this.bcv = document.createElement('canvas');
    this.bctx = this.bcv.getContext('2d');

    this.grainCv = document.createElement('canvas');

    this.w = 0; this.h = 0; this.dpr = 1; this.scale = 1;
    this.viewW = VIEW_W; this.viewH = VIEW_H;
    this.glowDiv = 4;
    this.supportsFilter = typeof this.ctx.filter === 'string';
    this.quality = 'high';
    this._fpsAcc = 0; this._fpsN = 0; this._autoTimer = 0;

    this._buildGrain();
    this.resize();
    addEventListener('resize', () => this.resize());
    if (window.visualViewport) visualViewport.addEventListener('resize', () => this.resize());
  }

  _buildGrain() {
    const S = 128;
    this.grainCv.width = S; this.grainCv.height = S;
    const g = this.grainCv.getContext('2d');
    const img = g.createImageData(S, S);
    for (let i = 0; i < img.data.length; i += 4) {
      const v = 118 + Math.random() * 44;
      img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
      img.data[i + 3] = 255;
    }
    g.putImageData(img, 0, 0);
  }

  qualityScale() {
    const q = this.quality;
    return q === 'low' ? 0.66 : q === 'balanced' ? 0.85 : 1;
  }

  resize() {
    const cw = Math.max(320, innerWidth);
    const ch = Math.max(240, innerHeight);
    const maxDpr = this.quality === 'low' ? 1 : this.quality === 'balanced' ? 1.5 : 2;
    const dpr = clamp(devicePixelRatio || 1, 1, maxDpr) * this.qualityScale();

    this.cssW = cw; this.cssH = ch;
    this.w = Math.round(cw * dpr);
    this.h = Math.round(ch * dpr);
    this.dpr = dpr;
    if (this.cv.width !== this.w) this.cv.width = this.w;
    if (this.cv.height !== this.h) this.cv.height = this.h;

    // world-units -> device pixels. The design box always fits; anything past
    // the expansion cap becomes a letterbox bar rather than exposed void.
    this.scale = Math.min(this.w / VIEW_W, this.h / VIEW_H);
    this.viewW = Math.min(this.w / this.scale, VIEW_W * MAX_EXPAND_W);
    this.viewH = Math.min(this.h / this.scale, VIEW_H * MAX_EXPAND_H);
    this.rw = Math.round(this.viewW * this.scale);
    this.rh = Math.round(this.viewH * this.scale);
    this.ox = Math.round((this.w - this.rw) / 2);
    this.oy = Math.round((this.h - this.rh) / 2);

    this.glowDiv = this.quality === 'low' ? 6 : 4;
    this.gcv.width = Math.max(1, Math.round(this.w / this.glowDiv));
    this.gcv.height = Math.max(1, Math.round(this.h / this.glowDiv));
    this.bcv.width = this.gcv.width;
    this.bcv.height = this.gcv.height;
    this._vg = null;
    this._grainPat = null;

    this.ctx.imageSmoothingEnabled = true;
    this.gctx.imageSmoothingEnabled = true;
    this.bctx.imageSmoothingEnabled = true;
  }

  setQuality(q) {
    if (q === this.quality) return;
    this.quality = q;
    this.resize();
  }

  /** Adaptive quality: sustained low frame-rate steps the renderer down a notch. */
  sampleFps(dt) {
    if (settings.quality !== 'auto') { this.setQuality(settings.quality); return; }
    this._fpsAcc += dt; this._fpsN++;
    this._autoTimer += dt;
    if (this._autoTimer < 2.5) return;
    const avg = this._fpsN / this._fpsAcc;
    this._fpsAcc = 0; this._fpsN = 0; this._autoTimer = 0;
    if (avg < 42 && this.quality === 'high') this.setQuality('balanced');
    else if (avg < 34 && this.quality === 'balanced') this.setQuality('low');
    else if (avg > 58 && this.quality === 'low') this.setQuality('balanced');
    else if (avg > 58 && this.quality === 'balanced') this.setQuality('high');
  }

  /** Clear both buffers. `sky` paints the opaque backdrop. */
  begin() {
    const { ctx, gctx } = this;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    gctx.setTransform(1, 0, 0, 1, 0, 0);
    gctx.clearRect(0, 0, this.gcv.width, this.gcv.height);
  }

  /**
   * Push the camera transform onto both buffers.
   * Screen-space (HUD-ish) drawing should happen outside this.
   */
  world(camX, camY, shakeX = 0, shakeY = 0, zoom = 1, rot = 0) {
    const { ctx, gctx } = this;
    const s = this.scale * zoom;
    const cx = this.w / 2, cy = this.h / 2;
    for (const [g, div] of [[ctx, 1], [gctx, this.glowDiv]]) {
      g.setTransform(1, 0, 0, 1, 0, 0);
      g.scale(1 / div, 1 / div);
      g.translate(cx + shakeX * this.scale, cy + shakeY * this.scale);
      if (rot) g.rotate(rot);
      g.scale(s, s);
      g.translate(-camX, -camY);
    }
    this.camX = camX; this.camY = camY; this.zoom = zoom;
    this.wLeft = camX - this.viewW / (2 * zoom);
    this.wRight = camX + this.viewW / (2 * zoom);
    this.wTop = camY - this.viewH / (2 * zoom);
    this.wBottom = camY + this.viewH / (2 * zoom);
  }

  /** Screen space in world units: origin top-left, VIEW-relative. */
  screen() {
    const { ctx } = this;
    ctx.setTransform(1, 0, 0, 1, this.ox, this.oy);
    ctx.scale(this.scale, this.scale);
  }

  /** true if an AABB in world units could be visible (with margin). */
  visible(x, y, w, h, m = 24) {
    return x + w > this.wLeft - m && x < this.wRight + m && y + h > this.wTop - m && y < this.wBottom + m;
  }

  /** Composite glow + film effects. Call last. */
  composite(fx = {}) {
    const ctx = this.ctx;
    ctx.setTransform(1, 0, 0, 1, 0, 0);

    if (settings.bloom) {
      // Blur at glow resolution (1/16th the pixels), then let the bilinear
      // upscale widen the halo for free. Blurring during the upscale instead
      // would run the kernel over every output pixel — several times the cost.
      const gw = this.gcv.width, gh = this.gcv.height;
      const wide = this.quality !== 'low';
      let src = this.gcv;
      if (this.supportsFilter) {
        this.bctx.setTransform(1, 0, 0, 1, 0, 0);
        this.bctx.clearRect(0, 0, gw, gh);
        this.bctx.filter = `blur(${this.quality === 'high' ? 2.2 : 1.6}px)`;
        this.bctx.drawImage(this.gcv, 0, 0);
        this.bctx.filter = 'none';
        src = this.bcv;
      }
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.85;
      ctx.drawImage(src, 0, 0, this.w, this.h);
      if (wide) {
        // second, wider tap: draw the same buffer scaled up past the frame
        const k = 1.06;
        ctx.globalAlpha = 0.4;
        ctx.drawImage(src, -this.w * (k - 1) / 2, -this.h * (k - 1) / 2, this.w * k, this.h * k);
      }
      ctx.restore();
    }

    // chromatic fringe on impact — subtle, and only while `fx.aberr` is live
    if (fx.aberr > 0.01 && this.quality === 'high') {
      const o = fx.aberr * 5 * this.dpr;
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.13 * fx.aberr;
      ctx.drawImage(this.bcv, -o, 0, this.w, this.h);
      ctx.drawImage(this.bcv, o, 0, this.w, this.h);
      ctx.restore();
    }

    // vignette (cached: depends only on canvas size)
    if (!this._vg) {
      const vg = ctx.createRadialGradient(
        this.w / 2, this.h * 0.48, this.h * 0.3,
        this.w / 2, this.h * 0.5, this.h * 0.95);
      vg.addColorStop(0, 'rgba(0,0,0,0)');
      vg.addColorStop(0.6, 'rgba(2,1,6,0.16)');
      vg.addColorStop(1, 'rgba(2,1,6,0.62)');
      this._vg = vg;
    }
    ctx.fillStyle = this._vg;
    ctx.fillRect(0, 0, this.w, this.h);
    if (fx.vignette > 0.01) {
      ctx.save();
      ctx.globalAlpha = fx.vignette * 0.5;
      ctx.fillStyle = this._vg;
      ctx.fillRect(0, 0, this.w, this.h);
      ctx.restore();
    }

    if (settings.grain && this.quality !== 'low') {
      this._grainPat ||= ctx.createPattern(this.grainCv, 'repeat');
      ctx.save();
      ctx.globalCompositeOperation = 'overlay';
      ctx.globalAlpha = 0.032;
      const s = 128;
      ctx.translate(-Math.random() * s, -Math.random() * s);
      ctx.fillStyle = this._grainPat;
      ctx.fillRect(0, 0, this.w + s, this.h + s);
      ctx.restore();
    }

    if (fx.flash > 0.004) {
      ctx.save();
      ctx.globalAlpha = settings.flashes ? Math.min(1, fx.flash) : Math.min(0.22, fx.flash * 0.3);
      ctx.fillStyle = fx.flashColor || '#ffffff';
      ctx.fillRect(0, 0, this.w, this.h);
      ctx.restore();
    }
    if (fx.fade > 0.001) {
      ctx.save();
      ctx.globalAlpha = Math.min(1, fx.fade);
      ctx.fillStyle = fx.fadeColor || '#07060B';
      ctx.fillRect(0, 0, this.w, this.h);
      ctx.restore();
    }

    // Letterbox last, so it also trims the sky and film passes that paint the
    // whole canvas.
    if (this.ox > 0 || this.oy > 0) {
      ctx.fillStyle = '#07060B';
      if (this.oy > 0) {
        ctx.fillRect(0, 0, this.w, this.oy);
        ctx.fillRect(0, this.oy + this.rh, this.w, this.h - this.oy - this.rh);
      }
      if (this.ox > 0) {
        ctx.fillRect(0, 0, this.ox, this.h);
        ctx.fillRect(this.ox + this.rw, 0, this.w - this.ox - this.rw, this.h);
      }
    }
  }
}

export const stage = new Stage();
