/**
 * Terrain renderer.
 *
 * Passes, in order:
 *   1. every visible '#' tile merged into one Path2D, filled once with a baked,
 *      tileable rock texture — strata therefore run continuously across tile
 *      boundaries instead of repeating every 16 units
 *   2. per-tile depth shading: how deep a tile sits below the nearest surface
 *      drives a black overlay, which is what turns a flat mass into a cliff
 *   3. exposed-face detail (crust, bevel, ambient occlusion, cracks) — only
 *      tiles with an open face pay for it
 *   4. biome decoration on ledges
 *
 * Gradients and patterns are created once per level: CanvasGradient/Pattern
 * coordinates resolve in user space at paint time, so one object serves every
 * tile as long as the context is translated.
 */
import { TILE, C } from '../game/config.js';
import { stage } from './stage.js';
import { alpha, clamp01, fbm, hashStr, lerp, mixHex, noise2, TAU } from '../core/util.js';
import { settings } from '../core/save.js';

const ROCK_PX = 128;      // one texture repeat == 128 world units == 8 tiles

/**
 * Baked rock face: mottling + horizontal strata + pebbles, wrapped so it tiles.
 * Doing this once per biome means pass 1 is a single fill for the whole screen.
 */
function makeRockTexture(b) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = ROCK_PX;
  const g = cv.getContext('2d');

  // base + mottle, written straight into pixels (fastest and highest quality)
  const img = g.createImageData(ROCK_PX, ROCK_PX);
  const base = hexToRgb(b.rock);
  const hi = hexToRgb(b.rockHi);
  const lo = hexToRgb(b.rockDeep);
  for (let y = 0; y < ROCK_PX; y++) {
    // strata: a slow vertical band pattern with jittered edges
    const bandRaw = y / 21 + noise2(y * 0.08, 3.1) * 0.7;
    const band = Math.abs((bandRaw % 1) - 0.5) * 2;      // 0..1 triangle
    for (let x = 0; x < ROCK_PX; x++) {
      // wrapped domain -> seamless in both axes
      const u = (x / ROCK_PX) * TAU, v = (y / ROCK_PX) * TAU;
      const nx = Math.cos(u) * 1.9 + 5, ny = Math.sin(u) * 1.9 + 11;
      const mx = Math.cos(v) * 1.9 + 23, my = Math.sin(v) * 1.9 + 31;
      let n = fbm(nx * 1.6 + my * 0.3, ny * 1.6 + mx * 0.3, 4);
      n = n * 0.72 + band * 0.28;
      const t = clamp01((n - 0.28) * 1.7);
      const i = (y * ROCK_PX + x) * 4;
      // blend deep -> base -> highlight
      let r, gg, bb;
      if (t < 0.5) {
        const k = t * 2;
        r = lerp(lo[0], base[0], k); gg = lerp(lo[1], base[1], k); bb = lerp(lo[2], base[2], k);
      } else {
        const k = (t - 0.5) * 2;
        r = lerp(base[0], hi[0], k); gg = lerp(base[1], hi[1], k); bb = lerp(base[2], hi[2], k);
      }
      img.data[i] = r; img.data[i + 1] = gg; img.data[i + 2] = bb; img.data[i + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);

  // pebbles: small lit/shadowed dots, deterministic so the texture is stable
  for (let i = 0; i < 190; i++) {
    const h = hashStr(`p${i}${b.id}`);
    const x = h % ROCK_PX, y = (h >>> 9) % ROCK_PX;
    const r = 0.7 + ((h >>> 18) % 5) * 0.42;
    g.fillStyle = alpha(b.rockHi, 0.2 + ((h >>> 21) % 5) * 0.05);
    g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill();
    g.fillStyle = alpha(b.rockDeep, 0.3);
    g.beginPath(); g.arc(x + 0.5, y + r * 0.8, r * 0.8, 0, TAU); g.fill();
  }
  return cv;
}

function hexToRgb(h) {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export class Terrain {
  constructor(level, biome) {
    this.L = level;
    this.b = biome;
    this._build();
  }

  _build() {
    const ctx = stage.ctx;
    const b = this.b;

    this.rockCv = makeRockTexture(b);
    this.rockPat = ctx.createPattern(this.rockCv, 'repeat');

    // global tint: shallower rock catches the sky, deep rock goes cold
    const hPx = this.L.h * TILE;
    const tg = ctx.createLinearGradient(0, 0, 0, hPx);
    tg.addColorStop(0, alpha(b.skyLight, 0.16));
    tg.addColorStop(0.4, alpha(b.skyLight, 0.06));
    tg.addColorStop(1, alpha('#000010', 0.22));
    this.gTint = tg;

    // top-face crust
    const c = ctx.createLinearGradient(0, 0, 0, 9);
    c.addColorStop(0, mixHex(b.crustHi, '#ffffff', 0.15));
    c.addColorStop(0.16, b.crust);
    c.addColorStop(0.42, alpha(mixHex(b.crust, b.rockHi, 0.55), 0.7));
    c.addColorStop(1, alpha(b.rockHi, 0));
    this.gCrust = c;

    // sub-surface bounce light, two tiles deep
    const ss = ctx.createLinearGradient(0, 0, 0, TILE * 2);
    ss.addColorStop(0, alpha(b.crust, 0.3));
    ss.addColorStop(1, alpha(b.crust, 0));
    this.gSub = ss;

    const ao = ctx.createLinearGradient(0, 0, 0, 11);
    ao.addColorStop(0, 'rgba(0,0,0,0.55)');
    ao.addColorStop(1, 'rgba(0,0,0,0)');
    this.gAO = ao;

    const sl = ctx.createLinearGradient(0, 0, 6, 0);
    sl.addColorStop(0, alpha(b.crustHi, 0.3));
    sl.addColorStop(1, alpha(b.crustHi, 0));
    this.gSideL = sl;
    const sr = ctx.createLinearGradient(0, 0, -6, 0);
    sr.addColorStop(0, 'rgba(0,0,0,0.34)');
    sr.addColorStop(1, 'rgba(0,0,0,0)');
    this.gSideR = sr;


    // reusable depth-shade colour table
    this.depthCol = [];
    for (let d = 0; d < 12; d++) {
      this.depthCol.push(alpha('#0A0610', Math.min(0.4, d * 0.085)));
    }
  }

  refresh() { this._build(); }

  // ------------------------------------------------------------------ draw
  draw(t) {
    const L = this.L, b = this.b, ctx = stage.ctx;
    const x0 = Math.max(0, Math.floor(stage.wLeft / TILE) - 1);
    const x1 = Math.min(L.w - 1, Math.ceil(stage.wRight / TILE) + 1);
    const y0 = Math.max(0, Math.floor(stage.wTop / TILE) - 1);
    const y1 = Math.min(L.h - 1, Math.ceil(stage.wBottom / TILE) + 1);

    // ---------- pass 1: merged rock body ----------
    const path = new Path2D();
    let any = false;
    for (let ty = y0; ty <= y1; ty++) {
      let run = -1;
      for (let tx = x0; tx <= x1 + 1; tx++) {
        const solid = tx <= x1 && L.at(tx, ty) === '#';
        if (solid && run < 0) run = tx;
        else if (!solid && run >= 0) {
          path.rect(run * TILE, ty * TILE, (tx - run) * TILE, TILE);
          any = true;
          run = -1;
        }
      }
    }
    if (any) {
      ctx.save();
      ctx.fillStyle = this.rockPat;
      ctx.fill(path);
      ctx.fillStyle = this.gTint;
      ctx.fill(path);
      ctx.restore();
    }

    // ---------- pass 2: depth shading ----------
    // How deep a tile sits below the nearest surface drives a black overlay;
    // that is what turns a flat mass into a cliff face. Tiles are grouped by
    // depth into one Path2D each and filled once: a per-tile translucent
    // fillRect would antialias its own edges and double-blend against its
    // neighbour, printing a dark seam on every tile boundary.
    const depthPaths = [];
    const subPath = new Path2D();
    let hasSub = false;
    for (let tx = x0; tx <= x1; tx++) {
      let depth = 0;
      for (let k = 1; k <= 10; k++) {
        if (L.solid(tx, y0 - k)) depth++; else break;
      }
      for (let ty = y0; ty <= y1; ty++) {
        if (!L.solid(tx, ty)) { depth = 0; continue; }
        if (depth > 0) {
          const d = Math.min(11, depth);
          (depthPaths[d] ||= new Path2D()).rect(tx * TILE, ty * TILE, TILE, TILE);
        } else {
          // surface tile: warm bounce light spilling down from the crust
          subPath.rect(tx * TILE, ty * TILE, TILE, TILE * 2);
          hasSub = true;
        }
        depth++;
      }
    }
    ctx.save();
    for (let d = depthPaths.length - 1; d >= 1; d--) {
      if (!depthPaths[d]) continue;
      ctx.fillStyle = this.depthCol[d];
      ctx.fill(depthPaths[d]);
    }
    if (hasSub) {
      ctx.fillStyle = this.gSub;
      ctx.fill(subPath);
    }
    ctx.restore();

    // ---------- crumbling blocks ----------
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (L.at(tx, ty) !== 'X') continue;
        this._crumbleTile(ctx, tx, ty, t);
      }
    }

    // ---------- pass 3: exposed-face detail ----------
    ctx.save();
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (L.at(tx, ty) !== '#') continue;
        const up = L.solid(tx, ty - 1), dn = L.solid(tx, ty + 1);
        const lf = L.solid(tx - 1, ty), rt = L.solid(tx + 1, ty);
        if (up && dn && lf && rt) continue;

        ctx.save();
        ctx.translate(tx * TILE, ty * TILE);

        if (!lf) { ctx.fillStyle = this.gSideL; ctx.fillRect(0, 0, 6, TILE); }
        if (!rt) {
          ctx.save(); ctx.translate(TILE, 0);
          ctx.fillStyle = this.gSideR; ctx.fillRect(-6, 0, 6, TILE);
          ctx.restore();
        }

        if (!up) {
          ctx.fillStyle = this.gCrust;
          ctx.fillRect(0, 0, TILE, 9);
          // the lit lip varies slightly per tile so a long ledge is not a bar
          const lipH = 1.0 + ((hashStr(`l${tx},${ty}`) >>> 2) % 3) * 0.22;
          ctx.fillStyle = alpha(mixHex(b.crustHi, '#ffffff', 0.25), 0.8);
          ctx.fillRect(0, 0, TILE, lipH);
          // a couple of deterministic bumps break the perfect straight edge
          const hs = hashStr(`s${tx},${ty}`);
          ctx.fillStyle = alpha(b.crustHi, 0.55);
          ctx.beginPath();
          ctx.arc(((hs >>> 3) % 13) + 1.5, 1.4, 1.1 + ((hs >>> 9) % 3) * 0.3, Math.PI, TAU);
          ctx.fill();
          if ((hs & 1) === 0) {
            ctx.beginPath();
            ctx.arc(((hs >>> 13) % 13) + 1.5, 1.4, 0.9, Math.PI, TAU);
            ctx.fill();
          }
          ctx.fillStyle = alpha(b.rockDeep, 0.5);
          ctx.fillRect(0, 8, TILE, 0.9);
        }

        if (!dn) {
          ctx.save();
          ctx.translate(0, TILE);
          ctx.scale(1, -1);
          ctx.fillStyle = this.gAO;
          ctx.fillRect(0, 0, TILE, 11);
          ctx.restore();
          ctx.fillStyle = alpha('#000000', 0.32);
          ctx.fillRect(0, TILE - 1.6, TILE, 1.6);
          // stalactite nub
          const h3 = hashStr(`u${tx},${ty}`);
          if ((h3 & 3) === 0) {
            ctx.fillStyle = alpha(b.rockDeep, 0.85);
            const nx = (h3 >>> 4) % 11 + 3;
            ctx.beginPath();
            ctx.moveTo(nx - 1.6, TILE);
            ctx.lineTo(nx, TILE + 3 + ((h3 >>> 8) % 3));
            ctx.lineTo(nx + 1.6, TILE);
            ctx.closePath(); ctx.fill();
          }
        }

        const h2 = hashStr(`c${tx},${ty}`);
        if ((h2 & 7) === 0) {
          ctx.strokeStyle = alpha(b.rockDeep, 0.6);
          ctx.lineWidth = 0.8;
          const ax = (h2 >>> 3) % 12 + 2, ay = (h2 >>> 7) % 9 + 4;
          ctx.beginPath();
          ctx.moveTo(ax, ay);
          ctx.lineTo(ax + ((h2 >>> 11) % 5) - 2, ay + 4 + ((h2 >>> 13) % 4));
          ctx.stroke();
        }
        ctx.restore();
      }
    }
    ctx.restore();

    this._decor(t, x0, x1, y0, y1);
  }

  /** Crumbling block: visibly fragile, and it shudders once triggered. */
  _crumbleTile(ctx, tx, ty, t) {
    const L = this.L, b = this.b;
    const k = L.w * ty + tx;
    const timer = L.crumble.get(k);
    const px = tx * TILE, py = ty * TILE;
    ctx.save();
    if (timer !== undefined) {
      const shake = (1 - timer / 0.42) * 1.6;
      ctx.translate(px + (Math.random() - 0.5) * shake, py + (Math.random() - 0.5) * shake);
    } else {
      ctx.translate(px, py);
    }
    const g = ctx.createLinearGradient(0, 0, 0, TILE);
    g.addColorStop(0, mixHex(b.rockHi, b.crustHi, 0.3));
    g.addColorStop(0.5, b.rock);
    g.addColorStop(1, mixHex(b.rockDeep, '#000000', 0.2));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.roundRect(0.5, 0.5, TILE - 1, TILE - 1, 2);
    ctx.fill();
    ctx.strokeStyle = alpha(b.crustHi, timer !== undefined ? 0.95 : 0.5);
    ctx.lineWidth = 1;
    ctx.stroke();
    // fracture lines
    ctx.strokeStyle = alpha('#000000', 0.5);
    ctx.lineWidth = 0.8;
    const h = hashStr(`X${tx},${ty}`);
    ctx.beginPath();
    ctx.moveTo(2, 4 + (h % 5));
    ctx.lineTo(7 + ((h >>> 4) % 4), 8);
    ctx.lineTo(TILE - 2, 5 + ((h >>> 8) % 6));
    ctx.moveTo(6, TILE - 2);
    ctx.lineTo(8 + ((h >>> 12) % 3), 8);
    ctx.stroke();
    if (timer !== undefined) {
      ctx.fillStyle = alpha(C.danger, 0.25 * (1 - timer / 0.42));
      ctx.beginPath(); ctx.roundRect(0.5, 0.5, TILE - 1, TILE - 1, 2); ctx.fill();
    }
    ctx.restore();
  }

  /** Per-biome growth on ledges. Deterministic, so it never shimmers. */
  _decor(t, x0, x1, y0, y1) {
    const L = this.L, b = this.b, ctx = stage.ctx, gctx = stage.gctx;
    const kind = b.props[0];
    ctx.save();
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (L.at(tx, ty) !== '#' || L.solid(tx, ty - 1)) continue;
        const hs = hashStr(`d${tx},${ty}`);
        if ((hs & 7) > 2) continue;
        const px = tx * TILE + ((hs >>> 6) % 12) + 2;
        const py = ty * TILE;
        const sway = Math.sin(t * 1.4 + tx * 0.7) * 1.6;
        const sc = 0.7 + ((hs >>> 10) % 7) / 10;

        if (kind === 'coral') {
          // branching fan + a rounded polyp clump beside it
          const col = mixHex(b.crust, C.shard, ((hs >>> 3) & 1) ? 0.5 : 0.02);
          // soft fan body first, so the branches read as growing out of mass
          const fan = ctx.createRadialGradient(px, py - 4 * sc, 0, px, py - 4 * sc, 8 * sc);
          fan.addColorStop(0, alpha(col, 0.34));
          fan.addColorStop(1, alpha(col, 0));
          ctx.fillStyle = fan;
          ctx.beginPath();
          ctx.ellipse(px, py - 4 * sc, 7 * sc, 6 * sc, 0, Math.PI, TAU);
          ctx.fill();
          ctx.strokeStyle = alpha(col, 0.9);
          ctx.lineWidth = 1.5 * sc;
          ctx.lineCap = 'round';
          for (let i = -1; i <= 1; i++) {
            ctx.beginPath();
            ctx.moveTo(px, py);
            ctx.quadraticCurveTo(px + i * 3 + sway * 0.5, py - 6 * sc, px + i * 5 + sway, py - 11 * sc);
            ctx.stroke();
            if (i !== 0) {
              ctx.beginPath();
              ctx.moveTo(px + i * 2.4, py - 5 * sc);
              ctx.lineTo(px + i * 5.6, py - 7.5 * sc);
              ctx.stroke();
            }
          }
          ctx.fillStyle = alpha(mixHex(col, '#ffffff', 0.25), 0.75);
          for (let i = 0; i < 3; i++) {
            const bx = px - 4 + i * 3.4, br = 1.1 + ((hs >>> (i * 3)) % 3) * 0.35;
            ctx.beginPath(); ctx.arc(bx, py - br * 0.7, br, Math.PI, TAU); ctx.fill();
          }
        } else if (kind === 'crystal') {
          const h = (7 + ((hs >>> 8) % 8)) * sc;
          const w = 2.4 * sc;
          const col = ((hs >>> 5) & 1) ? b.crust : C.shard;
          const g2 = ctx.createLinearGradient(px - w, py - h, px + w, py);
          g2.addColorStop(0, mixHex(col, '#ffffff', 0.55));
          g2.addColorStop(1, col);
          ctx.fillStyle = g2;
          ctx.beginPath();
          ctx.moveTo(px, py - h); ctx.lineTo(px + w, py - h * 0.32); ctx.lineTo(px + w * 0.55, py);
          ctx.lineTo(px - w * 0.55, py); ctx.lineTo(px - w, py - h * 0.32);
          ctx.closePath(); ctx.fill();
          ctx.fillStyle = alpha('#ffffff', 0.55);
          ctx.fillRect(px - 0.45, py - h * 0.82, 0.9, h * 0.5);
          // a smaller companion shard
          ctx.fillStyle = alpha(col, 0.8);
          ctx.beginPath();
          ctx.moveTo(px + w * 1.6, py - h * 0.5); ctx.lineTo(px + w * 2.3, py);
          ctx.lineTo(px + w * 0.9, py);
          ctx.closePath(); ctx.fill();
          if (settings.bloom) {
            const pulse = 0.5 + 0.5 * Math.sin(t * 2 + tx);
            gctx.fillStyle = alpha(col, 0.3 * pulse);
            gctx.beginPath(); gctx.arc(px, py - h * 0.5, w * 1.8, 0, TAU); gctx.fill();
          }
        } else {
          const pulse = 0.4 + 0.6 * Math.abs(Math.sin(t * 1.7 + tx * 1.3));
          ctx.fillStyle = alpha(b.crustHi, 0.55 * pulse);
          ctx.beginPath();
          ctx.roundRect(px - 3.5, py - 1.8, 8, 2.6, 1.2);
          ctx.fill();
          ctx.fillStyle = alpha('#FFF0C0', 0.5 * pulse);
          ctx.fillRect(px - 2, py - 1.2, 5, 1);
          if (settings.bloom) {
            gctx.fillStyle = alpha('#FF6B35', 0.4 * pulse);
            gctx.beginPath(); gctx.arc(px, py - 1, 6, 0, TAU); gctx.fill();
          }
          // heat shimmer wisp
          if ((hs & 12) === 0) {
            ctx.strokeStyle = alpha('#FFB05A', 0.16);
            ctx.lineWidth = 1.1;
            ctx.beginPath();
            ctx.moveTo(px, py - 2);
            ctx.quadraticCurveTo(px + Math.sin(t * 2 + tx) * 3, py - 9, px + Math.sin(t * 1.4 + tx) * 4, py - 16);
            ctx.stroke();
          }
        }
      }
    }
    ctx.restore();
  }

  /** Spikes, water and one-way platforms are tile-anchored but drawn as props. */
  drawHazards(t) {
    const L = this.L, ctx = stage.ctx, gctx = stage.gctx;
    const x0 = Math.max(0, Math.floor(stage.wLeft / TILE) - 1);
    const x1 = Math.min(L.w - 1, Math.ceil(stage.wRight / TILE) + 1);
    const y0 = Math.max(0, Math.floor(stage.wTop / TILE) - 1);
    const y1 = Math.min(L.h - 1, Math.ceil(stage.wBottom / TILE) + 1);

    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        const ch = L.at(tx, ty);
        if (ch === '^' || ch === 'V' || ch === '{' || ch === '}') this._spike(ctx, gctx, tx, ty, ch, t);
        else if (ch === '=') this._platform(ctx, tx, ty, t);
        else if (ch === '~' || ch === 'W') this._water(ctx, gctx, tx, ty, ch, t);
      }
    }
  }

  _spike(ctx, gctx, tx, ty, ch, t) {
    const px = tx * TILE, py = ty * TILE;
    const pulse = 0.55 + 0.45 * Math.sin(t * 4 + tx * 0.9 + ty);
    ctx.save();
    ctx.translate(px + TILE / 2, py + TILE / 2);
    if (ch === 'V') ctx.rotate(Math.PI);
    else if (ch === '{') ctx.rotate(Math.PI / 2);
    else if (ch === '}') ctx.rotate(-Math.PI / 2);
    ctx.translate(-TILE / 2, -TILE / 2);

    const spb = this.b.spike || { lo: '#5E5370', mid: '#CFC2DA' };
    const bg = ctx.createLinearGradient(0, TILE, 0, TILE - 5);
    bg.addColorStop(0, mixHex(spb.lo, '#000000', 0.4));
    bg.addColorStop(1, spb.lo);
    ctx.fillStyle = bg;
    ctx.fillRect(0, TILE - 4.5, TILE, 4.5);

    const sp = this.b.spike || { hi: '#FFF2F5', mid: '#CFC2DA', lo: '#5E5370' };
    for (let i = 0; i < 3; i++) {
      const bx = 1.6 + i * 4.6;
      const h = i === 1 ? 13.5 : 11;
      const g = ctx.createLinearGradient(bx, TILE - h, bx + 4, TILE);
      g.addColorStop(0, sp.hi);
      g.addColorStop(0.42, sp.mid);
      g.addColorStop(1, sp.lo);
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(bx + 2, TILE - h);
      ctx.lineTo(bx + 4.1, TILE - 2);
      ctx.lineTo(bx - 0.1, TILE - 2);
      ctx.closePath();
      ctx.fill();
      // a narrow hot tip, not a candy stripe
      ctx.fillStyle = alpha(C.danger, 0.42 * pulse);
      ctx.beginPath();
      ctx.moveTo(bx + 2, TILE - h);
      ctx.lineTo(bx + 2.65, TILE - h * 0.58);
      ctx.lineTo(bx + 1.35, TILE - h * 0.58);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();

    if (settings.bloom) {
      gctx.fillStyle = alpha(C.danger, 0.1 * pulse);
      gctx.fillRect(px + 3, py + 3, TILE - 6, TILE - 7);
    }
  }

  _platform(ctx, tx, ty, t) {
    const px = tx * TILE, py = ty * TILE;
    const b = this.b;
    ctx.save();
    ctx.translate(px, py);
    const g = ctx.createLinearGradient(0, 0, 0, 6);
    g.addColorStop(0, mixHex(b.crustHi, '#ffffff', 0.3));
    g.addColorStop(0.45, b.crust);
    g.addColorStop(1, mixHex(b.rock, '#000000', 0.25));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.roundRect(0, 0, TILE, 5.5, [2.5, 2.5, 1, 1]);
    ctx.fill();
    ctx.fillStyle = alpha('#000000', 0.34);
    ctx.fillRect(1, 5.5, TILE - 2, 1.4);
    ctx.restore();
  }

  _water(ctx, gctx, tx, ty, ch, t) {
    const px = tx * TILE, py = ty * TILE;
    ctx.save();
    if (ch === '~') {
      const wob = Math.sin(t * 2.2 + tx * 0.8) * 1.5;
      const g = ctx.createLinearGradient(0, py, 0, py + TILE);
      g.addColorStop(0, alpha('#8FE6FF', 0.5));
      g.addColorStop(1, alpha(C.water, 0.5));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(px, py + 2 + wob);
      ctx.quadraticCurveTo(px + TILE / 2, py - 1 + wob, px + TILE, py + 2 - wob);
      ctx.lineTo(px + TILE, py + TILE);
      ctx.lineTo(px, py + TILE);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = alpha('#CFF6FF', 0.65);
      ctx.lineWidth = 0.9;
      ctx.beginPath();
      ctx.moveTo(px, py + 2 + wob);
      ctx.quadraticCurveTo(px + TILE / 2, py - 1 + wob, px + TILE, py + 2 - wob);
      ctx.stroke();
      if (settings.bloom) {
        gctx.fillStyle = alpha('#8FE6FF', 0.12);
        gctx.fillRect(px, py, TILE, 4);
      }
    } else {
      ctx.fillStyle = alpha(C.water, 0.45);
      ctx.fillRect(px, py, TILE, TILE);
      const caustic = 0.05 + 0.05 * Math.sin(t * 1.6 + tx * 0.6 + ty * 0.4);
      ctx.fillStyle = alpha('#BFF0FF', caustic);
      ctx.fillRect(px, py, TILE, TILE);
    }
    ctx.restore();
  }
}
