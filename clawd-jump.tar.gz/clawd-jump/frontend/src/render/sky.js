/**
 * Parallax backdrop: sky gradient, celestial body with god rays, cloud bands,
 * three procedurally generated ridge silhouettes, and per-biome weather.
 *
 * Ridges are drawn as paths rather than baked bitmaps — 64 segments per layer
 * is nothing for the rasteriser, and it buys us sub-pixel parallax plus real
 * gradients that would band badly if they were pre-scaled.
 */
import { stage, VIEW_H } from './stage.js';
import { alpha, fbm, lerp, makeRng, TAU, clamp01, mixHex } from '../core/util.js';
import { settings } from '../core/save.js';

const RIDGE_SEGS = 72;
const RIDGE_SPAN = 1400; // world units per repeat

function buildRidge(rng, amp, base, rough) {
  const pts = new Float32Array(RIDGE_SEGS + 1);
  const o = rng() * 100;
  for (let i = 0; i <= RIDGE_SEGS; i++) {
    const u = i / RIDGE_SEGS;
    // wrap the noise domain so the profile tiles seamlessly
    const a = u * TAU;
    const nx = Math.cos(a) * 2.1 + o, ny = Math.sin(a) * 2.1 + o;
    let h = fbm(nx * rough, ny * rough, 5);
    // sharpen: ridged noise gives crests instead of rolling dunes
    h = 1 - Math.abs(h * 2 - 1);
    h = Math.pow(h, 0.75);
    pts[i] = base - h * amp;
  }
  pts[RIDGE_SEGS] = pts[0];
  return pts;
}

class Sky {
  constructor() {
    this.biome = null;
    this.layers = [];
    this.clouds = [];
    this.stars = [];
    this.weather = [];
    this.t = 0;
    this._grad = null;
    this._gradKey = '';
    this._lastCamX = 0;
  }

  setBiome(biome, seed = 1) {
    this.biome = biome;
    const rng = makeRng(seed * 7919 + 13);
    this.layers = [
      { pts: buildRidge(rng, 150, 220, 0.9), par: 0.08, col: biome.ridge[0], span: RIDGE_SPAN * 1.9, yoff: -30 },
      { pts: buildRidge(rng, 118, 250, 1.6), par: 0.17, col: biome.ridge[1], span: RIDGE_SPAN * 1.2, yoff: 6 },
      { pts: buildRidge(rng, 88, 280, 2.7), par: 0.30, col: biome.ridge[2], span: RIDGE_SPAN * 0.82, yoff: 30 },
    ];
    this.clouds = [];
    const nC = biome.id === 'glass' ? 5 : 9;
    for (let i = 0; i < nC; i++) {
      this.clouds.push({
        x: rng() * 2400, y: 30 + rng() * 150,
        r: 26 + rng() * 74, sq: 0.28 + rng() * 0.3,
        par: 0.05 + rng() * 0.09, a: 0.06 + rng() * 0.14,
        drift: 2 + rng() * 6, seed: rng() * 100,
      });
    }
    // Mid-ground props fill the dead band between the horizon and the playfield.
    // Two layers at different parallax read as real depth; without them the
    // middle third of the screen is flat sky and the scene looks unfinished.
    this.props = [];
    for (const [par, count, scale, dark] of [[0.42, 13, 0.9, 0.2], [0.62, 9, 1.35, 0.05]]) {
      for (let i = 0; i < count; i++) {
        this.props.push({
          x: rng() * 3000,
          par,
          h: (52 + rng() * 66) * scale,
          w: (11 + rng() * 15) * scale,
          dark,
          seed: rng() * 1000,
          kind: biome.props[0],
          lean: (rng() - 0.5) * 0.18,
          arms: 3 + Math.floor(rng() * 3),
        });
      }
    }
    this.props.sort((a, b2) => a.par - b2.par);

    // The near canyon wall. Without it the band between the horizon and the
    // playfield is bare sky, which reads as an unfinished background no matter
    // how good the foreground is. This sits *behind* the playable terrain and
    // turns the scene into the inside of a canyon.
    this.wall = buildRidge(rng, 84, 220, 3.1);
    this.wallFissures = [];
    for (let i = 0; i < 11; i++) {
      this.wallFissures.push({ u: rng(), len: 0.25 + rng() * 0.5, w: 0.5 + rng() * 1.6, o: rng() });
    }

    this.stars = [];
    if (biome.id === 'glass') {
      for (let i = 0; i < 130; i++) {
        this.stars.push({ x: rng(), y: rng() * 0.62, r: rng() * 0.9 + 0.25, tw: rng() * TAU, sp: 1 + rng() * 3 });
      }
    }
    this.weather.length = 0;
    this._grad = null;
    this._gradKey = '';
  }

  _gradient(ctx) {
    const key = `${this.biome.id}|${stage.h}`;
    if (this._gradKey === key && this._grad) return this._grad;
    const g = ctx.createLinearGradient(0, 0, 0, stage.h);
    const s = this.biome.sky;
    for (let i = 0; i < s.length; i++) g.addColorStop(i / (s.length - 1), s[i]);
    this._grad = g; this._gradKey = key;
    return g;
  }

  update(dt, camX, camY) {
    this.t += dt;
    const b = this.biome;
    if (!b) return;
    const budget = stage.quality === 'low' ? 0.35 : stage.quality === 'balanced' ? 0.7 : 1;
    const want = Math.round((b.weather === 'snow' ? 110 : b.weather === 'ash' ? 90 : 70) * budget);

    // weather lives in normalised screen space so it survives camera cuts
    while (this.weather.length < want) {
      this.weather.push({
        x: Math.random(), y: Math.random(),
        vx: 0, vy: 0, r: 0, ph: Math.random() * TAU, sp: 0.4 + Math.random(),
      });
      this._initMote(this.weather[this.weather.length - 1], true);
    }
    while (this.weather.length > want) this.weather.pop();

    const dx = (camX - this._lastCamX);
    this._lastCamX = camX;

    for (const m of this.weather) {
      m.ph += dt * m.sp * 2.2;
      m.x += (m.vx * dt) / stage.viewW - (dx * 0.16) / stage.viewW;
      m.y += (m.vy * dt) / stage.viewH;
      if (b.weather === 'snow' || b.weather === 'motes') m.x += (Math.sin(m.ph) * 7 * dt) / stage.viewW;
      if (m.y > 1.05 || m.y < -0.06 || m.x < -0.08 || m.x > 1.08) this._initMote(m, false);
    }
  }

  _initMote(m, anywhere) {
    const b = this.biome;
    m.x = Math.random() * 1.1 - 0.05;
    if (b.weather === 'ash') {
      m.y = anywhere ? Math.random() : 1.04;
      m.vy = -(14 + Math.random() * 34);
      m.vx = (Math.random() - 0.5) * 22;
      m.r = 0.7 + Math.random() * 1.9;
      m.col = Math.random() < 0.35 ? '#FFB05A' : '#FF6B35';
      m.glow = Math.random() < 0.5 ? 0.9 : 0.3;
      m.a = 0.4 + Math.random() * 0.5;
    } else if (b.weather === 'snow') {
      m.y = anywhere ? Math.random() : -0.04;
      m.vy = 16 + Math.random() * 34;
      m.vx = (Math.random() - 0.5) * 14;
      m.r = 0.6 + Math.random() * 1.7;
      m.col = '#DDE8FF';
      m.glow = 0.35;
      m.a = 0.25 + Math.random() * 0.55;
    } else {
      m.y = anywhere ? Math.random() : Math.random();
      m.vy = -(4 + Math.random() * 14);
      m.vx = (Math.random() - 0.5) * 10;
      m.r = 0.5 + Math.random() * 1.4;
      m.col = Math.random() < 0.3 ? '#5BD8E0' : '#FFD9A8';
      m.glow = 0.8;
      m.a = 0.25 + Math.random() * 0.5;
    }
    m.sp = 0.4 + Math.random();
  }

  /**
   * Draw in device pixels (no world transform). `camX/camY` drive parallax.
   * Ridges are placed relative to the world so the horizon sits still while
   * the player climbs, which is what sells depth.
   */
  draw(camX, camY) {
    const b = this.biome;
    const ctx = stage.ctx, gctx = stage.gctx;
    if (!b) return;
    const W = stage.w, H = stage.h;
    const S = stage.scale;

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = this._gradient(ctx);
    ctx.fillRect(0, 0, W, H);

    // vertical drift: climbing reveals more sky, sinking reveals more haze
    const vert = clamp01((camY + 200) / 900);

    // ---------- stars ----------
    if (this.stars.length) {
      for (const s of this.stars) {
        const tw = 0.45 + 0.55 * Math.sin(this.t * s.sp + s.tw);
        const x = ((s.x * W - camX * 0.02 * S) % W + W) % W;
        const y = s.y * H - camY * 0.02 * S;
        if (y < -4 || y > H) continue;
        ctx.fillStyle = alpha('#EAF0FF', tw * 0.8);
        ctx.fillRect(x, y, s.r * stage.dpr, s.r * stage.dpr);
      }
    }

    // ---------- celestial body ----------
    const sun = b.sun;
    const sx = sun.x * W - camX * 0.03 * S;
    const sy = sun.y * H - camY * 0.05 * S + vert * 40;
    const sr = sun.r * S * 0.6;

    // god rays (cheap: a fan of soft triangles)
    if (stage.quality !== 'low') {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const rays = 7;
      for (let i = 0; i < rays; i++) {
        const a = (i / rays) * TAU + this.t * 0.035 + (i % 2 ? 0.2 : 0);
        const w = 0.05 + 0.035 * Math.sin(this.t * 0.6 + i * 2.1);
        const len = H * (1.1 + 0.3 * Math.sin(this.t * 0.4 + i));
        ctx.fillStyle = alpha(sun.glow, 0.035 + 0.02 * Math.sin(this.t * 0.9 + i));
        ctx.beginPath();
        ctx.moveTo(sx, sy);
        ctx.lineTo(sx + Math.cos(a - w) * len, sy + Math.sin(a - w) * len);
        ctx.lineTo(sx + Math.cos(a + w) * len, sy + Math.sin(a + w) * len);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
    }

    // disc + halo (halo also lands in the glow buffer so it blooms)
    const halo = ctx.createRadialGradient(sx, sy, 0, sx, sy, sr * 5.5);
    halo.addColorStop(0, alpha(sun.color, 0.5));
    halo.addColorStop(0.18, alpha(sun.glow, 0.34));
    halo.addColorStop(0.45, alpha(sun.glow, 0.1));
    halo.addColorStop(1, alpha(sun.glow, 0));
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.fillStyle = halo;
    ctx.fillRect(sx - sr * 7, sy - sr * 7, sr * 14, sr * 14);
    ctx.restore();
    if (sun.kind !== 'glow') {
      // An opaque core first, then an additive rim: purely additive over a mid
      // tone sky reads as haze, not as a body with an edge.
      const disc = ctx.createRadialGradient(sx - sr * 0.22, sy - sr * 0.26, sr * 0.04, sx, sy, sr * 0.86);
      disc.addColorStop(0, '#FFFFFF');
      disc.addColorStop(0.6, sun.color);
      disc.addColorStop(1, mixHex(sun.color, sun.glow, 0.55));
      ctx.fillStyle = disc;
      ctx.beginPath(); ctx.arc(sx, sy, sr * 0.86, 0, TAU); ctx.fill();
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      const rim = ctx.createRadialGradient(sx, sy, sr * 0.7, sx, sy, sr * 1.25);
      rim.addColorStop(0, alpha(sun.color, 0.55));
      rim.addColorStop(1, alpha(sun.glow, 0));
      ctx.fillStyle = rim;
      ctx.beginPath(); ctx.arc(sx, sy, sr * 1.25, 0, TAU); ctx.fill();
      ctx.restore();
    }

    gctx.setTransform(1, 0, 0, 1, 0, 0);
    const gd = stage.glowDiv;
    // Only a hint reaches the bloom buffer: the glow layer composites *over*
    // terrain, so a hot sun would shine straight through a cliff face.
    if (sun.kind !== 'glow') {
      gctx.fillStyle = alpha(sun.color, 0.3);
      gctx.beginPath(); gctx.arc(sx / gd, sy / gd, (sr * 0.7) / gd, 0, TAU); gctx.fill();
    }

    // ---------- cloud bands ----------
    for (const c of this.clouds) {
      const x = ((c.x + this.t * c.drift - camX * c.par) % 2400 + 2400) % 2400;
      const px = (x / 2400) * (W * 1.6) - W * 0.3;
      const py = c.y * S - camY * c.par * S * 0.5 + vert * 20;
      if (py > H + 100 || py < -160) continue;
      const r = c.r * S * 0.55;
      const g = ctx.createRadialGradient(px, py, 0, px, py, r);
      g.addColorStop(0, alpha(b.skyLight, c.a));
      g.addColorStop(0.55, alpha(b.fog, c.a * 0.5));
      g.addColorStop(1, alpha(b.fog, 0));
      ctx.save();
      ctx.translate(px, py); ctx.scale(1, c.sq); ctx.translate(-px, -py);
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(px, py, r, 0, TAU); ctx.fill();
      ctx.restore();
    }

    // ---------- ridges ----------
    // Far layers first, then props, then the nearest ridge — having the near
    // ridge cut across the props' bases is what makes them read as distant.
    this._ridges(camX, camY, 0, 2);
    this._drawProps(camX, camY, vert);
    this._ridges(camX, camY, 2, 3);
    this._backWall(camX, camY, vert);

    // ---------- atmospheric haze toward the horizon ----------
    const hz = ctx.createLinearGradient(0, H * 0.34, 0, H);
    hz.addColorStop(0, alpha(b.fog, 0));
    hz.addColorStop(0.55, alpha(b.fog, b.id === 'ember' ? 0.2 : 0.12));
    hz.addColorStop(1, alpha(b.fog, b.id === 'ember' ? 0.46 : 0.3));
    ctx.fillStyle = hz;
    ctx.fillRect(0, H * 0.34, W, H * 0.66);

    // ---------- weather ----------
    ctx.save();
    for (const m of this.weather) {
      const x = m.x * W, y = m.y * H;
      const r = m.r * S * 0.5;
      const a = m.a * (0.6 + 0.4 * Math.sin(m.ph));
      ctx.fillStyle = alpha(m.col, a);
      ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      if (m.glow > 0.4 && settings.bloom) {
        gctx.fillStyle = alpha(m.col, a * m.glow * 0.7);
        gctx.beginPath(); gctx.arc(x / gd, y / gd, (r * 1.8) / gd, 0, TAU); gctx.fill();
      }
    }
    ctx.restore();
  }

  _ridges(camX, camY, from, to) {
    const b = this.biome, ctx = stage.ctx;
    const W = stage.w, H = stage.h, S = stage.scale;
    for (let li = from; li < to; li++) {
      const L = this.layers[li];
      const pts = L.pts;
      const spanPx = L.span * S;
      const off = ((-camX * L.par * S) % spanPx + spanPx) % spanPx;
      const baseY = (H * 0.52) + L.yoff * S - camY * L.par * S;

      const grd = ctx.createLinearGradient(0, baseY - 150 * S, 0, H);
      grd.addColorStop(0, mixHex(L.col, b.skyLight, 0.22 - li * 0.05));
      grd.addColorStop(0.3, L.col);
      grd.addColorStop(1, mixHex(L.col, '#000000', 0.5));
      ctx.fillStyle = grd;

      ctx.beginPath();
      ctx.moveTo(-spanPx + off, H + 10);
      for (let rep = -1; rep <= Math.ceil(W / spanPx) + 1; rep++) {
        const x0 = rep * spanPx + off;
        for (let i = 0; i <= RIDGE_SEGS; i++) {
          const x = x0 + (i / RIDGE_SEGS) * spanPx;
          const y = baseY + (pts[i] - 220) * S * 0.55;
          if (rep === -1 && i === 0) ctx.lineTo(x, y); else ctx.lineTo(x, y);
        }
      }
      ctx.lineTo(W + spanPx, H + 10);
      ctx.closePath();
      ctx.fill();

      // rim light along the crest, lit from the sun side
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.strokeStyle = alpha(b.skyLight, 0.1 + li * 0.04);
      ctx.lineWidth = Math.max(1, 1.2 * S * 0.5);
      ctx.beginPath();
      for (let rep = 0; rep <= Math.ceil(W / spanPx) + 1; rep++) {
        const x0 = rep * spanPx + off - spanPx;
        for (let i = 0; i <= RIDGE_SEGS; i++) {
          const x = x0 + (i / RIDGE_SEGS) * spanPx;
          const y = baseY + (pts[i] - 220) * S * 0.55;
          if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
      }
      ctx.stroke();
      ctx.restore();
    }
  }

  /**
   * The canyon wall directly behind the playfield: a jagged crest with vertical
   * fissures and horizontal strata, close enough in parallax (0.72) that it
   * slides convincingly with the camera.
   */
  _backWall(camX, camY, vert) {
    const b = this.biome, ctx = stage.ctx;
    const W = stage.w, H = stage.h, S = stage.scale;
    const pts = this.wall;
    const par = 0.72;
    const spanPx = 1100 * S;
    const off = ((-camX * par * S) % spanPx + spanPx) % spanPx;
    const baseY = H * 0.70 - camY * par * S * 0.42 + vert * 34;

    const topOf = (x) => {
      // x in device px -> wall crest height
      const u = (((x - off) / spanPx) % 1 + 1) % 1;
      const i = u * RIDGE_SEGS;
      const i0 = Math.floor(i);
      const a = pts[i0], c = pts[Math.min(RIDGE_SEGS, i0 + 1)];
      return baseY + (lerp(a, c, i - i0) - 220) * S * 0.42;
    };

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(-4, H + 8);
    const steps = 120;
    for (let i = 0; i <= steps; i++) {
      const x = (i / steps) * (W + 8) - 4;
      ctx.lineTo(x, topOf(x));
    }
    ctx.lineTo(W + 8, H + 8);
    ctx.closePath();

    // Darker and flatter than the playable terrain: if the backdrop is lighter
    // than the foreground the depth cue inverts and the wall reads as a wall
    // you could stand on.
    const g = ctx.createLinearGradient(0, baseY - 90 * S, 0, H);
    g.addColorStop(0, mixHex(mixHex(b.rockDeep, b.fog, 0.26), '#000000', 0.34));
    g.addColorStop(0.3, mixHex(b.rockDeep, '#000000', 0.46));
    g.addColorStop(1, mixHex(b.rockDeep, '#000000', 0.72));
    ctx.fillStyle = g;
    ctx.fill();

    // strata + fissures live inside the wall silhouette
    ctx.clip();
    ctx.globalAlpha = 0.07;
    ctx.strokeStyle = mixHex(b.rockHi, b.fog, 0.3);
    ctx.lineWidth = Math.max(1, 1.6 * S * 0.4);
    for (let k = 0; k < 7; k++) {
      const y = baseY + (k * 34 + 18) * S * 0.42;
      if (y > H) break;
      ctx.beginPath();
      for (let i = 0; i <= 24; i++) {
        const x = (i / 24) * W;
        const yy = y + Math.sin(i * 0.9 + k * 2.1) * 3 * S * 0.4;
        if (i === 0) ctx.moveTo(x, yy); else ctx.lineTo(x, yy);
      }
      ctx.stroke();
    }
    ctx.globalAlpha = 0.13;
    ctx.strokeStyle = mixHex(b.rockDeep, '#000000', 0.5);
    for (const f of this.wallFissures) {
      const x = ((f.u * spanPx + off) % spanPx) - spanPx * 0.5 + W * 0.5;
      for (const rep of [-1, 0, 1]) {
        const fx = x + rep * spanPx;
        if (fx < -20 || fx > W + 20) continue;
        const ty = topOf(fx);
        ctx.lineWidth = f.w * S * 0.5;
        ctx.beginPath();
        ctx.moveTo(fx, ty);
        ctx.quadraticCurveTo(fx + (f.o - 0.5) * 22 * S * 0.4, ty + (H - ty) * f.len * 0.5,
                             fx + (f.o - 0.5) * 34 * S * 0.4, ty + (H - ty) * f.len);
        ctx.stroke();
      }
    }
    ctx.restore();

    // rim light along the crest, from the sun side
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = alpha(b.skyLight, 0.22);
    ctx.lineWidth = Math.max(1, 1.2 * S * 0.4);
    ctx.beginPath();
    for (let i = 0; i <= steps; i++) {
      const x = (i / steps) * (W + 8) - 4;
      if (i === 0) ctx.moveTo(x, topOf(x)); else ctx.lineTo(x, topOf(x));
    }
    ctx.stroke();
    ctx.restore();
  }

  /**
   * Silhouetted towers/spires/chimneys between the ridges and the playfield.
   * Each is a single filled path plus a one-sided rim light, so a full field of
   * 28 props costs about as much as one more ridge layer.
   */
  _drawProps(camX, camY, vert) {
    const b = this.biome, ctx = stage.ctx, gctx = stage.gctx;
    const W = stage.w, H = stage.h, S = stage.scale;
    const span = 3000;
    const sunSide = b.sun.x > 0.5 ? 1 : -1;

    for (const p of this.props) {
      const spanPx = span * S * 0.5;
      let px = ((p.x * S * 0.5 - camX * p.par * S) % spanPx + spanPx) % spanPx;
      // draw two copies so a prop never pops in at the screen edge
      for (const rep of [0, 1]) {
        const x = px - rep * spanPx;
        if (x < -140 * S || x > W + 140 * S) continue;
        const baseY = H * (0.60 + p.par * 0.22) - camY * p.par * S * 0.55 + vert * 26;
        const h = p.h * S * 0.5, w = p.w * S * 0.5;
        if (baseY - h > H || baseY < -40) continue;

        // atmospheric perspective: nearer props are darker, farther ones haze out
        const col = mixHex(mixHex(b.ridge[0], b.fog, p.dark), '#000000', 0.42 - p.par * 0.34);
        ctx.save();
        ctx.translate(x, baseY);
        ctx.rotate(p.lean * 0.4);
        ctx.fillStyle = col;

        if (p.kind === 'crystal' || p.kind === 'obsidian') {
          // faceted spire
          ctx.beginPath();
          ctx.moveTo(0, -h);
          ctx.lineTo(w * 0.55, -h * 0.42);
          ctx.lineTo(w * 0.4, 0);
          ctx.lineTo(-w * 0.45, 0);
          ctx.lineTo(-w * 0.6, -h * 0.4);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = alpha(b.skyLight, 0.16);
          ctx.beginPath();
          ctx.moveTo(0, -h);
          ctx.lineTo(sunSide * w * 0.55, -h * 0.42);
          ctx.lineTo(sunSide * w * 0.4, 0);
          ctx.lineTo(0, 0);
          ctx.closePath();
          ctx.fill();
        } else if (p.kind === 'vent') {
          // chimney with a widening base and a smoke plume
          ctx.beginPath();
          ctx.moveTo(-w * 0.34, -h);
          ctx.quadraticCurveTo(-w * 0.6, -h * 0.4, -w, 0);
          ctx.lineTo(w, 0);
          ctx.quadraticCurveTo(w * 0.6, -h * 0.4, w * 0.34, -h);
          ctx.closePath();
          ctx.fill();
          const sm = ctx.createLinearGradient(0, -h, 0, -h - h * 0.9);
          sm.addColorStop(0, alpha(b.fog, 0.22));
          sm.addColorStop(1, alpha(b.fog, 0));
          ctx.fillStyle = sm;
          ctx.beginPath();
          ctx.moveTo(-w * 0.3, -h);
          ctx.quadraticCurveTo(Math.sin(this.t * 0.5 + p.seed) * w, -h - h * 0.5, -w * 0.1, -h - h * 0.9);
          ctx.lineTo(w * 0.5, -h - h * 0.9);
          ctx.quadraticCurveTo(w * 0.9, -h - h * 0.4, w * 0.3, -h);
          ctx.closePath();
          ctx.fill();
        } else {
          // gorgonian sea fan: a tapering trunk that forks into fine branches
          ctx.strokeStyle = col;
          ctx.lineCap = 'round';
          ctx.lineWidth = Math.max(1, w * 0.3);
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.quadraticCurveTo(p.lean * w, -h * 0.5, p.lean * w * 2, -h * 0.72);
          ctx.stroke();
          const arms = p.arms;
          for (let i = 0; i < arms; i++) {
            const u = 0.28 + (i / arms) * 0.62;
            const side = i % 2 ? 1 : -1;
            const bx = p.lean * w * u * 2, by = -h * u;
            const len = h * (0.34 - u * 0.16);
            ctx.lineWidth = Math.max(0.8, w * (0.2 - u * 0.09));
            ctx.beginPath();
            ctx.moveTo(bx, by);
            ctx.quadraticCurveTo(bx + side * w * 0.5, by - len * 0.5, bx + side * w * 0.66, by - len);
            ctx.stroke();
            // twig tips
            ctx.lineWidth = Math.max(0.6, w * 0.08);
            for (const tw of [-0.5, 0.5]) {
              ctx.beginPath();
              ctx.moveTo(bx + side * w * 0.66, by - len);
              ctx.lineTo(bx + side * w * 0.66 + tw * w * 0.3, by - len - h * 0.07);
              ctx.stroke();
            }
          }
          // a small holdfast at the base so it doesn't look like it floats
          ctx.fillStyle = col;
          ctx.beginPath();
          ctx.ellipse(0, 0, w * 0.42, w * 0.16, 0, Math.PI, TAU);
          ctx.fill();
        }

        // rim light on the sun side
        ctx.strokeStyle = alpha(b.skyLight, 0.2 - p.par * 0.1);
        ctx.lineWidth = Math.max(0.8, 1.1 * S * 0.4);
        ctx.beginPath();
        ctx.moveTo(sunSide * w * 0.2, -h * 0.95);
        ctx.quadraticCurveTo(sunSide * w * 0.5, -h * 0.5, sunSide * w * 0.3, 0);
        ctx.stroke();
        ctx.restore();

        if (p.kind === 'crystal' && settings.bloom) {
          gctx.fillStyle = alpha(b.crust, 0.1);
          gctx.beginPath();
          gctx.arc(x / stage.glowDiv, (baseY - h * 0.7) / stage.glowDiv, (w * 0.8) / stage.glowDiv, 0, TAU);
          gctx.fill();
        }
      }
    }
  }

  /** Small standalone render used by the level-select cards. */
  drawThumb(ctx, w, h, biome, seed) {
    const rng = makeRng(seed);
    const g = ctx.createLinearGradient(0, 0, 0, h);
    for (let i = 0; i < biome.sky.length; i++) g.addColorStop(i / (biome.sky.length - 1), biome.sky[i]);
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    const sx = biome.sun.x * w, sy = biome.sun.y * h, sr = h * 0.09;
    const halo = ctx.createRadialGradient(sx, sy, 0, sx, sy, sr * 7);
    halo.addColorStop(0, alpha(biome.sun.color, 0.55));
    halo.addColorStop(1, alpha(biome.sun.glow, 0));
    ctx.fillStyle = halo; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = biome.sun.color;
    ctx.beginPath(); ctx.arc(sx, sy, sr, 0, TAU); ctx.fill();
    for (let li = 0; li < 3; li++) {
      const pts = buildRidge(rng, 60 - li * 12, 220, 1 + li * 0.8);
      ctx.fillStyle = biome.ridge[li];
      ctx.beginPath();
      ctx.moveTo(0, h);
      for (let i = 0; i <= RIDGE_SEGS; i++) {
        const x = (i / RIDGE_SEGS) * w;
        const y = h * (0.52 + li * 0.07) + (pts[i] - 220) * (h / VIEW_H) * 0.6;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(w, h); ctx.closePath(); ctx.fill();
    }
    ctx.fillStyle = alpha(biome.fog, 0.3);
    ctx.fillRect(0, h * 0.6, w, h * 0.4);
  }
}

export const sky = new Sky();
