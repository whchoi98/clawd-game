/**
 * Pooled particle system.
 *
 * One flat pre-allocated array; emitters overwrite the oldest slot when
 * saturated. No allocation, no GC spikes, and the draw loop is a single pass
 * over contiguous memory. Emissive particles are additionally stamped onto the
 * low-res glow buffer so they bloom.
 */
import { stage } from './stage.js';
import { alpha, clamp01, TAU } from '../core/util.js';

const CAP = 1400;

class P {
  constructor() {
    this.life = 0; this.max = 1;
    this.x = 0; this.y = 0; this.vx = 0; this.vy = 0;
    this.r = 1; this.r2 = 0;
    this.grav = 0; this.drag = 0.9;
    this.rot = 0; this.vrot = 0;
    this.kind = 0;          // 0 dot 1 square 2 spark 3 smoke 4 ring 5 tri 6 text
    this.col = '#fff'; this.col2 = null;
    this.glow = 0; this.a0 = 1;
    this.txt = null;
    this.bounce = 0;
    this.wobble = 0;
  }
}

class Particles {
  constructor() {
    this.pool = new Array(CAP);
    for (let i = 0; i < CAP; i++) this.pool[i] = new P();
    this.head = 0;
    this.count = 0;
  }

  _take() {
    const p = this.pool[this.head];
    this.head = (this.head + 1) % CAP;
    if (this.count < CAP) this.count++;
    return p;
  }

  clear() { for (const p of this.pool) p.life = 0; this.count = 0; }

  budget() {
    return stage.quality === 'low' ? 0.4 : stage.quality === 'balanced' ? 0.7 : 1;
  }

  // ------------------------------------------------------------ emitters
  /** Ground/landing dust: heavy, short-lived, spreads sideways. */
  dust(x, y, n = 8, dir = 0, col = '#ffffff', spd = 60) {
    n = Math.max(1, Math.round(n * this.budget()));
    for (let i = 0; i < n; i++) {
      const p = this._take();
      const a = (dir || 0) + (Math.random() - 0.5) * (dir ? 1.5 : TAU);
      const s = spd * (0.35 + Math.random() * 0.9);
      p.kind = 3; p.life = p.max = 0.28 + Math.random() * 0.4;
      p.x = x + (Math.random() - 0.5) * 6; p.y = y + (Math.random() - 0.5) * 3;
      p.vx = Math.cos(a) * s; p.vy = Math.sin(a) * s * 0.5 - Math.random() * 24;
      p.r = 2 + Math.random() * 4; p.grav = -14; p.drag = 0.86;
      p.col = col; p.glow = 0; p.a0 = 0.5; p.rot = Math.random() * TAU; p.vrot = 0;
    }
  }

  /** Sharp directional sparks that streak along their velocity. */
  spark(x, y, n = 10, col = '#fff', spd = 200, dir = null, spread = TAU, glow = 1) {
    n = Math.max(1, Math.round(n * this.budget()));
    for (let i = 0; i < n; i++) {
      const p = this._take();
      const a = (dir ?? 0) + (Math.random() - 0.5) * spread;
      const s = spd * (0.4 + Math.random() * 1.1);
      p.kind = 2; p.life = p.max = 0.16 + Math.random() * 0.3;
      p.x = x; p.y = y;
      p.vx = Math.cos(a) * s; p.vy = Math.sin(a) * s;
      p.r = 1 + Math.random() * 1.6; p.grav = 320; p.drag = 0.9;
      p.col = col; p.glow = glow; p.a0 = 1;
    }
  }

  /** Tumbling debris chunks. */
  chunk(x, y, n = 6, col = '#fff', spd = 130, glow = 0) {
    n = Math.max(1, Math.round(n * this.budget()));
    for (let i = 0; i < n; i++) {
      const p = this._take();
      const a = -Math.PI / 2 + (Math.random() - 0.5) * 2.4;
      const s = spd * (0.4 + Math.random());
      p.kind = 1; p.life = p.max = 0.5 + Math.random() * 0.6;
      p.x = x; p.y = y;
      p.vx = Math.cos(a) * s; p.vy = Math.sin(a) * s;
      p.r = 1.6 + Math.random() * 3; p.grav = 520; p.drag = 0.985;
      p.rot = Math.random() * TAU; p.vrot = (Math.random() - 0.5) * 16;
      p.col = col; p.glow = glow; p.a0 = 1; p.bounce = 0.4;
    }
  }

  /** Expanding stroked ring — reads as a shockwave. */
  ring(x, y, r0, r1, dur, col, width = 2, glow = 1) {
    const p = this._take();
    p.kind = 4; p.life = p.max = dur;
    p.x = x; p.y = y; p.vx = 0; p.vy = 0;
    p.r = r0; p.r2 = r1; p.grav = 0; p.drag = 1;
    p.col = col; p.glow = glow; p.a0 = 1; p.rot = width;
  }

  /** Soft drifting smoke/steam. */
  smoke(x, y, n = 4, col = '#ffffff', rise = 30, size = 6) {
    n = Math.max(1, Math.round(n * this.budget()));
    for (let i = 0; i < n; i++) {
      const p = this._take();
      p.kind = 3; p.life = p.max = 0.8 + Math.random() * 1.1;
      p.x = x + (Math.random() - 0.5) * 8; p.y = y + (Math.random() - 0.5) * 6;
      p.vx = (Math.random() - 0.5) * 18; p.vy = -rise * (0.5 + Math.random());
      p.r = size * (0.6 + Math.random() * 0.9); p.grav = -8; p.drag = 0.96;
      p.col = col; p.glow = 0; p.a0 = 0.32; p.wobble = Math.random() * TAU;
    }
  }

  /** Triangular glass/shell fragments. */
  tri(x, y, n = 5, col = '#fff', spd = 150, glow = 0.6) {
    n = Math.max(1, Math.round(n * this.budget()));
    for (let i = 0; i < n; i++) {
      const p = this._take();
      const a = Math.random() * TAU;
      const s = spd * (0.3 + Math.random());
      p.kind = 5; p.life = p.max = 0.5 + Math.random() * 0.5;
      p.x = x; p.y = y;
      p.vx = Math.cos(a) * s; p.vy = Math.sin(a) * s - 40;
      p.r = 2 + Math.random() * 3.5; p.grav = 480; p.drag = 0.99;
      p.rot = Math.random() * TAU; p.vrot = (Math.random() - 0.5) * 12;
      p.col = col; p.glow = glow; p.a0 = 1;
    }
  }

  /** Floating label, e.g. a shard combo count. */
  text(x, y, txt, col = '#fff', dur = 0.9, glow = 0.7) {
    const p = this._take();
    p.kind = 6; p.life = p.max = dur;
    p.x = x; p.y = y; p.vx = 0; p.vy = -34; p.grav = 26; p.drag = 0.97;
    p.txt = txt; p.col = col; p.glow = glow; p.a0 = 1; p.r = 9;
  }

  /** A single ambient mote — used by the weather system. */
  mote(x, y, vx, vy, r, col, life, glow = 0) {
    const p = this._take();
    p.kind = 0; p.life = p.max = life;
    p.x = x; p.y = y; p.vx = vx; p.vy = vy;
    p.r = r; p.grav = 0; p.drag = 1;
    p.col = col; p.glow = glow; p.a0 = 0.8; p.wobble = Math.random() * TAU;
  }

  // ------------------------------------------------------------ sim
  update(dt, solidAt) {
    for (let i = 0; i < CAP; i++) {
      const p = this.pool[i];
      if (p.life <= 0) continue;
      p.life -= dt;
      if (p.life <= 0) continue;
      if (p.kind === 4) continue; // rings are pure animation

      const d = Math.pow(p.drag, dt * 60);
      p.vx *= d; p.vy *= d;
      p.vy += p.grav * dt;
      if (p.wobble) { p.wobble += dt * 2.4; p.x += Math.sin(p.wobble) * 6 * dt; }
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.rot += p.vrot * dt;

      if (p.bounce && solidAt && p.vy > 0 && solidAt(p.x, p.y + p.r)) {
        p.y -= p.r * 0.5;
        p.vy = -p.vy * p.bounce;
        p.vx *= 0.7;
        p.vrot *= 0.6;
        if (Math.abs(p.vy) < 24) { p.bounce = 0; p.vy = 0; p.grav = 0; p.drag = 0.8; }
      }
    }
  }

  // ------------------------------------------------------------ draw
  draw(font) {
    const ctx = stage.ctx, gctx = stage.gctx;
    ctx.save(); gctx.save();
    ctx.lineCap = 'round';
    gctx.lineCap = 'round';

    for (let i = 0; i < CAP; i++) {
      const p = this.pool[i];
      if (p.life <= 0) continue;
      const t = p.life / p.max;             // 1 -> 0
      const age = 1 - t;
      if (!stage.visible(p.x - 20, p.y - 20, 40, 40, 8)) continue;

      const a = clamp01(t * 1.4) * p.a0;
      const g = p.glow > 0 ? gctx : null;

      switch (p.kind) {
        case 0: { // dot
          const r = p.r * (0.6 + t * 0.6);
          ctx.fillStyle = alpha(p.col, a);
          ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, TAU); ctx.fill();
          if (g) { g.fillStyle = alpha(p.col, a * p.glow); g.beginPath(); g.arc(p.x, p.y, r * 1.6, 0, TAU); g.fill(); }
          break;
        }
        case 1: { // square debris
          const s = p.r * (0.5 + t * 0.7);
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
          ctx.fillStyle = alpha(p.col, a); ctx.fillRect(-s, -s, s * 2, s * 2);
          ctx.restore();
          if (g) { g.fillStyle = alpha(p.col, a * p.glow * 0.8); g.fillRect(p.x - s, p.y - s, s * 2, s * 2); }
          break;
        }
        case 2: { // spark streak
          const sp = Math.hypot(p.vx, p.vy);
          const len = Math.min(16, sp * 0.028 + p.r);
          const nx = sp > 1 ? p.vx / sp : 0, ny = sp > 1 ? p.vy / sp : 1;
          ctx.strokeStyle = alpha(p.col, a);
          ctx.lineWidth = p.r * (0.5 + t);
          ctx.beginPath();
          ctx.moveTo(p.x - nx * len, p.y - ny * len);
          ctx.lineTo(p.x + nx * len * 0.35, p.y + ny * len * 0.35);
          ctx.stroke();
          if (g) {
            g.strokeStyle = alpha(p.col, a * p.glow);
            g.lineWidth = p.r * 2.2;
            g.beginPath();
            g.moveTo(p.x - nx * len, p.y - ny * len);
            g.lineTo(p.x + nx * len * 0.4, p.y + ny * len * 0.4);
            g.stroke();
          }
          break;
        }
        case 3: { // smoke puff
          const r = p.r * (0.7 + age * 1.5);
          const grd = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r);
          grd.addColorStop(0, alpha(p.col, a * 0.75));
          grd.addColorStop(1, alpha(p.col, 0));
          ctx.fillStyle = grd;
          ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, TAU); ctx.fill();
          break;
        }
        case 4: { // ring
          const r = p.r + (p.r2 - p.r) * (1 - Math.pow(t, 2.2));
          ctx.strokeStyle = alpha(p.col, a * 0.9);
          ctx.lineWidth = Math.max(0.4, p.rot * t);
          ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, TAU); ctx.stroke();
          if (g) {
            g.strokeStyle = alpha(p.col, a * p.glow);
            g.lineWidth = Math.max(0.6, p.rot * t * 1.8);
            g.beginPath(); g.arc(p.x, p.y, r, 0, TAU); g.stroke();
          }
          break;
        }
        case 5: { // triangle shard
          const s = p.r * (0.6 + t * 0.7);
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
          ctx.fillStyle = alpha(p.col, a);
          ctx.beginPath();
          ctx.moveTo(0, -s); ctx.lineTo(s * 0.9, s * 0.7); ctx.lineTo(-s * 0.9, s * 0.7);
          ctx.closePath(); ctx.fill();
          ctx.restore();
          if (g) {
            g.fillStyle = alpha(p.col, a * p.glow);
            g.beginPath(); g.arc(p.x, p.y, s * 1.4, 0, TAU); g.fill();
          }
          break;
        }
        case 6: { // floating text
          ctx.font = `800 ${p.r}px ${font}`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillStyle = alpha('#000000', a * 0.45);
          ctx.fillText(p.txt, p.x, p.y + 1);
          ctx.fillStyle = alpha(p.col, a);
          ctx.fillText(p.txt, p.x, p.y);
          if (g) {
            g.font = `800 ${p.r}px ${font}`;
            g.textAlign = 'center'; g.textBaseline = 'middle';
            g.fillStyle = alpha(p.col, a * p.glow * 0.9);
            g.fillText(p.txt, p.x, p.y);
          }
          break;
        }
      }
    }
    ctx.restore(); gctx.restore();
  }
}

export const particles = new Particles();
