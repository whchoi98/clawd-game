/**
 * Application shell: boot, the fixed-timestep loop, and the scene machine.
 *
 * The loop runs simulation at a fixed 120Hz and renders once per frame. Fixed
 * steps keep the physics identical on a 60Hz laptop and a 165Hz monitor, which
 * matters here because jump heights are tuned to the millisecond.
 */
import { stage } from './render/stage.js';
import { sky } from './render/sky.js';
import { particles } from './render/particles.js';
import { drawClawd, SKINS } from './render/clawd.js';
import { Input } from './core/input.js';
import { audio } from './core/audio.js';
import { settings, progress, saveProgress, saveSettings, levelRecord, bestMs } from './core/save.js';
import { ui } from './ui/ui.js';
import { World } from './game/world.js';
import { LEVELS, LEVEL_BY_ID } from './game/levels.js';
import { makeEndlessLevel } from './game/endless.js';
import { BIOMES, C, TILE } from './game/config.js';
import { alpha, clamp, clamp01, damp, fbm, fmtTime, lerp, makeRng, TAU } from './core/util.js';

const STEP = 1 / 120;
const MAX_STEPS = 8;

class App {
  constructor() {
    this.input = new Input(settings.binds);
    this.scene = 'boot';
    this.world = null;
    this.paused = false;
    this.acc = 0;
    this.last = performance.now();
    this.t = 0;
    this.titleBg = new TitleBackdrop();
    this.currentLevelId = null;

    ui.on('act', (e) => this.onAction(e));
    ui.on('rebind', (b) => this.input.setBinds(b));
    ui.on('capture', (cb) => this.input.capture(cb));

    addEventListener('visibilitychange', () => {
      if (document.hidden && this.scene === 'play' && !this.paused) this.pause();
    });
    // any first gesture unlocks WebAudio
    const unlock = () => { audio.init(); audio.applySettings(); };
    addEventListener('pointerdown', unlock, { once: true });
    addEventListener('keydown', unlock, { once: true });

    this.input.touch = ui.touch;
  }

  // ------------------------------------------------------------------ boot
  async boot() {
    ui.bootProgress(0.15, '렌더 파이프라인 구성…');
    await raf2();
    // warm the noise tiles and gradients before the first visible frame
    sky.setBiome(BIOMES.coral, 3);
    ui.bootProgress(0.4, '지형 텍스처 베이킹…');
    await raf2();
    try { await Promise.race([document.fonts.ready, wait(1400)]); } catch { /* no font API */ }
    ui.bootProgress(0.7, '레벨 로드…');
    await raf2();
    ui.buildSelect();
    ui.refreshTitle();
    ui.bootProgress(1, '준비 완료');
    await wait(240);
    this.scene = 'title';
    ui.show('title');
    booted = true;

    // Deterministic capture mode for automated visual checks. Headless browsers
    // throttle requestAnimationFrame, so a screenshot of the normal loop comes
    // back blank; this advances the simulation in fixed steps synchronously and
    // draws once. Never engaged without the query flag.
    const q = new URLSearchParams(location.search);
    if (q.has('shot')) { this._capture(q); return; }

    requestAnimationFrame((now) => { this.last = now; this.frame(now); });
  }

  /** @param {URLSearchParams} q  shot=<levelId|title|endless> frames=N hold=right,jump */
  _capture(q) {
    const id = q.get('shot') || 'title';
    const frames = Math.min(3000, Math.max(1, +(q.get('frames') || 120)));
    const hold = new Set((q.get('hold') || '').split(',').filter(Boolean));

    if (id === 'title') {
      for (let i = 0; i < frames; i++) this.titleBg.update(STEP * 2);
      this.titleBg.draw();
      // `ui=<screen>` renders a specific UI surface over the live backdrop so
      // menu layout can be reviewed without scripting clicks.
      const scr = q.get('ui');
      if (scr) {
        if (scr === 'select') { ui.buildSelect(); ui.show('select'); }
        else if (scr === 'result') {
          ui.showResult({ id: 'c1', time: 34.72, shards: 23, totalShards: 25, relics: 1,
                          totalRelics: 1, deaths: 1, par: 40, rank: 'A', win: true },
                        LEVEL_BY_ID.c1, true, 2);
        } else ui.show(scr, { modal: true });
      }
      document.documentElement.dataset.shot = 'ready';
      return;
    }
    if (q.has('audio')) { audio.init(); audio.applySettings(); }
    if (id === 'endless') this.startEndless(); else this.startLevel(id);

    // `at=x,y` drops the player anywhere in the level — used by the level
    // tooling to test a specific beat without playing up to it.
    const at = (q.get('at') || '').split(',').map(Number);
    if (at.length === 2 && at.every(Number.isFinite)) {
      this.world.player.reset(at[0], at[1]);
      this.world.respawn = { x: at[0], y: at[1] };
      this.world.camX = at[0];
      this.world.camY = at[1] - 12;
      this.world.camGroundY = this.world.camY;
    }

    // `pulse=jump:14,dash:70` taps an action every N steps. Held input alone
    // can never exercise jump or dash, because both read a press *edge*.
    const pulse = (q.get('pulse') || '').split(',').filter(Boolean).map((p) => {
      const [a, n] = p.split(':');
      return { a, n: Math.max(2, +n || 20) };
    });
    // `alt=N` flips the horizontal axis every N steps — the only way to model a
    // player alternating walls, which is what a wall-jump chain actually needs.
    const alt = Math.max(0, +(q.get('alt') || 0));
    // `bot=wall` models what a player actually does in a shaft: hold toward a
    // wall, and the moment you stick to it, jump and reverse. Fixed-direction or
    // fixed-period input can never validate a wall-jump chain.
    const bot = q.get('bot');
    let botDir = 1;
    let step = 0;
    const pressed = new Set();
    const released = new Set();
    const fake = {
      held: hold, pressed, released,
      axisX: (hold.has('right') ? 1 : 0) - (hold.has('left') ? 1 : 0),
      axisY: (hold.has('down') ? 1 : 0) - (hold.has('up') ? 1 : 0),
      down: (a) => hold.has(a) || pressed.has(a),
      hit: (a) => pressed.has(a),
      up_: (a) => released.has(a),
      reset: () => {},
    };
    const track = { maxX: 0, minY: 1e9, jumps: 0, dashes: 0, wallJumps: 0, hurts: 0 };
    for (let i = 0; i < frames; i++) {
      if (q.has('audio')) audio.tick(STEP);
      pressed.clear(); released.clear();
      step++;
      if (alt) {
        const dir = Math.floor(step / alt) % 2 ? -1 : 1;
        fake.axisX = dir;
        hold.delete(dir > 0 ? 'left' : 'right');
        hold.add(dir > 0 ? 'right' : 'left');
      }
      if (bot === 'wall') {
        const pl = this.world.player;
        if (pl.wallDir !== 0) { pressed.add('jump'); botDir = -pl.wallDir; }
        else if (pl.grounded) { pressed.add('jump'); }
        fake.axisX = botDir;
        hold.delete(botDir > 0 ? 'left' : 'right');
        hold.add(botDir > 0 ? 'right' : 'left');
      }
      for (const p of pulse) {
        if (step % p.n === 0) pressed.add(p.a);
        else if (step % p.n === 3) released.add(p.a);
      }
      const before = { j: this.world.stats.jumps, d: this.world.stats.dashes,
                       w: this.world.stats.wallJumps, hp: this.world.player.hp };
      this.world.update(STEP, fake);
      const pl = this.world.player;
      track.maxX = Math.max(track.maxX, pl.x);
      track.minY = Math.min(track.minY, pl.y);
      if (this.world.stats.jumps > before.j) track.jumps++;
      if (this.world.stats.dashes > before.d) track.dashes++;
      if (this.world.stats.wallJumps > before.w) track.wallJumps++;
      if (pl.hp < before.hp) track.hurts++;
    }
    this._track = track;
    this.world.draw();
    ui.hudUpdate(this.world);
    const w = this.world;
    document.documentElement.dataset.shot = JSON.stringify({
      cv: [stage.w, stage.h], dpr: +stage.dpr.toFixed(2), scale: +stage.scale.toFixed(3),
      view: [Math.round(stage.viewW), Math.round(stage.viewH)], q: stage.quality,
      cam: [Math.round(w.camX), Math.round(w.camY)],
      bounds: [Math.round(stage.wTop), Math.round(stage.wBottom)],
      level: [w.level.pxW, w.level.pxH],
      player: [Math.round(w.player.x), Math.round(w.player.y)], deaths: w.stats.deaths,
      shards: w.stats.shards, phase: w.phase,
      screen: [...document.querySelectorAll('.screen.is-active')].map((e) => e.id).join(','),
      rank: document.getElementById('res-rank')?.textContent || null,
      stars: [...document.querySelectorAll('#res-stars .star.on')].length,
      cleared: w.cleared,
      audio: audio.ready ? {
        state: audio.ctx.state, track: audio.trackName,
        step: audio._step, bar: audio._bar,
        master: +audio.master.gain.value.toFixed(2), voices: audio.voices, sfx: audio._lastSfx.size,
        intensity: +audio.intensity.toFixed(2),
      } : { state: 'uninit' },
      flood: w.endless ? { y: Math.round(w.floodY), speed: +w.floodSpeed.toFixed(1), height: Math.round(w.maxHeight) } : null,
      track: this._track && {
        maxX: Math.round(this._track.maxX), minY: Math.round(this._track.minY),
        jumps: this._track.jumps, dashes: this._track.dashes,
        wallJumps: this._track.wallJumps, hurts: this._track.hurts,
      },
    });
  }

  // ------------------------------------------------------------------ actions
  onAction({ act, btn }) {
    switch (act) {
      case 'play': {
        ui.buildSelect();
        ui.show('select');
        this.scene = 'select';
        break;
      }
      case 'continue':
        if (progress.lastLevel) this.startLevel(progress.lastLevel);
        break;
      case 'endless':
        this.startEndless();
        break;
      case 'settings':
        ui.show('settings', { modal: true });
        break;
      case 'credits':
        ui.show('credits', { modal: true });
        break;
      case 'close':
        ui.closeModal();
        break;
      case 'back':
        ui.show('title');
        this.scene = 'title';
        ui.refreshTitle();
        break;
      case 'level':
        this.startLevel(btn.dataset.id);
        break;
      case 'pause':
        this.pause();
        break;
      case 'resume':
        this.resume();
        break;
      case 'restart':
        ui.closeModal();
        this.paused = false;
        audio.setMuffle(false);
        this.startLevel(this.currentLevelId, { restart: true });
        break;
      case 'retry':
        ui.closeModal();
        if (this.endlessMode) this.startEndless();
        else this.startLevel(this.currentLevelId, { restart: true });
        break;
      case 'next': {
        const i = LEVELS.findIndex((l) => l.id === this.currentLevelId);
        ui.closeModal();
        if (i >= 0 && i < LEVELS.length - 1) this.startLevel(LEVELS[i + 1].id);
        break;
      }
      case 'recover':
        // Drop the broken world entirely rather than trying to resume it.
        while (ui.stack.length) ui.closeModal();
        errorShown = false;
        this.paused = false;
        this.world = null;
        this.endlessMode = false;
        audio.setMuffle(false);
        this.scene = 'title';
        ui.refreshTitle();
        ui.show('title');
        break;
      case 'reload':
        location.reload();
        break;
      case 'quit':
        ui.closeModal();
        this.paused = false;
        audio.setMuffle(false);
        this.world = null;
        this.scene = 'select';
        ui.buildSelect();
        ui.show('select');
        audio.play('menu', { intensity: 0.5 });
        break;
    }
  }

  pause() {
    if (this.paused || this.scene !== 'play') return;
    this.paused = true;
    audio.setMuffle(true);
    ui.showPause(this.world);
  }

  resume() {
    if (!this.paused) return;
    while (ui.stack.length) ui.closeModal();
    this.paused = false;
    audio.setMuffle(false);
    this.input.reset();
  }

  // ------------------------------------------------------------------ levels
  startLevel(id, { restart = false } = {}) {
    const def = LEVEL_BY_ID[id];
    if (!def) return;
    this.endlessMode = false;
    this.currentLevelId = id;
    progress.lastLevel = id;
    saveProgress();

    while (ui.stack.length) ui.closeModal();
    this.world = new World(def, { skin: settings.skin, onEvent: (e, d) => this.onWorldEvent(e, d) });
    this.paused = false;
    this.scene = 'play';
    ui.hudInit(this.world.level);
    ui.show('hud');
    audio.init();
    audio.setMuffle(false);
    audio.play(BIOMES[def.biome].track, { intensity: 0.75 });
    this.input.reset();
    if (!restart) {
      ui.banner(def.name, BIOMES[def.biome].crustHi);
      if (def.hint && !progress.seen[id]) {
        progress.seen[id] = true;
        saveProgress();
        setTimeout(() => ui.toast(def.hint, '#CFC9DC'), 2000);
      }
    }
  }

  startEndless() {
    const def = makeEndlessLevel();
    this.endlessMode = true;
    this.currentLevelId = 'endless';
    while (ui.stack.length) ui.closeModal();
    this.world = new World(def, { skin: settings.skin, onEvent: (e, d) => this.onWorldEvent(e, d) });
    this.paused = false;
    this.scene = 'play';
    ui.hudInit(this.world.level);
    document.getElementById('hud-level').textContent = 'ENDLESS ASCENT';
    document.getElementById('hud-relic-chip').style.display = '';
    ui.show('hud');
    audio.init();
    audio.play('endless', { intensity: 0.9 });
    this.input.reset();
    ui.banner('끝없는 등반', C.shardHi);
    setTimeout(() => ui.toast('아래에서 조류가 밀려온다', C.shardHi), 1700);
    progress.endless.runs++;
    saveProgress();
  }

  onWorldEvent(evt, data) {
    switch (evt) {
      case 'shard':
        if (data.total > 0 && data.n === data.total) ui.toast('파편 전부 회수', C.shardHi);
        break;
      case 'relic':
        ui.toast('유물 발견 ✦', C.relicHi);
        break;
      case 'checkpoint':
        ui.toast('기록 지점', C.checkpoint);
        break;
      case 'death':
        if (!this.endlessMode) ui.toast(deathLine(data.cause), C.dangerHi);
        break;
      case 'goal':
        // Endless generates a summit goal of its own; it must not go through the
        // story results path, which looks the level up in LEVEL_BY_ID.
        if (this.endlessMode) this.finishEndless(this.world.endlessSummary());
        else this.finishLevel(data);
        break;
      case 'endlessOver':
        this.finishEndless(data);
        break;
    }
  }

  finishLevel(sum) {
    const rec = levelRecord(sum.id);
    const prevBest = bestMs(sum.id);
    const ms = Math.round(sum.time * 1000);
    const isBest = ms < prevBest;
    rec.done = true;
    if (isBest) rec.bestMs = ms;
    rec.bestShards = Math.max(rec.bestShards || 0, sum.shards);
    if (sum.relics > 0 && !rec.relics.includes(sum.id)) rec.relics.push(sum.id);
    let stars = 1;
    if (sum.totalShards > 0 && sum.shards >= sum.totalShards) stars++;
    if (sum.time <= sum.par) stars++;
    rec.stars = Math.max(rec.stars || 0, stars);
    progress.totals.shards += sum.shards;
    progress.totals.deaths += sum.deaths;
    saveProgress();

    setTimeout(() => {
      ui.showResult({ ...sum, win: true }, LEVEL_BY_ID[sum.id], isBest, stars);
      audio.play('menu', { intensity: 0.45 });
    }, 1250);
  }

  finishEndless(sum) {
    const e = progress.endless;
    const isBest = sum.height > e.bestHeight;
    e.bestHeight = Math.max(e.bestHeight, sum.height);
    e.bestShards = Math.max(e.bestShards, sum.shards);
    saveProgress();
    setTimeout(() => {
      document.getElementById('res-rank').textContent = isBest ? '★' : `${sum.height}`;
      document.getElementById('res-rank').dataset.rank = isBest ? 'S' : 'A';
      document.getElementById('res-title').textContent = isBest ? '최고 높이 갱신' : '등반 종료';
      document.getElementById('res-rows').innerHTML = `
        <div class="res__row${isBest ? ' best' : ''}"><span>도달 높이</span><b>${sum.height} m</b></div>
        <div class="res__row"><span>최고 높이</span><b>${e.bestHeight} m</b></div>
        <div class="res__row"><span>파편</span><b>${sum.shards}</b></div>
        <div class="res__row"><span>최대 연속</span><b>×${sum.bestCombo}</b></div>
        <div class="res__row"><span>버틴 시간</span><b>${fmtTime(sum.time)}</b></div>`;
      const st = document.getElementById('res-stars');
      st.innerHTML = '';
      document.getElementById('scr-result').querySelector('[data-act="next"]').hidden = true;
      ui.show('result', { modal: true });
      audio.play('menu', { intensity: 0.45 });
    }, 1100);
  }

  // ------------------------------------------------------------------ loop
  frame(now) {
    requestAnimationFrame((n) => this.frame(n));
    let dt = (now - this.last) / 1000;
    this.last = now;
    if (!(dt > 0)) dt = STEP;
    dt = Math.min(dt, 0.25);
    this.t += dt;

    stage.sampleFps(dt);
    this.input.update();
    audio.tick(dt);
    ui.tick(this.input, dt);

    // Global shortcuts, only while no dialog is up. Escape is bound to both
    // `pause` and `cancel`; letting both owners act on one press made Escape in
    // a nested dialog fall all the way back to gameplay. With a dialog open,
    // ui.tick owns the key. This also stops `R` from wiping the results screen.
    if (this.scene === 'play' && ui.stack.length === 0) {
      if (this.input.hit('pause')) this.pause();
      if (this.input.hit('restart') && !this.endlessMode) {
        this.startLevel(this.currentLevelId, { restart: true });
      }
    }

    if (this.scene === 'play' && this.world) {
      if (!this.paused && ui.stack.length === 0) {
        this.acc += dt;
        let steps = 0;
        while (this.acc >= STEP && steps < MAX_STEPS) {
          this.world.update(STEP, this.input);
          // Only the first substep of a frame sees the press edges; see
          // Input#clearEdges for why.
          this.input.clearEdges();
          this.acc -= STEP;
          steps++;
        }
        if (steps === MAX_STEPS) this.acc = 0;   // don't let a stall snowball
      }
      this.world.draw();
      ui.hudUpdate(this.world);
      if (this.endlessMode) {
        const el = document.getElementById('hud-timer');
        el.textContent = `${Math.floor(this.world.maxHeight)} m`;
      }
    } else {
      this.titleBg.update(dt);
      this.titleBg.draw();
    }
  }
}

// ============================================================
// TITLE BACKDROP — a live, slowly panning vista behind the menus
// ============================================================
class TitleBackdrop {
  constructor() {
    this.t = 0;
    this.camX = 0;
    this.biomeIdx = 0;
    this.biome = BIOMES.coral;
    this.switchT = 0;
    this.profile = this._profile(7);
    sky.setBiome(this.biome, 3);
    this.clawd = { x: 0, y: 0, anim: 0, blink: 0, blinkT: 2, vx: 0, facing: 1 };
  }

  _profile(seed) {
    const rng = makeRng(seed);
    const pts = new Float32Array(97);
    const o = rng() * 50;
    for (let i = 0; i < pts.length; i++) {
      const u = i / (pts.length - 1);
      pts[i] = fbm(u * 3.4 + o, o * 0.7, 4);
    }
    return pts;
  }

  update(dt) {
    this.t += dt;
    this.camX += dt * 12;
    this.switchT += dt;
    // rotate the vista every 14s so the title screen never feels static
    if (this.switchT > 14) {
      this.switchT = 0;
      this.biomeIdx = (this.biomeIdx + 1) % 3;
      const ids = ['coral', 'glass', 'ember'];
      this.biome = BIOMES[ids[this.biomeIdx]];
      sky.setBiome(this.biome, 3 + this.biomeIdx * 9);
      this.profile = this._profile(7 + this.biomeIdx * 13);
    }
    sky.update(dt, this.camX, 0);
    particles.update(dt, null);

    const c = this.clawd;
    c.blinkT -= dt;
    if (c.blinkT <= 0) { c.blinkT = 2.4 + Math.random() * 4; c.blink = 1; }
    c.blink = Math.max(0, c.blink - dt * 7);
    c.anim += dt * 0.3;
    if (audio.ready) audio.play('menu', { intensity: 0.45 });
  }

  draw() {
    stage.begin();
    sky.draw(this.camX, 0);
    const ctx = stage.ctx;
    stage.screen();
    const W = stage.viewW, H = stage.viewH;

    // foreground plateau, near-black so the type stays readable over it
    const pts = this.profile;
    const off = (this.camX * 0.55) % W;
    ctx.beginPath();
    ctx.moveTo(-off - W, H);
    for (let rep = 0; rep < 3; rep++) {
      for (let i = 0; i < pts.length; i++) {
        const x = -off + (rep - 1) * W + (i / (pts.length - 1)) * W;
        const y = H * 0.72 + pts[i] * H * 0.2;
        ctx.lineTo(x, y);
      }
    }
    ctx.lineTo(W * 2, H);
    ctx.closePath();
    const g = ctx.createLinearGradient(0, H * 0.6, 0, H);
    g.addColorStop(0, this.biome.rockDeep);
    g.addColorStop(1, '#05040A');
    ctx.fillStyle = g;
    ctx.fill();
    ctx.strokeStyle = alpha(this.biome.crustHi, 0.28);
    ctx.lineWidth = 0.8;
    ctx.stroke();

    // Clawd, idling on the right third where the menu isn't.
    // Sample the plateau at his actual x so his feet always touch the ground.
    const cx = W * 0.76;
    const u = (((cx + off) / W) % 1 + 1) % 1;
    const pi = u * (pts.length - 1);
    const p0 = pts[Math.floor(pi)], p1 = pts[Math.min(pts.length - 1, Math.floor(pi) + 1)];
    const cy = H * 0.72 + lerp(p0, p1, pi - Math.floor(pi)) * H * 0.2;
    ctx.save();
    ctx.translate(cx, cy);
    const s = H / 150;
    ctx.scale(s, s);
    drawClawd(ctx, stage.gctx, {
      x: 0, y: 0, vx: 0, vy: 0, grounded: true, facing: -1, state: 'idle',
      t: this.t, anim: this.clawd.anim, squash: 0, invuln: 0, blink: this.clawd.blink,
      skin: SKINS[settings.skin] || SKINS.clawd, dashReady: true, dashFlash: 0, alpha: 1,
    });
    ctx.restore();

    stage.composite({ vignette: 0.25, fade: 0 });
  }
}

// ------------------------------------------------------------------ helpers
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
/**
 * Yield a frame, but never block boot on it: a backgrounded or headless tab can
 * throttle requestAnimationFrame indefinitely, and a loading screen that waits
 * forever is worse than one that advances a beat early.
 */
const raf2 = () => Promise.race([
  new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r))),
  wait(120),
]);

function deathLine(cause) {
  switch (cause) {
    case 'pit': return '심연';
    case 'spike': return '가시';
    case 'saw': return '톱날';
    case 'tide': return '조류에 잠겼다';
    case 'bolt': return '피격';
    default: return '쓰러졌다';
  }
}

/**
 * Surface failures without trapping the player.
 *
 * Before boot completes there is no UI to fall back to, so the message goes on
 * the loading screen. After boot, re-raising the loading screen would leave a
 * dead, buttonless overlay with no way out — so a recoverable dialog is shown
 * instead, and repeat errors are swallowed so a per-frame throw cannot spam it.
 */
let booted = false;
let errorShown = false;
function fatal(msg) {
  const text = String(msg).slice(0, 400);
  if (!booted) {
    const hint = document.getElementById('boot-hint');
    if (hint) { hint.textContent = text; hint.style.color = '#FF9AA6'; }
    const boot = document.getElementById('scr-boot');
    if (boot && !boot.classList.contains('is-active')) boot.classList.add('is-active');
    return;
  }
  if (errorShown) return;
  errorShown = true;
  const el = document.getElementById('err-msg');
  if (el) el.textContent = text;
  try { ui.show('error', { modal: true }); } catch { /* UI itself is broken */ }
}
addEventListener('error', (e) => fatal(`오류: ${e.message} @ ${e.filename?.split('/').pop()}:${e.lineno}`));
addEventListener('unhandledrejection', (e) => fatal(`오류: ${e.reason?.message || e.reason}`));

const app = new App();
window.__clawd = app;   // handy for debugging in the console
app.boot().catch((e) => fatal(`부팅 실패: ${e?.stack || e}`));
