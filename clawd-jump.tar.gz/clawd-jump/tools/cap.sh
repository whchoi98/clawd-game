#!/bin/bash

# Chromium used for automated visual checks. Any build works; `npm run qa:browser`
# downloads a pinned one via Playwright.
CHROME="${CHROME:-$HOME/.cache/ms-playwright/chromium-1194/chrome-linux/chrome}"
if [ ! -x "$CHROME" ]; then
  echo "chromium not found at $CHROME — run: npm run qa:browser (or set CHROME=)" >&2
  exit 1
fi

# cap.sh <name> <query>   e.g. cap.sh c1 "shot=c1&frames=200&hold=right"
mkdir -p shots
"$CHROME" \
  --headless=new --disable-gpu --no-sandbox --hide-scrollbars \
  --window-size=1280,807 --force-device-scale-factor=1 \
  --screenshot="shots/$1.png" --virtual-time-budget=6000 \
  "http://127.0.0.1:8099/index.html?$2" >/dev/null 2>&1
echo "$1: $(stat -c%s shots/$1.png 2>/dev/null || echo FAIL) bytes"
