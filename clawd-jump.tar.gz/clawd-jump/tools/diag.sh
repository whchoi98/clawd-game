#!/bin/bash

# Chromium used for automated visual checks. Any build works; `npm run qa:browser`
# downloads a pinned one via Playwright.
CHROME="${CHROME:-$HOME/.cache/ms-playwright/chromium-1194/chrome-linux/chrome}"
if [ ! -x "$CHROME" ]; then
  echo "chromium not found at $CHROME — run: npm run qa:browser (or set CHROME=)" >&2
  exit 1
fi

"$CHROME" \
  --headless=new --disable-gpu --no-sandbox --window-size=1280,807 \
  --force-device-scale-factor=1 --virtual-time-budget="${2:-9000}" \
  --dump-dom "http://127.0.0.1:8099/index.html?$1" 2>/dev/null \
  | grep -oE 'data-shot="[^"]*"' | head -1 \
  | python3 -c "import sys,html,re,json
raw=sys.stdin.read().strip()
m=re.search(r'data-shot=\"(.*)\"\$', raw, re.S)
print(json.dumps(json.loads(html.unescape(m.group(1))), ensure_ascii=False) if m else 'NO_DIAG')"
