#!/bin/bash

# Chromium used for automated visual checks. Any build works; `npm run qa:browser`
# downloads a pinned one via Playwright.
CHROME="${CHROME:-$HOME/.cache/ms-playwright/chromium-1194/chrome-linux/chrome}"
if [ ! -x "$CHROME" ]; then
  echo "chromium not found at $CHROME — run: npm run qa:browser (or set CHROME=)" >&2
  exit 1
fi

# Boots every level in capture mode and reports the diagnostics blob.
for L in c1 c2 c3 g1 g2 g3 e1 e2 e3 endless; do
  D=$("$CHROME" \
    --headless=new --disable-gpu --no-sandbox --window-size=1280,807 \
    --force-device-scale-factor=1 --virtual-time-budget=7000 \
    --dump-dom "http://127.0.0.1:8099/index.html?shot=$L&frames=240&hold=right" 2>/dev/null \
    | grep -oE 'data-shot="[^"]*"' | head -1 | python3 -c "import sys,html,json,re
raw=sys.stdin.read()
m=re.search(r'data-shot=\"(.*)\"\$', raw.strip(), re.S)
if not m: print('NO_DIAG'); raise SystemExit
try:
  d=json.loads(html.unescape(m.group(1)))
  print(f\"cam={d['cam']} bounds={d['bounds']} lvl={d['level']} pl={d['player']} deaths={d['deaths']} shards={d['shards']} phase={d['phase']} q={d['q']}\")
except Exception as e: print('PARSE_FAIL', e)")
  printf '%-8s %s\n' "$L" "$D"
done
