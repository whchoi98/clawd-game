# -*- coding: utf-8 -*-
"""
Level builder. Hand-authored levels expressed as primitives, emitted as the
rectangular char grids the runtime expects. Keeping the source in primitives
means every row is the same width by construction and a pit can never be
accidentally 9 tiles wide.
"""
import json, sys

class Map:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.g = [['.'] * w for _ in range(h)]

    def set(self, x, y, ch):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.g[y][x] = ch

    def ground(self, x0, x1, ytop):
        """Solid from ytop down to the bottom of the map."""
        for x in range(x0, x1 + 1):
            for y in range(ytop, self.h):
                self.set(x, y, '#')

    def block(self, x0, x1, y0, y1, ch='#'):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                self.set(x, y, ch)

    def plat(self, x0, x1, y, ch='#'):
        for x in range(x0, x1 + 1):
            self.set(x, y, ch)

    def owp(self, x0, x1, y):
        self.plat(x0, x1, y, '=')

    def spikes(self, x0, x1, y, ch='^'):
        for x in range(x0, x1 + 1):
            self.set(x, y, ch)

    def crumb(self, x0, x1, y):
        self.plat(x0, x1, y, 'X')

    def water(self, x0, x1, y0, y1):
        for x in range(x0, x1 + 1):
            self.set(x, y0, '~')
            for y in range(y0 + 1, y1 + 1):
                self.set(x, y, 'W')

    def ent(self, ch, x, y):
        self.set(x, y, ch)

    def shards(self, pts):
        for (x, y) in pts:
            self.set(x, y, 'o')

    def arc(self, x0, y0, x1, y1, n, ch='o'):
        """Place a shard trail along a lobbed arc — reads as a jump invitation."""
        for i in range(n):
            t = i / max(1, n - 1)
            x = round(x0 + (x1 - x0) * t)
            y = round(y0 + (y1 - y0) * t - 3.2 * (1 - (2 * t - 1) ** 2))
            self.set(x, y, ch)

    def rows(self):
        return [''.join(r) for r in self.g]

    def check(self, name):
        rows = self.rows()
        errs = []
        flat = ''.join(rows)
        if flat.count('P') != 1: errs.append(f'{name}: P count={flat.count("P")}')
        if flat.count('G') != 1: errs.append(f'{name}: G count={flat.count("G")}')
        # bottomless pit widths along the lowest solid band
        # find, for each column, the topmost solid tile
        tops = []
        for x in range(self.w):
            t = None
            for y in range(self.h):
                if rows[y][x] in '#X=~W':
                    t = y; break
            tops.append(t)
        run = 0
        for x in range(self.w):
            if tops[x] is None:
                run += 1
                if run > 6: errs.append(f'{name}: empty column run {run} at x={x}')
            else:
                run = 0
        return errs


LEVELS = []

# ============================================================ CORAL 1
def c1():
    m = Map(108, 22)
    m.ground(0, 15, 18)
    # the very first gap has a floor two tiles down: a mistake costs time, not a
    # life. The first lethal pit comes later, once jumping has been taught.
    m.ground(16, 19, 20)
    m.ground(20, 47, 18)
    m.ground(48, 60, 16)
    m.ground(65, 84, 17)
    m.ground(88, 107, 18)
    # decorative back-wall inside the big masses
    # steps and ledges
    m.plat(24, 28, 14); m.plat(33, 36, 12)
    m.plat(52, 56, 12); m.plat(70, 75, 13)
    m.owp(41, 45, 14)
    m.plat(94, 99, 14)
    # shard trails teach the arc of a jump
    m.arc(16, 17, 19, 17, 4)
    m.arc(61, 15, 64, 16, 4)
    m.arc(85, 16, 87, 17, 3)
    m.shards([(25, 13), (26, 13), (27, 13), (34, 11), (35, 11),
              (53, 11), (54, 11), (55, 11), (71, 12), (73, 12), (75, 12),
              (95, 13), (96, 13), (97, 13)])
    m.ent('w', 30, 17)
    m.ent('w', 76, 16)
    m.ent('S', 62, 15)
    m.ent('C', 49, 15)
    m.ent('R', 97, 12)     # reachable from the 94..99 ledge with a double jump
    m.ent('P', 3, 17)
    m.ent('G', 104, 17)
    return dict(id='c1', biome='coral', name='첫 물결', en='FIRST TIDE', par=40, seed=3,
                hint='← → 이동 · SPACE 점프 · 공중에서 한 번 더 눌러 2단 점프', rows=m.rows()), m

# ============================================================ CORAL 2
def c2():
    m = Map(120, 24)
    m.ground(0, 12, 19)
    m.ground(18, 30, 19)
    m.ground(36, 44, 17)
    m.ground(50, 58, 19)
    m.ground(64, 72, 15)
    m.ground(78, 90, 18)
    m.ground(96, 119, 19)
    m.owp(13, 17, 17); m.owp(31, 35, 16); m.owp(45, 49, 18)
    m.plat(59, 63, 17); m.plat(73, 77, 14)
    m.plat(24, 28, 15); m.plat(38, 42, 13)
    m.plat(84, 88, 14); m.plat(101, 106, 15)
    m.spikes(46, 48, 17)
    m.spikes(91, 95, 18)
    m.ent('s', 55, 15)
    m.ent('s', 86, 11)
    m.arc(13, 18, 17, 16, 5)
    m.arc(31, 18, 35, 15, 5)
    m.arc(59, 18, 63, 16, 5)
    m.shards([(25, 14), (26, 14), (39, 12), (40, 12), (41, 12),
              (66, 14), (68, 14), (70, 14), (85, 13), (86, 13), (87, 13),
              (102, 14), (103, 14), (104, 14), (110, 18), (112, 18)])
    m.ent('w', 22, 18); m.ent('w', 54, 18); m.ent('h', 82, 17)
    m.ent('C', 37, 16); m.ent('C', 80, 17)
    m.ent('S', 74, 13)
    m.ent('R', 74, 9)
    m.ent('P', 3, 18)
    m.ent('G', 116, 18)
    return dict(id='c2', biome='coral', name='조류의 틈', en='TIDAL GAP', par=52, seed=11,
                hint='발판 아래에서 위로 통과할 수 있는 얇은 발판이 있다', rows=m.rows()), m

# ============================================================ CORAL 3 — vertical
# Shaft topology, learned the hard way:
#   * interior is 4 tiles wide — a wall jump (vx=168, vy=-258) carries ~3 tiles,
#     so 4 makes alternating walls the obvious answer and 6+ makes it impossible;
#   * the walls stop 2 tiles above the floor, leaving a doorway to walk in;
#   * a spring on the shaft floor lifts you to where the walls begin;
#   * rest ledges are ONE-WAY ('=') — a solid ledge spanning the interior seals
#     the shaft against anyone climbing from below;
#   * there is no cap: you exit by clearing a wall top and standing on it.
def c3():
    m = Map(72, 42)
    # --- entry yard ---
    m.ground(0, 18, 38)
    m.arc(4, 37, 12, 37, 6)
    m.ent('w', 11, 37)

    # --- shaft 1: interior x 23..26, doorway at y 36..37, walls to y=15 / y=11 ---
    m.ground(19, 30, 38)
    m.block(19, 22, 15, 35)
    m.block(27, 30, 11, 35)
    m.ent('S', 24, 37)
    m.owp(23, 26, 29)                     # passable rest ledge
    m.ent('C', 25, 28)
    m.shards([(24, 33), (25, 33), (24, 28), (25, 28), (24, 23), (25, 23),
              (24, 18), (25, 18), (24, 13), (25, 13)])

    # --- mid shelf, reached by stepping off the right wall top ---
    m.ground(31, 42, 14)
    m.plat(35, 39, 10)
    m.ent('t', 41, 13)
    m.ent('s', 33, 12)
    m.shards([(36, 9), (37, 9), (38, 9)])
    m.ent('R', 37, 6)                     # optional: double jump off the ledge
    m.ent('C', 32, 13)

    # --- shaft 2: interior x 47..50, doorway at y 12..13 ---
    m.ground(43, 54, 14)
    m.block(43, 46, 5, 11)
    m.block(51, 54, 3, 11)
    m.ent('S', 48, 13)
    m.shards([(48, 10), (49, 10), (48, 6), (49, 6)])

    # --- summit ---
    m.ground(55, 71, 4)
    m.ent('f', 60, 1)
    m.shards([(58, 3), (61, 3), (64, 3)])
    m.ent('P', 3, 37)
    m.ent('G', 68, 3)
    return dict(id='c3', biome='coral', name='산호 첨탑', en='CORAL SPIRE', par=70, seed=23,
                hint='좁은 통로에서는 좌우 벽을 번갈아 차며 오른다 — 벽에 붙으면 바로 점프', rows=m.rows()), m

# ============================================================ GLASS 1 — dash
def g1():
    m = Map(122, 24)
    m.ground(0, 14, 19)
    m.ground(22, 32, 19)
    m.ground(40, 48, 17)
    m.ground(58, 66, 19)
    m.ground(74, 84, 16)
    m.ground(92, 121, 19)
    m.crumb(15, 21, 18)
    m.crumb(33, 39, 17)
    m.crumb(49, 57, 18)
    m.crumb(85, 91, 17)
    m.plat(26, 30, 15); m.plat(43, 46, 13)
    m.plat(61, 64, 15); m.plat(78, 82, 12)
    m.plat(98, 103, 15); m.plat(108, 113, 12)
    m.spikes(67, 73, 19)
    m.ground(67, 73, 20)
    m.ent('z', 70, 19)
    m.arc(15, 18, 21, 17, 6)
    m.arc(33, 16, 39, 16, 6)
    m.arc(49, 17, 57, 18, 7)
    m.shards([(27, 14), (28, 14), (44, 12), (45, 12),
              (62, 14), (63, 14), (79, 11), (80, 11), (81, 11),
              (99, 14), (100, 14), (101, 14), (109, 11), (110, 11), (111, 11)])
    m.ent('w', 44, 16); m.ent('f', 60, 12); m.ent('w', 96, 18)
    m.ent('C', 41, 16); m.ent('C', 93, 18)
    m.ent('R', 112, 8)
    m.plat(108, 113, 9)
    m.ent('P', 3, 18)
    m.ent('G', 118, 18)
    return dict(id='g1', biome='glass', name='유리 정원', en='GLASS GARDEN', par=58, seed=37,
                hint='SHIFT로 대시. 무너지는 발판 위에서는 멈추지 말 것', rows=m.rows()), m

# ============================================================ GLASS 2 — wall chains
def g2():
    m = Map(86, 44)
    # --- entry yard ---
    m.ground(0, 16, 40)
    m.arc(5, 39, 13, 39, 6)
    m.ent('h', 9, 39)

    # --- shaft A: interior x 21..24, doorway y 38..39, walls to y=21 / y=17 ---
    m.ground(17, 28, 40)
    m.block(17, 20, 21, 37)
    m.block(25, 28, 17, 37)
    m.ent('S', 22, 39)
    m.owp(21, 24, 31)
    m.ent('C', 23, 30)
    m.shards([(22, 35), (23, 35), (22, 30), (23, 30), (22, 26), (23, 26),
              (22, 22), (23, 22), (22, 19), (23, 19)])

    # --- shelf ---
    m.ground(29, 40, 20)
    m.plat(33, 37, 16)
    m.ent('f', 39, 15)
    m.ent('t', 30, 19)
    m.shards([(34, 15), (35, 15), (36, 15)])
    m.ent('R', 35, 11)                    # optional: double jump off the ledge
    m.ent('C', 31, 19)

    # --- shaft B: interior x 45..48, doorway y 18..19, walls to y=9 / y=5 ---
    m.ground(41, 52, 20)
    m.block(41, 44, 9, 17)
    m.block(49, 52, 5, 17)
    m.ent('S', 46, 19)
    m.owp(45, 48, 13)
    m.shards([(46, 15), (47, 15), (46, 12), (47, 12), (46, 8), (47, 8)])

    # --- summit run ---
    m.ground(53, 68, 8)
    m.plat(57, 61, 4)
    m.ent('c', 64, 7)
    m.shards([(58, 3), (59, 3), (60, 3)])
    m.ground(70, 85, 6)
    m.plat(75, 80, 2)
    m.shards([(76, 1), (77, 1)])
    m.ent('C', 71, 5)
    m.ent('P', 3, 39)
    m.ent('G', 82, 5)
    return dict(id='g2', biome='glass', name='반사의 방', en='HALL OF MIRRORS', par=82, seed=53,
                hint='좁은 수직 통로에서는 좌우 벽을 번갈아 차며 오른다', rows=m.rows()), m

# ============================================================ GLASS 3
def g3():
    m = Map(134, 26)
    m.ground(0, 14, 21)
    m.ground(24, 34, 21)
    m.ground(46, 56, 19)
    m.ground(68, 78, 21)
    m.ground(90, 100, 17)
    m.ground(110, 133, 21)
    m.water(15, 23, 23, 25)
    m.water(35, 45, 23, 25)
    m.water(57, 67, 23, 25)
    m.water(79, 89, 23, 25)
    m.water(101, 109, 23, 25)
    m.ent('m', 17, 20); m.ent('m', 38, 20); m.ent('M', 60, 16); m.ent('m', 82, 20)
    m.ent('m', 103, 18)
    m.plat(28, 32, 17); m.plat(50, 54, 15); m.plat(72, 76, 17); m.plat(93, 97, 13)
    m.ent('s', 30, 13); m.ent('s', 74, 13)
    m.ent('t', 52, 18); m.ent('f', 86, 14)
    m.shards([(29, 16), (30, 16), (31, 16), (51, 14), (52, 14), (53, 14),
              (73, 16), (74, 16), (75, 16), (94, 12), (95, 12), (96, 12),
              (118, 20), (120, 20), (122, 20)])
    m.arc(15, 20, 23, 20, 6)
    m.arc(35, 20, 45, 18, 7)
    m.ent('C', 26, 20); m.ent('C', 70, 20); m.ent('C', 112, 20)
    m.ent('S', 114, 20)
    m.ent('R', 114, 13)
    m.plat(112, 117, 14)
    m.ent('P', 3, 20)
    m.ent('G', 130, 20)
    return dict(id='g3', biome='glass', name='서릿결 회랑', en='FROSTLINE GALLERY', par=80, seed=71,
                hint='움직이는 발판은 타이밍이 전부다. 물에 빠지면 느려진다', rows=m.rows(),
                spikers=[[27, 20], [71, 20], [120, 20]]), m

# ============================================================ EMBER 1
def e1():
    m = Map(110, 34)
    m.ground(0, 12, 30)
    m.spikes(13, 19, 30); m.ground(13, 19, 31)
    m.ground(20, 30, 30)
    m.plat(22, 27, 26); m.plat(20, 24, 22)
    m.ground(34, 44, 27)
    m.plat(36, 41, 23); m.plat(38, 43, 19)
    m.spikes(31, 33, 30); m.ground(31, 33, 31)
    m.ground(48, 60, 24)
    m.plat(50, 55, 20); m.plat(53, 58, 16)
    m.ground(64, 76, 21)
    m.plat(66, 71, 17); m.plat(69, 74, 13)
    m.ground(80, 109, 18)
    m.plat(84, 89, 14); m.plat(92, 97, 10)
    m.spikes(61, 63, 24); m.ground(61, 63, 25)
    m.spikes(77, 79, 21); m.ground(77, 79, 22)
    m.ent('S', 16, 29); m.ent('S', 46, 26); m.ent('S', 78, 20)
    m.ent('c', 40, 18); m.ent('c', 70, 12)
    m.ent('h', 26, 25); m.ent('h', 56, 15)
    m.shards([(23, 25), (24, 25), (21, 21), (22, 21),
              (37, 22), (38, 22), (39, 18), (40, 18),
              (51, 19), (52, 19), (54, 15), (55, 15),
              (67, 16), (68, 16), (70, 12), (71, 12),
              (85, 13), (86, 13), (93, 9), (94, 9)])
    m.ent('C', 35, 26); m.ent('C', 65, 20); m.ent('C', 82, 17)
    m.ent('R', 95, 6)
    m.plat(92, 97, 7)
    m.ent('P', 3, 29)
    m.ent('G', 106, 17)
    return dict(id='e1', biome='ember', name='재의 계단', en='ASH STAIRWAY', par=76, seed=97,
                hint='돌진하는 적은 부딪히기 직전 웅크린다. 그때 피해라', rows=m.rows()), m

# ============================================================ EMBER 2
def e2():
    m = Map(126, 28)
    m.ground(0, 12, 23)
    m.crumb(13, 18, 22)
    m.ground(19, 26, 23)
    m.spikes(27, 33, 23); m.ground(27, 33, 24)
    m.crumb(34, 40, 21)
    m.ground(41, 50, 22)
    m.plat(44, 48, 18); m.plat(41, 45, 14)
    m.spikes(51, 56, 22); m.ground(51, 56, 23)
    m.crumb(57, 63, 20)
    m.ground(64, 74, 21)
    m.plat(66, 71, 17); m.plat(69, 74, 13)
    m.spikes(75, 80, 21); m.ground(75, 80, 22)
    m.crumb(81, 87, 19)
    m.ground(88, 98, 20)
    m.plat(90, 95, 16); m.plat(93, 98, 12)
    m.ground(102, 125, 19)
    m.plat(106, 111, 15); m.plat(114, 119, 11)
    m.ent('z', 100, 19)
    m.ent('t', 47, 17); m.ent('t', 72, 12); m.ent('t', 96, 19)
    m.ent('c', 60, 15); m.ent('f', 85, 14)
    m.ent('S', 30, 22); m.ent('S', 54, 21); m.ent('S', 78, 20)
    m.shards([(14, 21), (16, 21), (18, 21), (35, 20), (37, 20), (39, 20),
              (45, 17), (46, 17), (42, 13), (43, 13),
              (58, 19), (60, 19), (62, 19), (67, 16), (68, 16), (70, 12), (71, 12),
              (82, 18), (84, 18), (86, 18), (91, 15), (92, 15), (94, 11), (95, 11),
              (107, 14), (108, 14), (115, 10), (116, 10)])
    m.ent('C', 20, 22); m.ent('C', 65, 20); m.ent('C', 104, 18)
    m.ent('R', 117, 7)
    m.plat(114, 119, 8)
    m.ent('P', 3, 22)
    m.ent('G', 122, 18)
    return dict(id='e2', biome='ember', name='열의 통로', en='HEAT CONDUIT', par=88, seed=131,
                hint='무너지는 발판은 밟는 순간부터 0.4초. 멈추면 떨어진다', rows=m.rows(),
                spikers=[[22, 22], [92, 19]]), m

# ============================================================ EMBER 3 — finale
def e3():
    m = Map(96, 52)
    m.ground(0, 18, 48)
    # chimney 1
    m.block(20, 23, 34, 51)
    m.block(30, 33, 40, 51)
    # One solid mass, not two full-width ledges: the old pair enclosed rows 41-45
    # as a sealed void that held two shards and four spikes nothing could reach.
    m.block(24, 29, 40, 51)
    m.ent('z', 26, 39)
    # mid shelf
    m.plat(34, 44, 36)
    m.block(46, 49, 18, 51)
    m.plat(50, 58, 34); m.plat(50, 58, 28)
    m.block(60, 63, 12, 32)
    m.plat(64, 74, 26)
    m.crumb(75, 81, 25)
    m.ground(82, 95, 26)
    # upper climb
    m.plat(84, 90, 21); m.plat(76, 82, 17); m.plat(66, 72, 13)
    m.plat(56, 62, 9); m.plat(46, 52, 6)
    m.block(38, 41, 2, 12)
    m.plat(30, 37, 8)
    m.plat(20, 27, 4)
    m.ent('m', 35, 32); m.ent('M', 51, 24); m.ent('m', 65, 12)
    m.ent('s', 42, 30); m.ent('s', 70, 20); m.ent('s', 55, 5)
    m.ent('t', 47, 17); m.ent('t', 62, 11); m.ent('c', 88, 20)
    m.ent('f', 78, 12); m.ent('f', 50, 4); m.ent('h', 40, 35)
    m.ent('S', 16, 47); m.ent('S', 86, 25)
    m.arc(6, 47, 14, 47, 6)
    m.shards([(28, 38), (29, 38), (25, 39), (26, 39),
              (36, 35), (38, 35), (40, 35),
              (52, 33), (54, 33), (52, 27), (54, 27),
              (66, 25), (68, 25), (70, 25),
              (85, 20), (86, 20), (78, 16), (79, 16),
              (68, 12), (69, 12), (58, 8), (59, 8), (48, 5), (49, 5),
              (32, 7), (33, 7), (22, 3), (23, 3)])
    m.ent('C', 35, 35); m.ent('C', 65, 25); m.ent('C', 84, 20); m.ent('C', 57, 8)
    m.ent('R', 45, 32)          # optional: needs a dash across the gap
    m.ent('P', 3, 47)
    m.ent('G', 25, 3)
    return dict(id='e3', biome='ember', name='심부의 심장', en='CORE HEART', par=110, seed=173,
                hint='마지막이다. 배운 것 전부를 쓴다', rows=m.rows(),
                spikers=[[42, 35], [88, 25]]), m


builders = [c1, c2, c3, g1, g2, g3, e1, e2, e3]
errs = []
out = []
for b in builders:
    d, m = b()
    e = m.check(d['id'])
    errs += e
    out.append(d)
    w = len(d['rows'][0]); h = len(d['rows'])
    assert all(len(r) == w for r in d['rows']), d['id']
    shards = ''.join(d['rows']).count('o')
    print(f"{d['id']:>3} {d['name']:<8} {w}x{h}  shards={shards:>2}  relics={''.join(d['rows']).count('R')}")

if errs:
    print("\n!! ISSUES:")
    for e in errs: print("  ", e)

import os
out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'levels.json')
with open(out_path, 'w') as f:
    json.dump(out, f, ensure_ascii=False)
print(f"\nwrote {out_path}")
