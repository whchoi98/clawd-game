import * as cdk from 'aws-cdk-lib/core';
import { Match, Template } from 'aws-cdk-lib/assertions';
import { ClawdJumpStack } from '../lib/clawd-jump-stack';

function synth() {
  const app = new cdk.App();
  const stack = new ClawdJumpStack(app, 'TestStack', { env: { account: '123456789012', region: 'ap-northeast-2' } });
  return Template.fromStack(stack);
}

describe('hosting stack', () => {
  test('the site bucket blocks all public access', () => {
    synth().hasResourceProperties('AWS::S3::Bucket', {
      PublicAccessBlockConfiguration: {
        BlockPublicAcls: true,
        BlockPublicPolicy: true,
        IgnorePublicAcls: true,
        RestrictPublicBuckets: true,
      },
    });
  });

  test('the bucket is encrypted and refuses plaintext requests', () => {
    const t = synth();
    t.hasResourceProperties('AWS::S3::Bucket', {
      BucketEncryption: {
        ServerSideEncryptionConfiguration: [
          { ServerSideEncryptionByDefault: { SSEAlgorithm: 'AES256' } },
        ],
      },
    });
    // enforceSSL adds an explicit deny on aws:SecureTransport=false
    t.hasResourceProperties('AWS::S3::BucketPolicy', {
      PolicyDocument: {
        Statement: Match.arrayWith([
          Match.objectLike({
            Effect: 'Deny',
            Condition: { Bool: { 'aws:SecureTransport': 'false' } },
          }),
        ]),
      },
    });
  });

  test('CloudFront reads the bucket through Origin Access Control, not a website endpoint', () => {
    const t = synth();
    t.resourceCountIs('AWS::CloudFront::OriginAccessControl', 1);
    t.hasResourceProperties('AWS::CloudFront::Distribution', {
      DistributionConfig: Match.objectLike({
        Origins: Match.arrayWith([
          Match.objectLike({ OriginAccessControlId: Match.anyValue() }),
        ]),
      }),
    });
    // the bucket policy grants read to the distribution's service principal
    t.hasResourceProperties('AWS::S3::BucketPolicy', {
      PolicyDocument: {
        Statement: Match.arrayWith([
          Match.objectLike({
            Action: 's3:GetObject',
            Principal: { Service: 'cloudfront.amazonaws.com' },
          }),
        ]),
      },
    });
  });

  test('viewers are redirected to HTTPS and responses are compressed', () => {
    synth().hasResourceProperties('AWS::CloudFront::Distribution', {
      DistributionConfig: Match.objectLike({
        DefaultRootObject: 'index.html',
        DefaultCacheBehavior: Match.objectLike({
          ViewerProtocolPolicy: 'redirect-to-https',
          Compress: true,
        }),
      }),
    });
  });

  test('the CSP allows Google Fonts and nothing else off-origin', () => {
    const t = synth();
    const policies = t.findResources('AWS::CloudFront::ResponseHeadersPolicy');
    const csp = Object.values(policies)[0].Properties
      .ResponseHeadersPolicyConfig.SecurityHeadersConfig.ContentSecurityPolicy.ContentSecurityPolicy as string;
    expect(csp).toContain("default-src 'self'");
    expect(csp).toContain('https://fonts.googleapis.com');
    expect(csp).toContain('https://fonts.gstatic.com');
    expect(csp).toContain("frame-ancestors 'none'");
    // no wildcard escape hatches
    expect(csp).not.toContain('*');
  });

  test('HSTS is set for a year, including subdomains', () => {
    synth().hasResourceProperties('AWS::CloudFront::ResponseHeadersPolicy', {
      ResponseHeadersPolicyConfig: Match.objectLike({
        SecurityHeadersConfig: Match.objectLike({
          StrictTransportSecurity: {
            AccessControlMaxAgeSec: 31536000,
            IncludeSubdomains: true,
            Override: true,
          },
        }),
      }),
    });
  });

  test('deploying the site invalidates the CDN so players never mix builds', () => {
    const t = synth();
    const deployments = t.findResources('Custom::CDKBucketDeployment');
    const props = Object.values(deployments)[0].Properties;
    expect(props.DistributionPaths).toEqual(['/*']);
    expect(props.DistributionId).toBeDefined();
    expect(props.Prune).toBe(true);
  });

  test('the stack publishes a playable URL', () => {
    const outs = synth().findOutputs('SiteUrl');
    expect(Object.keys(outs)).toHaveLength(1);
  });
});
